from __future__ import annotations

import argparse
import copy
import math
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.nuscenes_clips import load_nuscenes
from src.utils.io import ensure_dir, read_yaml
from src.utils.logging import setup_logging
from src.utils.seed import seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train the lightweight open-loop ego trajectory planner."
    )
    parser.add_argument("--train", required=True, help="Training clip manifest CSV.")
    parser.add_argument("--val", required=True, help="Validation clip manifest CSV.")
    parser.add_argument("--dataroot", default=None, help="nuScenes dataroot.")
    parser.add_argument("--version", default=None, help="nuScenes version.")
    parser.add_argument("--config", required=True, help="YAML config path.")
    parser.add_argument("--exp-name", default="base_train")
    parser.add_argument(
        "--model-type",
        default=None,
        choices=["mlp", "hydra_mdp_lite", "hydra_mdp_nuscenes"],
    )
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--learning-rate", type=float, default=None)
    parser.add_argument("--weight-decay", type=float, default=None)
    parser.add_argument("--optimizer", default=None, choices=["adamw", "adam"])
    parser.add_argument("--disable-early-stopping", action="store_true")
    parser.add_argument("--early-stopping-patience", type=int, default=None)
    parser.add_argument("--early-stopping-patience-ratio", type=float, default=None)
    parser.add_argument("--early-stopping-min-epochs", type=int, default=None)
    parser.add_argument("--early-stopping-min-epochs-ratio", type=float, default=None)
    parser.add_argument("--early-stopping-min-delta", type=float, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--checkpoint-dir", default="outputs/checkpoints")
    parser.add_argument("--eval-dir", default=None)
    parser.add_argument("--sample-interval-sec", type=float, default=None)
    parser.add_argument("--camera-features", default=None)
    parser.add_argument("--trajectory-vocab", default=None)
    parser.add_argument("--init-checkpoint", default=None)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def planner_dataset_config(planner_cfg: dict[str, Any], args: argparse.Namespace) -> PlannerDatasetConfig:
    from src.models.ego_planner_dataset import PlannerDatasetConfig

    return PlannerDatasetConfig(
        past_horizon_sec=float(planner_cfg.get("past_horizon_sec", 2.0)),
        future_horizon_sec=float(planner_cfg.get("future_horizon_sec", 3.0)),
        sample_interval_sec=args.sample_interval_sec
        if args.sample_interval_sec is not None
        else float(planner_cfg.get("sample_interval_sec", 0.5)),
        collision_distance_m=float(planner_cfg.get("collision_distance_m", 2.0)),
        max_windows_per_clip=planner_cfg.get("max_windows_per_clip"),
        camera_features_path=args.camera_features or planner_cfg.get("camera_features_path"),
        trajectory_vocab_path=args.trajectory_vocab or planner_cfg.get("trajectory_vocab_path"),
        max_agents=int(planner_cfg.get("max_agents", 32)),
    )


def cpu_state_dict(model: Any) -> dict[str, Any]:
    return {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}


def build_optimizer(torch_module: Any, name: str, parameters: Any, lr: float, weight_decay: float) -> Any:
    normalized = name.lower()
    if normalized == "adamw":
        return torch_module.optim.AdamW(parameters, lr=lr, weight_decay=weight_decay)
    if normalized == "adam":
        return torch_module.optim.Adam(parameters, lr=lr, weight_decay=weight_decay)
    raise ValueError(f"Unsupported optimizer: {name}")


def resolve_early_stopping_config(
    training_cfg: dict[str, Any],
    args: argparse.Namespace,
    max_epochs: int,
) -> dict[str, Any]:
    raw_cfg = training_cfg.get("early_stopping", {})
    early_cfg = raw_cfg if isinstance(raw_cfg, dict) else {}

    enabled = bool(early_cfg.get("enabled", training_cfg.get("early_stopping", True)))
    if args.disable_early_stopping:
        enabled = False

    patience_ratio = (
        args.early_stopping_patience_ratio
        if args.early_stopping_patience_ratio is not None
        else float(
            early_cfg.get(
                "patience_ratio",
                training_cfg.get("early_stopping_patience_ratio", 0.20),
            )
        )
    )
    patience = (
        args.early_stopping_patience
        if args.early_stopping_patience is not None
        else early_cfg.get("patience")
    )
    if patience is None:
        patience = math.ceil(max_epochs * patience_ratio)
    patience = max(1, int(patience))

    min_epochs_ratio = (
        args.early_stopping_min_epochs_ratio
        if args.early_stopping_min_epochs_ratio is not None
        else float(
            early_cfg.get(
                "min_epochs_ratio",
                training_cfg.get("early_stopping_min_epochs_ratio", 0.30),
            )
        )
    )
    min_epochs = (
        args.early_stopping_min_epochs
        if args.early_stopping_min_epochs is not None
        else early_cfg.get("min_epochs")
    )
    if min_epochs is None:
        min_epochs = math.ceil(max_epochs * min_epochs_ratio)
    min_epochs = min(max_epochs, max(1, int(min_epochs)))

    min_delta = (
        args.early_stopping_min_delta
        if args.early_stopping_min_delta is not None
        else float(early_cfg.get("min_delta", training_cfg.get("early_stopping_min_delta", 1e-4)))
    )

    return {
        "enabled": enabled,
        "patience": patience,
        "patience_ratio": float(patience_ratio),
        "min_epochs": min_epochs,
        "min_epochs_ratio": float(min_epochs_ratio),
        "min_delta": float(min_delta),
    }


def main() -> None:
    args = parse_args()
    try:
        import torch
    except ImportError as exc:
        raise SystemExit(
            "torch is required to train the planner. Run this script in the NPU/torch "
            "environment described by 00_1_NPU_env.md, or install torch locally."
        ) from exc

    from src.models.ego_planner import build_planner, select_device
    from src.models.ego_planner_dataset import EgoTrajectoryDataset
    from src.models.train_utils import (
        build_loss,
        evaluate_loss,
        evaluate_model_to_outputs,
        make_dataloader,
        train_one_epoch,
    )

    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config)
    dataset_cfg = cfg.get("dataset", {})
    planner_cfg = cfg.get("planner", {})
    training_cfg = cfg.get("training", {})
    if args.model_type:
        planner_cfg = {**planner_cfg, "model_type": args.model_type}

    seed = args.seed if args.seed is not None else int(cfg.get("project", {}).get("seed", 42))
    seed_everything(seed)
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version", "v1.0-mini")
    if not dataroot:
        raise SystemExit("--dataroot is required unless dataset.dataroot is set in --config")

    dataset_config = planner_dataset_config(planner_cfg, args)
    nusc = load_nuscenes(dataroot, version, verbose=not args.quiet)
    train_dataset = EgoTrajectoryDataset(
        args.train,
        dataroot=dataroot,
        version=version,
        config=dataset_config,
        nusc=nusc,
        verbose=not args.quiet,
    )
    val_dataset = EgoTrajectoryDataset(
        args.val,
        dataroot=dataroot,
        version=version,
        config=dataset_config,
        nusc=nusc,
        verbose=False,
    )

    batch_size = args.batch_size or int(planner_cfg.get("batch_size", 32))
    train_loader = make_dataloader(
        train_dataset, batch_size=batch_size, shuffle=True, num_workers=args.num_workers
    )
    val_loader = make_dataloader(
        val_dataset, batch_size=batch_size, shuffle=False, num_workers=args.num_workers
    )
    device = select_device(args.device or planner_cfg.get("device", "auto"))
    trajectory_vocab = None
    if train_dataset.trajectory_vocab is not None:
        trajectory_vocab = torch.from_numpy(train_dataset.trajectory_vocab)
    model, model_config = build_planner(
        input_dim=train_dataset.input_dim,
        future_steps=train_dataset.future_steps,
        planner_cfg=planner_cfg,
        camera_feature_dim=train_dataset.camera_feature_dim,
        trajectory_vocab=trajectory_vocab,
    )
    model = model.to(device)
    if args.init_checkpoint:
        init_checkpoint = torch.load(args.init_checkpoint, map_location="cpu")
        model.load_state_dict(init_checkpoint["model_state_dict"], strict=True)
        logger.info("Initialized model from checkpoint: %s", args.init_checkpoint)
    optimizer_name = str(
        args.optimizer or training_cfg.get("optimizer", planner_cfg.get("optimizer", "adamw"))
    ).lower()
    learning_rate = args.learning_rate or float(planner_cfg.get("learning_rate", 1e-3))
    default_weight_decay = 1e-4 if optimizer_name == "adamw" else 0.0
    weight_decay = args.weight_decay if args.weight_decay is not None else float(
        planner_cfg.get("weight_decay", training_cfg.get("weight_decay", default_weight_decay))
    )
    optimizer = build_optimizer(
        torch,
        optimizer_name,
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay,
    )
    loss_fn = build_loss(str(training_cfg.get("loss", "smooth_l1")))
    classification_weight = float(planner_cfg.get("classification_loss_weight", 0.0))
    metric_score_weight = float(planner_cfg.get("metric_score_loss_weight", 0.0))
    epochs = args.epochs or int(planner_cfg.get("num_epochs", training_cfg.get("base_epochs", 50)))
    early_stopping = resolve_early_stopping_config(training_cfg, args, epochs)

    logger.info(
        "Training %s on %s: train_windows=%d val_windows=%d input_dim=%d future_steps=%d",
        args.exp_name,
        device,
        len(train_dataset),
        len(val_dataset),
        train_dataset.input_dim,
        train_dataset.future_steps,
    )
    logger.info(
        "optimizer=%s lr=%.6g weight_decay=%.6g max_epochs=%d early_stopping=%s "
        "patience=%d min_epochs=%d min_delta=%.6g",
        optimizer_name,
        learning_rate,
        weight_decay,
        epochs,
        early_stopping["enabled"],
        early_stopping["patience"],
        early_stopping["min_epochs"],
        early_stopping["min_delta"],
    )

    best_val_loss = float("inf")
    best_epoch = 0
    best_state = cpu_state_dict(model)
    no_improvement_epochs = 0
    epochs_ran = 0
    stopped_early = False
    stop_reason = "max_epochs_reached"
    history: list[dict[str, Any]] = []
    for epoch in range(1, epochs + 1):
        epochs_ran = epoch
        train_loss = train_one_epoch(
            model,
            train_loader,
            optimizer,
            loss_fn,
            device,
            classification_weight=classification_weight,
            metric_score_weight=metric_score_weight,
            collision_threshold_m=dataset_config.collision_distance_m,
        )
        val_loss = evaluate_loss(
            model,
            val_loader,
            loss_fn,
            device,
            classification_weight=classification_weight,
            metric_score_weight=metric_score_weight,
            collision_threshold_m=dataset_config.collision_distance_m,
        )
        improved = val_loss < best_val_loss - float(early_stopping["min_delta"])
        if improved:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = cpu_state_dict(model)
            no_improvement_epochs = 0
        else:
            no_improvement_epochs += 1

        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "best_val_loss": best_val_loss,
                "is_best": improved,
                "no_improvement_epochs": no_improvement_epochs,
            }
        )
        logger.info(
            "epoch=%03d/%03d train_loss=%.6f val_loss=%.6f best_val_loss=%.6f "
            "no_improve=%d/%d",
            epoch,
            epochs,
            train_loss,
            val_loss,
            best_val_loss,
            no_improvement_epochs,
            early_stopping["patience"],
        )
        if (
            early_stopping["enabled"]
            and epoch >= int(early_stopping["min_epochs"])
            and no_improvement_epochs >= int(early_stopping["patience"])
        ):
            stopped_early = True
            stop_reason = f"no_validation_improvement_for_{no_improvement_epochs}_epochs"
            logger.info(
                "Early stopping at epoch %d/%d. best_epoch=%d best_val_loss=%.6f",
                epoch,
                epochs,
                best_epoch,
                best_val_loss,
            )
            break

    model.load_state_dict(copy.deepcopy(best_state))
    checkpoint_dir = ensure_dir(args.checkpoint_dir)
    checkpoint_path = checkpoint_dir / f"{args.exp_name}.pt"
    eval_dir = args.eval_dir or str(Path("outputs") / "eval" / args.exp_name)
    metrics, _ = evaluate_model_to_outputs(
        model,
        val_dataset,
        val_loader,
        device,
        utility_cfg=cfg.get("utility", {}),
        out_dir=eval_dir,
        collision_threshold_m=dataset_config.collision_distance_m,
    )
    checkpoint = {
        "model_state_dict": best_state,
        "model_config": model_config,
        "dataset_config": asdict(dataset_config),
        "training_config": {
            "max_epochs": epochs,
            "epochs_ran": epochs_ran,
            "best_epoch": best_epoch,
            "stopped_early": stopped_early,
            "stop_reason": stop_reason,
            "batch_size": batch_size,
            "optimizer": optimizer_name,
            "learning_rate": learning_rate,
            "weight_decay": weight_decay,
            "early_stopping": early_stopping,
            "loss": str(training_cfg.get("loss", "smooth_l1")),
            "classification_loss_weight": classification_weight,
            "metric_score_loss_weight": metric_score_weight,
            "seed": seed,
        },
        "dataset_version": version,
        "history": history,
        "best_val_loss": best_val_loss,
        "validation_metrics": metrics,
        "utility_config": cfg.get("utility", {}),
    }
    torch.save(checkpoint, checkpoint_path)
    logger.info("Saved checkpoint: %s", checkpoint_path)
    logger.info("Saved validation metrics under: %s", eval_dir)


if __name__ == "__main__":
    main()
