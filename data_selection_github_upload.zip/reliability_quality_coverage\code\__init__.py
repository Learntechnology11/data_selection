"""Reliability-Quality Coverage research code.

The original experiments target image classification, while
``nuscenes_rqc.py`` adapts the standalone RQC selector to autonomous-driving
clip selection on nuScenes artifacts.
"""
