from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.utils.io import ensure_dir, read_csv, require_columns, write_csv


DEFAULT_RANKING_WEIGHTS = {
    "ade": 0.35,
    "fde": 0.35,
    "heading_error": 0.10,
    "collision_proxy": 0.10,
    "offroad_proxy": 0.10,
}


def robust_normalize(values: pd.Series, clip_min: float = 0.0, clip_max: float = 5.0) -> pd.Series:
    numeric = pd.to_numeric(values, errors="coerce")
    valid = numeric.dropna()
    if valid.empty:
        return pd.Series(np.nan, index=values.index)
    median = float(valid.median())
    iqr = float(valid.quantile(0.75) - valid.quantile(0.25))
    if abs(iqr) < 1e-8:
        denom = max(abs(median), 1.0)
        normalized = numeric / denom
    else:
        normalized = (numeric - median) / (iqr + 1e-8)
    return normalized.clip(lower=clip_min, upper=clip_max)


def active_metric_weights(metrics: pd.DataFrame, weights: dict[str, float]) -> dict[str, float]:
    active: dict[str, float] = {}
    for metric, weight in weights.items():
        if metric not in metrics.columns:
            continue
        if pd.to_numeric(metrics[metric], errors="coerce").notna().any():
            active[metric] = float(weight)
    total = sum(active.values())
    if total <= 0:
        raise ValueError("No available metrics for importance scoring")
    return {metric: weight / total for metric, weight in active.items()}


def compute_importance_scores(
    per_clip_metrics: pd.DataFrame,
    weights: dict[str, float] | None = None,
    clip_min: float = 0.0,
    clip_max: float = 5.0,
) -> pd.DataFrame:
    require_columns(per_clip_metrics, ["clip_id"], "per_clip_metrics")
    result = per_clip_metrics.copy()
    active = active_metric_weights(result, weights or DEFAULT_RANKING_WEIGHTS)
    score = pd.Series(0.0, index=result.index)
    for metric, weight in active.items():
        norm_col = f"normalized_{metric}"
        result[norm_col] = robust_normalize(result[metric], clip_min, clip_max)
        score = score + weight * result[norm_col].fillna(0.0)
    result["importance_score"] = score.astype(float)
    return result


def build_ranked_pool(
    pool: pd.DataFrame,
    clusters: pd.DataFrame,
    per_clip_metrics: pd.DataFrame,
    weights: dict[str, float] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    require_columns(pool, ["clip_id"], "pool")
    require_columns(clusters, ["clip_id", "cluster_id"], "clusters")
    scored = compute_importance_scores(per_clip_metrics, weights=weights)
    pool_cols = [
        col
        for col in ["clip_id", "scene_token", "location", "description", "sample_tokens", "num_samples"]
        if col in pool.columns
    ]
    merged = (
        pool[pool_cols]
        .merge(clusters[["clip_id", "cluster_id"]], on="clip_id", how="left")
        .merge(scored, on="clip_id", how="left", suffixes=("", "_metric"))
    )
    if merged["cluster_id"].isna().any():
        bad = merged.loc[merged["cluster_id"].isna(), "clip_id"].astype(str).tolist()
        raise ValueError(f"Missing cluster assignments for pool clips: {bad[:5]}")
    if merged["importance_score"].isna().any():
        bad = merged.loc[merged["importance_score"].isna(), "clip_id"].astype(str).tolist()
        raise ValueError(f"Missing importance scores for pool clips: {bad[:5]}")

    ranked = merged.sort_values(
        ["cluster_id", "importance_score", "clip_id"],
        ascending=[True, False, True],
    ).reset_index(drop=True)
    ranked["rank_within_cluster"] = (
        ranked.groupby("cluster_id").cumcount() + 1
    ).astype(int)
    global_scores = ranked.sort_values(
        ["importance_score", "clip_id"], ascending=[False, True]
    ).reset_index(drop=True)
    global_scores["global_rank"] = np.arange(1, len(global_scores) + 1)
    return global_scores, ranked


def save_ranking_outputs(
    pool_scores: pd.DataFrame,
    ranked_pool: pd.DataFrame,
    out_dir: str | Path,
) -> None:
    output_dir = ensure_dir(out_dir)
    write_csv(pool_scores, output_dir / "pool_importance_scores.csv")
    write_csv(ranked_pool, output_dir / "cluster_ranked_pool.csv")


def load_rank_inputs(
    pool_path: str | Path,
    clusters_path: str | Path,
    per_clip_metrics_path: str | Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    return read_csv(pool_path), read_csv(clusters_path), read_csv(per_clip_metrics_path)
