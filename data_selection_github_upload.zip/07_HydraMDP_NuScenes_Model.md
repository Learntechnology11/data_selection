# HydraMDP-nuScenes Model

This project now uses `HydraMDP-nuScenes` as the recommended planner model for
nuScenes experiments. The implementation is still not the full original
Hydra-MDP, but it is much closer to the public Hydra-MDP design than the earlier
`HydraMDP-lite` MLP.

Core code:

```text
src/models/hydra_mdp_nuscenes.py
src/models/ego_planner_dataset.py
src/models/train_utils.py
configs/mosaic_nuscenes_mini.yaml
```

## 1. Inputs

For each training window, the dataset builds:

```text
ego history:
  shape = [past_steps * 4]
  fields per step = local_x, local_y, yaw_delta, speed

camera features:
  shape = [6 * 512] when using ResNet18 concat
  cameras = front, front-left, front-right, back, back-left, back-right

agent/environment tokens:
  shape = [max_agents, 15]
  fields = normalized local_x, normalized local_y, normalized distance,
           normalized yaw_delta,
           normalized length, width, height,
           normalized local_vx, local_vy, speed,
           is_vehicle, is_pedestrian, is_cycle, is_barrier,
           normalized log_sensor_point_count

trajectory vocabulary:
  shape = [num_modes, future_steps, 2]
```

The current mini config uses:

```text
past_horizon_sec = 2.0
future_horizon_sec = 3.0
sample_interval_sec = 0.5
past_steps = 5
future_steps = 6
num_modes = 64
max_agents = 32
```

## 2. Structure

`HydraMDP-nuScenes` contains:

```text
ego_encoder:
  MLP -> ego token

camera_encoder:
  split cached 6-camera feature into camera tokens
  MLP per camera token

agent_encoder:
  MLP per nearby-agent token

environment_encoder:
  TransformerEncoder over ego + camera + agent tokens

trajectory queries:
  encode trajectory vocabulary centers as decoder queries

trajectory_decoder:
  TransformerDecoder queries attend to environment memory

heads per trajectory mode:
  residual trajectory head
  imitation / mode logits head
  metric score head
```

The forward output is:

```text
trajectory:
  selected / weighted future trajectory, shape [B, T, 2]

candidate_trajectories:
  all mode candidates, shape [B, K, T, 2]

trajectory_logits:
  imitation logits over K trajectory modes, shape [B, K]

metric_scores:
  per-mode rule-metric costs, shape [B, K, 3]

selection_logits:
  trajectory_logits minus weighted metric_scores
```

## 3. Training Objective

The loss is:

```math
L =
L_{traj}
+ \lambda_{cls} L_{vocab}
+ \lambda_{metric} L_{metric}
```

where:

```text
L_traj:
  SmoothL1 between selected trajectory and human future ego trajectory

L_vocab:
  cross entropy between trajectory_logits and nearest trajectory vocabulary mode

L_metric:
  MSE between predicted metric_scores and weak rule-teacher proxy costs
```

Current proxy metric heads:

```text
metric_scores[..., 0] = collision proximity risk
metric_scores[..., 1] = early TTC-like proximity risk
metric_scores[..., 2] = comfort / jerk risk
```

Current config:

```yaml
classification_loss_weight: 0.2
metric_score_loss_weight: 0.1
metric_score_weights: [0.50, 0.30, 0.20]
```

## 4. Output Capability

Compared with the old `HydraMDP-lite`, the new model can produce:

```text
1. a final selected trajectory;
2. multiple candidate trajectories from vocabulary queries;
3. mode logits / uncertainty entropy;
4. per-candidate safety and comfort scores;
5. fused environment features for ranking and data selection.
```

This makes the model more useful for RQC / MOSAIC because the ranking metrics
come from a planner that has explicit candidate-level safety and comfort heads,
not only a single regression output.

## 5. Difference From Original Hydra-MDP

This is still a practical nuScenes reproduction, not a full original Hydra-MDP
implementation.

Kept or approximated:

```text
trajectory vocabulary queries
transformer environment fusion
multi-candidate trajectory decoder
imitation logits
metric score heads
rule-based metric proxy distillation
camera + ego + agent/environment inputs
```

Still simplified:

```text
camera images are cached ResNet features, not end-to-end perception
no LiDAR BEV backbone yet
no radar point encoder yet
no 3D detection / BEV segmentation auxiliary heads yet
no human + rule multi-teacher distillation dataset yet
no full closed-loop simulator cost supervision yet
```

Therefore the correct paper wording is:

```text
Hydra-MDP-inspired nuScenes planner
```

or:

```text
a compact Hydra-MDP-style multi-candidate planner
```

Do not claim it is the original full Hydra-MDP.

## 6. Recommended Next Upgrade

For full nuScenes on two Ascend NPU 910B3 cards, the next meaningful upgrades are:

```text
1. add LiDAR BEV feature cache and BEV token encoder;
2. add radar point / radar pillar token cache;
3. add BEV drivable-area or map-token supervision;
4. add DDP / torchrun training for two devices;
5. increase camera backbone to pretrained ResNet50 or a nuScenes-friendly backbone.
```

These should be added as new modules without removing the current cached-feature
path, so mini experiments remain fast and reproducible.
