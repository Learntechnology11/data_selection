# Codex 提示词合集：MOSAIC-on-nuScenes

## 0. 总控提示词

```text
你现在是自动驾驶数据选择算法工程师，请基于 nuScenes 数据集复现论文 “Scaling-Aware Data Selection for End-to-End Autonomous Driving Systems” 中的 MOSAIC 数据选择算法。

注意：不要照搬论文中的 OpenScene/Navtrain/NAVSIM/EPDMS 设置，因为当前项目使用的是 nuScenes。你的任务是复现 MOSAIC 的核心算法机制，而不是完全复现论文原实验环境。
当前只需要写出代码即可，但要验证代码的可使用性和正确性！
注：本地的代码我将会誊写到云端服务器上运行，服务器的环境是昇腾NPU，你写的代码尽可能利用当前环境已有的代码包（环境和代码包参考文件00_1_NPU_env.md）。如果没有该包的话就使用pip安装一下。最好不要更新已有的包
本地已有的可用环境是torch_gpu

MOSAIC 的核心流程是：
1. 将 D_pool 按驾驶场景 domain 聚类；
2. 在每个 cluster/domain 内根据样本重要性排序；
3. 对每个 cluster 进行小规模 pilot 训练或 fine-tuning，得到不同数据量 n 下的 validation utility 改善；
4. 对每个 cluster 拟合 saturating exponential scaling law：
   Delta_U_i(n) = a_i * (1 - exp(-n / tau_i))
5. 在给定预算 B 下，反复计算每个 cluster 的边际收益：
   delta_i(b_i) = Delta_U_i(b_i + step) - Delta_U_i(b_i)
   每次从边际收益最大的 cluster 中选取下一个 batch 的样本；
6. 输出最终选择的 clip manifest，用于训练 E2E planner 或轻量 planner。

请你优先实现一个可运行、可复现实验框架，先支持 nuScenes v1.0-mini，再支持 v1.0-trainval。不要写伪代码，不要 mock 结果。所有脚本都要能通过命令行运行，并生成 CSV/JSON 中间结果。

项目需要包含：
- scripts/build_nuscenes_clips.py
- scripts/create_splits.py
- scripts/extract_clip_features.py
- scripts/cluster_pool.py
- scripts/rank_pool.py
- scripts/run_pilot_experiments.py
- scripts/fit_scaling_laws.py
- scripts/select_mosaic.py
- scripts/select_baselines.py
- scripts/train_planner.py
- scripts/evaluate_planner.py
- configs/mosaic_nuscenes_mini.yaml
- configs/mosaic_nuscenes_trainval.yaml
- README_REPRO.md

先从最小闭环做起：
nuScenes mini -> 构建 10s clip -> 抽取 metadata/ego-motion/map/agent 特征 -> 聚类 -> 排序 -> 用轻量 planner 训练和评估 -> pilot scaling -> MOSAIC 选择 -> 与 Random/Coreset/Ranking-only 对比。
```

---

## 1. Prompt：建立工程骨架

```text
请先为当前项目创建一个可复现的 MOSAIC-on-nuScenes 工程骨架。

要求：
1. 新建目录：
   - configs/
   - scripts/
   - src/
   - src/data/
   - src/features/
   - src/selection/
   - src/models/
   - src/evaluation/
   - src/utils/
   - outputs/
2. 创建配置文件：
   - configs/mosaic_nuscenes_mini.yaml
   - configs/mosaic_nuscenes_trainval.yaml
3. 创建 README_REPRO.md，写清楚从 nuScenes mini 到 MOSAIC 选择的最小复现流程。
4. 所有脚本先写 argparse 和 main 函数，但不要只写空壳，要预留清晰 TODO 和输入输出路径。
5. 添加 requirements.txt，至少包含：
   - nuscenes-devkit
   - numpy
   - pandas
   - scikit-learn
   - scipy
   - torch
   - pyyaml
   - tqdm
   - matplotlib
   - pyarrow

请先完成工程骨架，不要一次性实现所有算法。
完成后请列出新增文件树和下一步建议。
```

---

## 2. Prompt：构建 nuScenes 10 秒 clip

```text
请实现 scripts/build_nuscenes_clips.py 和 src/data/nuscenes_clips.py。

目标：
从 nuScenes v1.0-mini 或 v1.0-trainval 中构建 10 秒 virtual clips。

要求：
1. 使用 nuscenes-devkit 读取 NuScenes。
2. 每个 scene 约 20 秒，请尽量切成两个非重叠 10 秒 clip。
3. 每个 clip 保存：
   - clip_id
   - scene_token
   - log_token
   - location
   - description
   - start_sample_token
   - end_sample_token
   - sample_tokens
   - num_samples
4. 输出 CSV：
   outputs/clips/nuscenes_{version}_clips.csv
5. 增加检查：
   - sample_tokens 不为空
   - 每个 clip 至少包含指定数量 keyframes
   - clip_id 唯一
6. 支持命令：
   python scripts/build_nuscenes_clips.py \
       --dataroot /path/to/nuscenes \
       --version v1.0-mini \
       --out outputs/clips/nuscenes_mini_clips.csv

请写完整可运行代码，并在 README_REPRO.md 中补充运行命令。
```

---

## 3. Prompt：划分 D_train、D_pool、D_val

```text
请实现 scripts/create_splits.py 和 src/data/splits.py。

目标：
根据 clips.csv 划分 base training set、pool set、validation set。

要求：
1. 对 v1.0-mini：
   - 按 clip 随机划分：
     D_train_base = 20%
     D_pool = 60%
     D_val = 20%
   - 使用固定 seed。
2. 对 v1.0-trainval：
   - 如果可以读取官方 train/val scene split，则优先使用官方 split。
   - train scenes 中抽取 10% 或 20% 作为 D_train_base，其余作为 D_pool。
   - val scenes 作为 D_val。
3. 输出：
   outputs/splits/base_train.csv
   outputs/splits/pool.csv
   outputs/splits/val.csv
4. 检查三个集合 clip_id 无交集。

命令示例：
python scripts/create_splits.py \
    --clips outputs/clips/nuscenes_mini_clips.csv \
    --mode mini_random \
    --base-ratio 0.2 \
    --pool-ratio 0.6 \
    --seed 42 \
    --out-dir outputs/splits
```

---

## 4. Prompt：抽取 clip 特征

```text
请实现 scripts/extract_clip_features.py 和 src/features/clip_features.py。

目标：
为每个 nuScenes 10 秒 clip 抽取用于聚类和 coreset 的特征。

最低要求：
1. metadata 特征：
   - location one-hot
   - scene description 的 TF-IDF 特征
2. ego-motion 特征：
   - mean_speed
   - max_speed
   - mean_acceleration
   - max_acceleration
   - mean_yaw_rate
   - max_yaw_rate
   - total_displacement
3. agent-density 特征：
   - mean_num_agents
   - mean_num_vehicles
   - mean_num_pedestrians
   - min_distance_to_agent
4. 输出：
   outputs/features/clip_features.parquet
   outputs/features/clip_features.npy
   outputs/features/clip_feature_columns.json

实现要求：
- 使用 nuScenes sample、ego_pose、sample_annotation 表。
- 速度/加速度可根据 ego pose 时间差近似计算。
- yaw rate 需要处理角度 unwrap。
- 如果某个 clip 无足够时间点，跳过或填充 NaN 后统一处理。
- 所有 NaN 必须在保存前处理。
- 添加日志，说明每类特征维度。

命令示例：
python scripts/extract_clip_features.py \
    --dataroot /path/to/nuscenes \
    --version v1.0-mini \
    --clips outputs/clips/nuscenes_mini_clips.csv \
    --out-dir outputs/features
```

---

## 5. Prompt：聚类

```text
请实现 scripts/cluster_pool.py 和 src/selection/clustering.py。

目标：
对 D_pool 中的 clip 进行 domain clustering。

输入：
- outputs/splits/pool.csv
- outputs/features/clip_features.parquet 或 .npy

实现两种 clustering mode：

1. location
   - 直接根据 nuScenes log location 分组。
   - 每个 location 是一个 cluster。

2. kmeans
   - 使用 metadata + ego-motion + agent-density 特征。
   - 标准化 numeric features。
   - KMeans 或 MiniBatchKMeans。
   - 支持 --num-clusters。

输出：
outputs/clusters/cluster_assignments.csv

列：
clip_id, cluster_id, cluster_method

还需要输出：
outputs/clusters/cluster_summary.csv

列：
cluster_id, num_clips, top_locations, top_description_keywords

命令示例：
python scripts/cluster_pool.py \
    --pool outputs/splits/pool.csv \
    --features outputs/features/clip_features.parquet \
    --method kmeans \
    --num-clusters 6 \
    --out-dir outputs/clusters
```

---

## 6. Prompt：训练轻量 planner

```text
请实现一个最小可运行的 open-loop ego trajectory planner。

文件：
- src/models/ego_planner_dataset.py
- src/models/ego_planner.py
- scripts/train_planner.py
- scripts/evaluate_planner.py
- src/evaluation/metrics.py
- src/evaluation/utility.py

任务：
用过去若干帧 ego 状态预测未来若干帧 ego trajectory。

输入：
- clip 的 sample_tokens
- ego_pose 序列
- 可选 clip-level features

模型：
- 先实现 MLPPlanner 或 GRUPlanner。
- 输入 past ego states: x, y, yaw, speed。
- 输出 future x, y offsets。
- Loss: SmoothL1Loss 或 L1Loss。

评估指标：
- ADE
- FDE
- heading_error
- jerk
- collision_proxy，可先基于预测轨迹与 annotation box center 距离近似
- offroad_proxy，如果 map API 暂时复杂，可以先实现为可选项；没有 map 时返回 NaN 并在 utility 中跳过

输出：
outputs/eval/{experiment_name}/metrics.json
outputs/eval/{experiment_name}/per_clip_metrics.csv

要求：
1. 支持 train/eval 两个脚本。
2. 支持从 CSV manifest 读取训练 clip。
3. 保存 checkpoint。
4. 支持 seed。
5. 支持 CPU/GPU 自动选择。

命令示例：
python scripts/train_planner.py \
    --train outputs/splits/base_train.csv \
    --val outputs/splits/val.csv \
    --dataroot /path/to/nuscenes \
    --version v1.0-mini \
    --config configs/mosaic_nuscenes_mini.yaml \
    --exp-name base_train

python scripts/evaluate_planner.py \
    --checkpoint outputs/checkpoints/base_train.pt \
    --eval outputs/splits/val.csv \
    --out-dir outputs/eval/base_train
```

---

## 7. Prompt：样本重要性排序

```text
请实现 scripts/rank_pool.py 和 src/selection/ranking.py。

目标：
使用 base planner 对 D_pool 中每个 clip 单独评估，得到 clip-level importance score。

输入：
- base planner checkpoint
- D_pool CSV
- cluster assignments CSV
- nuScenes dataroot
- metrics normalization config

计算：
1. 对每个 pool clip 计算：
   - ADE
   - FDE
   - heading_error
   - collision_proxy
   - offroad_proxy，如果可用
2. 对每个指标做 robust normalization：
   normalized_x = (x - median) / (IQR + eps)
   再 clip 到合理范围，例如 [0, 5]
3. importance score：
   importance =
     0.35 * normalized_ADE +
     0.35 * normalized_FDE +
     0.10 * normalized_heading_error +
     0.10 * normalized_collision_proxy +
     0.10 * normalized_offroad_proxy
4. 如果 offroad_proxy 不可用，则重新归一化其余权重。

输出：
outputs/ranking/pool_importance_scores.csv
outputs/ranking/cluster_ranked_pool.csv

cluster_ranked_pool.csv 要包含：
clip_id,
cluster_id,
ade,
fde,
heading_error,
collision_proxy,
offroad_proxy,
importance_score,
rank_within_cluster

排序规则：
每个 cluster 内 importance_score 越高，rank 越靠前。
```

---

## 8. Prompt：pilot 实验与 scaling law 拟合

```text
请实现 scripts/run_pilot_experiments.py、scripts/fit_scaling_laws.py 和 src/selection/scaling.py。

run_pilot_experiments.py 目标：
对每个 cluster，分别选择 top-n ranked clips 加入 base_train，然后训练或 fine-tune planner，得到 validation utility。

输入：
- base_train.csv
- val.csv
- cluster_ranked_pool.csv
- budgets，例如 5,10,20 或 50,100,200
- base checkpoint，可选
- train mode: scratch 或 finetune

输出：
outputs/pilot/pilot_results.csv

列：
cluster_id,
n,
seed,
selected_clip_ids,
utility,
delta_utility,
ade,
fde,
heading_error,
collision_proxy,
offroad_proxy,
checkpoint_path

fit_scaling_laws.py 目标：
对每个 cluster 拟合：
Delta_U_i(n) = a_i * (1 - exp(-n / tau_i))

要求：
1. 使用 scipy.optimize.curve_fit 或 least_squares。
2. 加约束：
   a_i >= 0
   tau_i > 0
3. fitting 失败时 fallback：
   a_i = max observed delta_utility
   tau_i = median n
4. 保存：
   outputs/scaling/scaling_params.json
   outputs/scaling/scaling_fit_plot_cluster_{i}.png

命令示例：
python scripts/run_pilot_experiments.py \
    --base-train outputs/splits/base_train.csv \
    --val outputs/splits/val.csv \
    --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
    --pilot-budgets 5 10 20 \
    --mode finetune \
    --out outputs/pilot/pilot_results.csv

python scripts/fit_scaling_laws.py \
    --pilot-results outputs/pilot/pilot_results.csv \
    --out-dir outputs/scaling
```

---

## 9. Prompt：MOSAIC 选择器

```text
请实现 scripts/select_mosaic.py 和 src/selection/mosaic.py。

目标：
根据 cluster ranking 和 scaling law 参数，在总预算 B 下选择数据。

输入：
- outputs/ranking/cluster_ranked_pool.csv
- outputs/scaling/scaling_params.json
- budget B
- step 或 batch_size

算法：
1. 初始化 b_i = 0。
2. 对每个 cluster i，计算：
   f_i(b_i + step) - f_i(b_i)
3. 选择边际收益最大的 cluster j。
4. 从 cluster j 的 ranked list 中选取下一个未选 clip。
5. 更新 b_j。
6. 重复直到选满 B。

输出：
1. outputs/selections/mosaic_budget_{B}.csv
   - selected clip manifest
2. outputs/selections/mosaic_trace_budget_{B}.csv
   - 每一步选择过程

trace 列：
step_id,
selected_cluster_id,
selected_clip_id,
cluster_count_before,
cluster_count_after,
estimated_marginal_gain

要求：
- 如果某个 cluster 已经没有 clip，则跳过该 cluster。
- 如果所有 scaling gain 都 <= 0，则 fallback 到全局 importance ranking。
- 增加单元测试，验证输出数量等于 B。
```

---

## 10. Prompt：baseline 对比实验

```text
请实现 scripts/select_baselines.py 和 scripts/run_selection_experiments.py。

baseline 至少包括：

1. Random
   - 从 D_pool 随机选择 B 个 clip。
   - 支持 seed。
2. Coreset
   - 使用 clip features。
   - greedy farthest-first。
   - 初始化集合为 base_train。
3. Ranking-only
   - 直接选择全局 importance_score 最高的 B 个 clip。
4. Cluster-only
   - 使用 MOSAIC 的 cluster 分配数量，但 cluster 内随机采样。
5. Uncertainty
   - 如果 planner 支持多模态或 dropout，使用预测方差。
   - 如果暂不支持，先实现 MC dropout uncertainty，并在 README 中说明。

每个方法输出：
outputs/selections/{method}_budget_{B}_seed_{seed}.csv

然后训练 planner：
base_train + selected clips -> train -> evaluate on val

汇总结果：
outputs/results/main_results.csv

列：
dataset_version,
method,
budget,
seed,
utility,
ADE,
FDE,
heading_error,
collision_proxy,
offroad_proxy,
jerk

请确保所有实验可通过一个命令运行：
python scripts/run_selection_experiments.py \
    --config configs/mosaic_nuscenes_mini.yaml \
    --budgets 20 40 80 \
    --methods random coreset ranking_only mosaic \
    --seeds 0 2025 424242
```

---

## 11. Prompt：完整闭环检查

```text
请检查当前 MOSAIC-on-nuScenes 项目是否已经形成完整闭环。

完整闭环应包括：
1. build_nuscenes_clips.py 能生成 10 秒 clip manifest；
2. create_splits.py 能生成 base_train / pool / val；
3. extract_clip_features.py 能生成 clip features；
4. cluster_pool.py 能生成 cluster assignments；
5. train_planner.py 能训练 base planner；
6. rank_pool.py 能生成 pool importance score；
7. run_pilot_experiments.py 能对每个 cluster 跑 pilot；
8. fit_scaling_laws.py 能拟合 Delta_U_i(n)=a_i(1-exp(-n/tau_i))；
9. select_mosaic.py 能按 marginal gain 选择预算 B 的样本；
10. select_baselines.py 能生成 random / coreset / ranking-only 选择结果；
11. run_selection_experiments.py 能训练并评估所有方法；
12. outputs/results/main_results.csv 能汇总所有结果。

请你：
- 逐个检查脚本输入输出是否一致；
- 修复路径、字段名、配置项不一致的问题；
- 添加必要的 sanity check；
- 在 README_REPRO.md 中写出从零运行 nuScenes mini 实验的完整命令；
- 不要删除已有功能；
- 不要 mock 数据；
- 不要跳过真实训练和评估逻辑。
```

---

## 12. Prompt：防止 Codex 跑偏

```text
注意以下问题：

1. nuScenes 的 scene 是约 20 秒，不是论文 OpenScene/Navtrain 中任意长度 session，所以 clip 构建方式要适配 nuScenes。
2. nuScenes 没有 EPDMS，不要强行实现 EPDMS。先用 open-loop planner utility 替代。
3. 如果 map API 难以一次实现，off-road proxy 可以先设为 optional，但 utility 计算必须能自动跳过缺失指标并重归一化权重。
4. 如果 deterministic planner 没有 entropy，不要把 prediction error 冒充 uncertainty。可以实现 MC dropout 或 ensemble variance。
5. scaling law 的 pilot 点可能很少，拟合失败时必须 fallback。
6. MOSAIC 选择时必须防止某个 cluster 被取空。
7. 所有选出的 clip 必须来自 D_pool，不能包含 base_train 或 val。
8. 最终结果必须包含每种方法在相同 budget 下的 validation metrics。
9. 所有脚本必须支持 argparse。
10. 不要 hard-code 本地路径。
```
