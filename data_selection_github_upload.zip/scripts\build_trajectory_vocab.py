from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.nuscenes_clips import load_nuscenes
from src.models.trajectory_vocab import fit_trajectory_vocab, save_trajectory_vocab
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Fit a k-means++ trajectory vocabulary for HydraMDP-style planners."
    )
    parser.add_argument("--config", default=None)
    parser.add_argument("--clips", required=True, help="Training/base clip manifest CSV.")
    parser.add_argument("--dataroot", default=None)
    parser.add_argument("--version", default=None)
    parser.add_argument("--num-modes", type=int, default=None)
    parser.add_argument("--out", default="outputs/vocab/trajectory_vocab_64.npy")
    parser.add_argument("--sample-interval-sec", type=float, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    dataset_cfg = cfg.get("dataset", {})
    planner_cfg = cfg.get("planner", {})
    project_cfg = cfg.get("project", {})
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version", "v1.0-mini")
    if not dataroot:
        raise SystemExit("--dataroot is required unless dataset.dataroot is set in --config")

    from src.models.ego_planner_dataset import EgoTrajectoryDataset, PlannerDatasetConfig

    dataset_config = PlannerDatasetConfig(
        past_horizon_sec=float(planner_cfg.get("past_horizon_sec", 2.0)),
        future_horizon_sec=float(planner_cfg.get("future_horizon_sec", 3.0)),
        sample_interval_sec=args.sample_interval_sec
        if args.sample_interval_sec is not None
        else float(planner_cfg.get("sample_interval_sec", 0.5)),
        collision_distance_m=float(planner_cfg.get("collision_distance_m", 2.0)),
        max_windows_per_clip=planner_cfg.get("max_windows_per_clip"),
    )
    nusc = load_nuscenes(dataroot, version, verbose=not args.quiet)
    dataset = EgoTrajectoryDataset(
        args.clips,
        dataroot=dataroot,
        version=version,
        config=dataset_config,
        nusc=nusc,
        verbose=False,
    )
    trajectories = np.stack([record.targets for record in dataset.records], axis=0)
    num_modes = args.num_modes or int(planner_cfg.get("trajectory_vocab_size", 64))
    seed = args.seed if args.seed is not None else int(project_cfg.get("seed", 42))
    vocab = fit_trajectory_vocab(trajectories, num_modes=num_modes, random_state=seed)
    save_trajectory_vocab(
        vocab,
        args.out,
        metadata={
            "source_clips": args.clips,
            "num_training_windows": int(len(trajectories)),
            "requested_num_modes": int(num_modes),
            "random_state": int(seed),
        },
    )
    logger.info("Wrote trajectory vocab: %s", args.out)
    logger.info("Vocab shape: %s", tuple(vocab.shape))


if __name__ == "__main__":
    main()
