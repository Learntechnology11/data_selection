from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


DEFAULT_UTILITY_WEIGHTS = {
    "ade": 30.0,
    "fde": 30.0,
    "heading_error": 10.0,
    "collision_proxy": 15.0,
    "offroad_proxy": 10.0,
    "jerk": 5.0,
}


def robust_normalize(
    series: pd.Series,
    clip_min: float = 0.0,
    clip_max: float = 5.0,
) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce")
    valid = values.dropna()
    if valid.empty:
        return pd.Series(np.nan, index=series.index)
    median = float(valid.median())
    q75 = float(valid.quantile(0.75))
    q25 = float(valid.quantile(0.25))
    iqr = q75 - q25
    if abs(iqr) < 1e-8:
        denom = max(abs(median), 1.0)
        normalized = values / denom
    else:
        normalized = (values - median) / (iqr + 1e-8)
    return normalized.clip(lower=clip_min, upper=clip_max)


def active_weights(frame: pd.DataFrame, weights: dict[str, float]) -> dict[str, float]:
    active: dict[str, float] = {}
    for metric, weight in weights.items():
        if metric not in frame.columns:
            continue
        values = pd.to_numeric(frame[metric], errors="coerce")
        if values.notna().any():
            active[metric] = float(weight)
    total = sum(active.values())
    if total <= 0:
        return {}
    return {metric: weight / total for metric, weight in active.items()}


def compute_utility_from_frame(
    per_clip_metrics: pd.DataFrame,
    utility_cfg: dict[str, Any] | None = None,
) -> tuple[float, dict[str, float]]:
    cfg = utility_cfg or {}
    weights = {
        metric: float(weight)
        for metric, weight in cfg.get("weights", DEFAULT_UTILITY_WEIGHTS).items()
    }
    base_score = float(cfg.get("base_score", 100.0))
    clip_min = float(cfg.get("clip_min", 0.0))
    clip_max = float(cfg.get("clip_max", 5.0))

    normalized_means: dict[str, float] = {}
    penalty = 0.0
    for metric, normalized_weight in active_weights(per_clip_metrics, weights).items():
        normalized = robust_normalize(per_clip_metrics[metric], clip_min, clip_max)
        normalized_mean = float(normalized.mean(skipna=True))
        normalized_means[f"normalized_{metric}"] = normalized_mean
        penalty += normalized_weight * normalized_mean
    return float(base_score - penalty * base_score), normalized_means


def sanitize_metrics_for_json(metrics: dict[str, Any]) -> dict[str, Any]:
    sanitized: dict[str, Any] = {}
    for key, value in metrics.items():
        if isinstance(value, (np.integer,)):
            sanitized[key] = int(value)
        elif isinstance(value, (np.floating, float)):
            sanitized[key] = None if np.isnan(value) else float(value)
        else:
            sanitized[key] = value
    return sanitized
