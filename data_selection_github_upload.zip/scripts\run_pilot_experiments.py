from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.utils.io import ensure_dir, read_csv, read_json, read_yaml, write_csv
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run cluster-wise pilot planner experiments.")
    parser.add_argument("--base-train", required=True)
    parser.add_argument("--val", required=True)
    parser.add_argument("--ranked-pool", required=True)
    parser.add_argument("--pilot-budgets", nargs="+", type=int, required=True)
    parser.add_argument("--mode", choices=["scratch", "finetune"], default="finetune")
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataroot", default=None)
    parser.add_argument("--version", default=None)
    parser.add_argument("--base-checkpoint", default=None)
    parser.add_argument("--base-metrics", default=None)
    parser.add_argument("--base-utility", type=float, default=None)
    parser.add_argument("--seeds", nargs="+", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument(
        "--model-type",
        choices=["mlp", "hydra_mdp_lite", "hydra_mdp_nuscenes"],
        default=None,
    )
    parser.add_argument("--out", default="outputs/pilot/pilot_results.csv")
    parser.add_argument("--work-dir", default="outputs/pilot")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def infer_base_utility(args: argparse.Namespace) -> float:
    if args.base_utility is not None:
        return float(args.base_utility)
    if args.base_metrics:
        metrics = read_json(args.base_metrics)
        return float(metrics["utility"])
    if args.base_checkpoint:
        try:
            import torch

            checkpoint = torch.load(args.base_checkpoint, map_location="cpu")
            return float(checkpoint.get("validation_metrics", {}).get("utility", 0.0))
        except Exception:
            return 0.0
    return 0.0


def combine_train_manifest(base_train: pd.DataFrame, selected: pd.DataFrame) -> pd.DataFrame:
    base_ids = set(base_train["clip_id"].astype(str))
    selected = selected[~selected["clip_id"].astype(str).isin(base_ids)].copy()
    common_cols = [col for col in base_train.columns if col in selected.columns]
    if not common_cols:
        raise ValueError("base_train and selected clips do not share manifest columns")
    combined = pd.concat([base_train, selected[common_cols]], ignore_index=True)
    if combined["clip_id"].duplicated().any():
        raise ValueError("Combined pilot train manifest has duplicate clip_id values")
    return combined


def run_train_command(
    *,
    train_path: Path,
    val_path: str,
    config: str,
    exp_name: str,
    dataroot: str | None,
    version: str | None,
    checkpoint_dir: Path,
    eval_dir: Path,
    mode: str,
    base_checkpoint: str | None,
    epochs: int | None,
    seed: int,
    model_type: str | None,
) -> None:
    cmd = [
        sys.executable,
        "scripts/train_planner.py",
        "--train",
        str(train_path),
        "--val",
        val_path,
        "--config",
        config,
        "--exp-name",
        exp_name,
        "--checkpoint-dir",
        str(checkpoint_dir),
        "--eval-dir",
        str(eval_dir),
        "--seed",
        str(seed),
    ]
    if dataroot:
        cmd.extend(["--dataroot", dataroot])
    if version:
        cmd.extend(["--version", version])
    if epochs is not None:
        cmd.extend(["--epochs", str(epochs)])
    if model_type:
        cmd.extend(["--model-type", model_type])
    if mode == "finetune" and base_checkpoint:
        cmd.extend(["--init-checkpoint", base_checkpoint])
    subprocess.run(cmd, cwd=REPO_ROOT, check=True)


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config)
    dataset_cfg = cfg.get("dataset", {})
    pilot_cfg = cfg.get("pilot", {})
    training_cfg = cfg.get("training", {})
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version")
    if not dataroot:
        raise SystemExit("--dataroot is required unless dataset.dataroot is set in --config")

    base_train = read_csv(args.base_train)
    ranked_pool = read_csv(args.ranked_pool)
    base_utility = infer_base_utility(args)
    seeds = args.seeds or pilot_cfg.get("seeds", [0])
    epochs = args.epochs
    if epochs is None:
        epochs = int(training_cfg.get("finetune_epochs" if args.mode == "finetune" else "base_epochs", 10))

    work_dir = ensure_dir(args.work_dir)
    manifest_dir = ensure_dir(work_dir / "manifests")
    checkpoint_dir = ensure_dir(work_dir / "checkpoints")
    eval_root = ensure_dir(work_dir / "eval")
    rows: list[dict[str, Any]] = []

    for seed in seeds:
        for cluster_id, cluster_frame in ranked_pool.groupby("cluster_id", sort=True):
            ranked_cluster = cluster_frame.sort_values("rank_within_cluster").reset_index(drop=True)
            for requested_n in args.pilot_budgets:
                n = min(int(requested_n), len(ranked_cluster))
                if n <= 0:
                    continue
                selected = ranked_cluster.head(n).copy()
                combined = combine_train_manifest(base_train, selected)
                manifest_path = manifest_dir / f"cluster_{cluster_id}_n_{n}_seed_{seed}.csv"
                write_csv(combined, manifest_path)
                exp_name = f"pilot_cluster_{cluster_id}_n_{n}_seed_{seed}"
                eval_dir = eval_root / exp_name
                run_train_command(
                    train_path=manifest_path,
                    val_path=args.val,
                    config=args.config,
                    exp_name=exp_name,
                    dataroot=dataroot,
                    version=version,
                    checkpoint_dir=checkpoint_dir,
                    eval_dir=eval_dir,
                    mode=args.mode,
                    base_checkpoint=args.base_checkpoint,
                    epochs=epochs,
                    seed=int(seed),
                    model_type=args.model_type,
                )
                metrics = read_json(eval_dir / "metrics.json")
                utility = float(metrics["utility"])
                rows.append(
                    {
                        "cluster_id": cluster_id,
                        "n": n,
                        "seed": seed,
                        "selected_clip_ids": json.dumps(selected["clip_id"].astype(str).tolist()),
                        "utility": utility,
                        "delta_utility": utility - base_utility,
                        "ade": metrics.get("ade"),
                        "fde": metrics.get("fde"),
                        "heading_error": metrics.get("heading_error"),
                        "collision_proxy": metrics.get("collision_proxy"),
                        "offroad_proxy": metrics.get("offroad_proxy"),
                        "jerk": metrics.get("jerk"),
                        "checkpoint_path": str(checkpoint_dir / f"{exp_name}.pt"),
                    }
                )
                logger.info("pilot cluster=%s n=%d seed=%s utility=%.4f", cluster_id, n, seed, utility)

    out_path = Path(args.out)
    write_csv(pd.DataFrame(rows), out_path)
    logger.info("Wrote pilot results: %s", out_path)


if __name__ == "__main__":
    main()
