"""Cross-fitted proxy-model signals and reliability estimation."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

import numpy as np
import torch
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import NearestNeighbors
from torch import nn
from torch.utils.data import DataLoader, Dataset, Subset

from fashion_mnist_coreset.models import SmallFashionCNN
from fashion_mnist_coreset.plots import save_json


@dataclass
class ProxySignals:
    """Model and geometry signals for every train-pool sample."""

    embeddings: np.ndarray
    probabilities: np.ndarray
    losses: np.ndarray
    predicted_labels: np.ndarray
    gradient_embedding: np.ndarray
    fisher_gradient: np.ndarray
    reliability: np.ndarray
    reject_mask: np.ndarray
    class_distance_z: np.ndarray
    neighbor_agreement: np.ndarray
    diagnostics: Dict[str, Any]


def build_proxy_signals(
    dataset: Dataset,
    labels: np.ndarray,
    true_noise_mask: np.ndarray,
    output_dir: Path,
    *,
    epochs: int,
    batch_size: int,
    folds: int,
    seed: int,
    device: str,
    force: bool = False,
) -> ProxySignals:
    """Train cross-fitted proxies, extract embeddings, and estimate reliability."""

    output_dir.mkdir(parents=True, exist_ok=True)
    cache_path = output_dir / "proxy_signals.npz"
    diagnostics_path = output_dir / "proxy_diagnostics.json"
    labels = np.asarray(labels, dtype=np.int64)
    if cache_path.exists() and diagnostics_path.exists() and not force:
        payload = np.load(cache_path)
        import json

        with diagnostics_path.open("r", encoding="utf-8") as f:
            diagnostics = json.load(f)
        cache_valid = (
            int(diagnostics.get("num_samples", -1)) == len(labels)
            and int(diagnostics.get("label_checksum", -1)) == int(np.dot(labels, np.arange(1, len(labels) + 1)) % 2_147_483_647)
        )
        if cache_valid:
            return ProxySignals(
                embeddings=payload["embeddings"],
                probabilities=payload["probabilities"],
                losses=payload["losses"],
                predicted_labels=payload["predicted_labels"],
                gradient_embedding=payload["gradient_embedding"],
                fisher_gradient=payload["fisher_gradient"],
                reliability=payload["reliability"],
                reject_mask=payload["reject_mask"].astype(bool),
                class_distance_z=payload["class_distance_z"],
                neighbor_agreement=payload["neighbor_agreement"],
                diagnostics=diagnostics,
            )
    probabilities = np.zeros((len(labels), 10), dtype=np.float32)
    splitter = StratifiedKFold(n_splits=max(2, int(folds)), shuffle=True, random_state=seed)
    fold_rows = []
    for fold_id, (train_idx, holdout_idx) in enumerate(splitter.split(np.zeros(len(labels)), labels)):
        model = _fit_proxy(
            dataset,
            train_idx,
            epochs=epochs,
            batch_size=batch_size,
            seed=seed + fold_id,
            device=device,
        )
        _, fold_probs = _extract(model, dataset, holdout_idx, batch_size, device)
        probabilities[holdout_idx] = fold_probs
        fold_rows.append(
            {
                "fold": fold_id,
                "train_size": int(len(train_idx)),
                "holdout_size": int(len(holdout_idx)),
                "holdout_accuracy": float(np.mean(fold_probs.argmax(axis=1) == labels[holdout_idx])),
            }
        )

    full_model = _fit_proxy(
        dataset,
        np.arange(len(labels)),
        epochs=epochs,
        batch_size=batch_size,
        seed=seed + 1000,
        device=device,
    )
    embeddings, _ = _extract(full_model, dataset, np.arange(len(labels)), batch_size, device)
    torch.save({"model": full_model.state_dict(), "seed": seed}, output_dir / "proxy_full.pt")

    observed_prob = probabilities[np.arange(len(labels)), labels]
    losses = -np.log(np.maximum(observed_prob, 1e-8))
    predicted = probabilities.argmax(axis=1).astype(np.int64)
    gradient = projected_gradient_embedding(embeddings, probabilities, labels, out_dim=96, seed=seed)
    fisher = fisher_normalize(gradient, rank=min(64, gradient.shape[1]), reg=1e-3)
    reliability_payload = estimate_reliability(
        embeddings,
        probabilities,
        labels,
        true_noise_mask=true_noise_mask,
    )
    diagnostics = {
        "num_samples": int(len(labels)),
        "label_checksum": int(np.dot(labels, np.arange(1, len(labels) + 1)) % 2_147_483_647),
        "proxy_epochs": int(epochs),
        "proxy_folds": int(folds),
        "folds": fold_rows,
        "crossfit_accuracy": float(np.mean(predicted == labels)),
        "mean_loss": float(losses.mean()),
        **reliability_payload["diagnostics"],
    }
    np.savez_compressed(
        cache_path,
        embeddings=embeddings.astype(np.float32),
        probabilities=probabilities.astype(np.float32),
        losses=losses.astype(np.float32),
        predicted_labels=predicted,
        gradient_embedding=gradient.astype(np.float32),
        fisher_gradient=fisher.astype(np.float32),
        reliability=reliability_payload["reliability"].astype(np.float32),
        reject_mask=reliability_payload["reject_mask"].astype(np.uint8),
        class_distance_z=reliability_payload["class_distance_z"].astype(np.float32),
        neighbor_agreement=reliability_payload["neighbor_agreement"].astype(np.float32),
    )
    save_json(diagnostics, diagnostics_path)
    _write_reliability_csv(
        output_dir / "sample_reliability.csv",
        labels,
        true_noise_mask,
        probabilities,
        losses,
        predicted,
        reliability_payload,
    )
    return ProxySignals(
        embeddings=embeddings,
        probabilities=probabilities,
        losses=losses,
        predicted_labels=predicted,
        gradient_embedding=gradient,
        fisher_gradient=fisher,
        reliability=reliability_payload["reliability"],
        reject_mask=reliability_payload["reject_mask"],
        class_distance_z=reliability_payload["class_distance_z"],
        neighbor_agreement=reliability_payload["neighbor_agreement"],
        diagnostics=diagnostics,
    )


def estimate_reliability(
    embeddings: np.ndarray,
    probabilities: np.ndarray,
    labels: np.ndarray,
    *,
    true_noise_mask: np.ndarray,
    neighbors: int = 15,
) -> Dict[str, Any]:
    """Estimate soft reliability and a conservative hard-reject mask."""

    labels = np.asarray(labels, dtype=np.int64)
    normalized = _standardize(embeddings)
    distance_z = np.zeros(len(labels), dtype=np.float64)
    for cls in range(10):
        idx = np.flatnonzero(labels == cls)
        if not len(idx):
            continue
        points = normalized[idx]
        center = np.median(points, axis=0)
        scale = np.median(np.abs(points - center[None, :]), axis=0) * 1.4826
        scale = np.maximum(scale, 0.1)
        distances = np.sqrt(np.mean(((points - center[None, :]) / scale[None, :]) ** 2, axis=1))
        median = float(np.median(distances))
        mad = float(np.median(np.abs(distances - median)) * 1.4826)
        distance_z[idx] = (distances - median) / max(mad, 1e-6)

    k = min(max(3, int(neighbors)), max(len(labels) - 1, 3))
    nn = NearestNeighbors(n_neighbors=min(k + 1, len(labels)), metric="euclidean")
    nn.fit(normalized)
    neighbor_idx = nn.kneighbors(return_distance=False)
    neighbor_agreement = np.zeros(len(labels), dtype=np.float64)
    for idx in range(len(labels)):
        neighbors_i = neighbor_idx[idx]
        neighbors_i = neighbors_i[neighbors_i != idx][:k]
        neighbor_agreement[idx] = float(np.mean(labels[neighbors_i] == labels[idx])) if len(neighbors_i) else 1.0

    p_label = probabilities[np.arange(len(labels)), labels]
    probs_without_label = probabilities.copy()
    probs_without_label[np.arange(len(labels)), labels] = -1.0
    max_other = probs_without_label.max(axis=1)
    predicted = probabilities.argmax(axis=1)
    conflict = np.maximum(max_other - p_label, 0.0)
    distance_risk = 1.0 / (1.0 + np.exp(-(distance_z - 1.5)))
    neighborhood_risk = 1.0 - neighbor_agreement
    uncertainty = 1.0 - probabilities.max(axis=1)
    risk = 1.8 * conflict + 0.8 * distance_risk + 1.0 * neighborhood_risk + 0.4 * uncertainty
    reliability = np.exp(-risk)
    reliability = np.clip(reliability, 0.01, 1.0)

    high_conflict = (predicted != labels) & (probabilities.max(axis=1) >= 0.80)
    corroborated = (distance_z >= 2.0) | (neighbor_agreement <= 0.45)
    reject = (high_conflict & corroborated) | (distance_z >= 4.5) | (reliability <= 0.12)

    true_noise = np.asarray(true_noise_mask, dtype=bool)
    tp = int(np.sum(reject & true_noise))
    fp = int(np.sum(reject & ~true_noise))
    fn = int(np.sum(~reject & true_noise))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    diagnostics = {
        "num_rejected": int(reject.sum()),
        "reject_rate": float(reject.mean()),
        "mean_reliability": float(reliability.mean()),
        "noise_detection_precision": float(precision),
        "noise_detection_recall": float(recall),
        "noise_detection_f1": float(2.0 * precision * recall / max(precision + recall, 1e-12)),
        "true_noise_rate": float(true_noise.mean()),
        "noise_remaining_after_gate": float(np.mean(true_noise[~reject])) if np.any(~reject) else 0.0,
    }
    return {
        "reliability": reliability,
        "reject_mask": reject,
        "class_distance_z": distance_z,
        "neighbor_agreement": neighbor_agreement,
        "diagnostics": diagnostics,
    }


def projected_gradient_embedding(
    embeddings: np.ndarray,
    probabilities: np.ndarray,
    labels: np.ndarray,
    *,
    out_dim: int,
    seed: int,
) -> np.ndarray:
    """Project classification-head gradients to a compact embedding."""

    onehot = np.eye(10, dtype=np.float64)[labels.astype(int)]
    residual = probabilities.astype(np.float64) - onehot
    raw = np.einsum("nc,nd->ncd", residual, embeddings.astype(np.float64)).reshape(len(labels), -1)
    rng = np.random.default_rng(seed + 104729)
    projection = rng.normal(0.0, 1.0 / np.sqrt(out_dim), size=(raw.shape[1], out_dim))
    return raw @ projection


def fisher_normalize(gradient: np.ndarray, *, rank: int, reg: float) -> np.ndarray:
    """Normalize projected gradients in the top empirical-Fisher subspace."""

    centered = gradient - gradient.mean(axis=0, keepdims=True)
    cov = centered.T @ centered / max(len(centered), 1)
    values, vectors = np.linalg.eigh(cov)
    order = np.argsort(values)[::-1][: max(1, min(rank, len(values)))]
    values_q = np.maximum(values[order], 0.0)
    vectors_q = vectors[:, order]
    return centered @ vectors_q / np.sqrt(values_q[None, :] + reg)


def _fit_proxy(
    dataset: Dataset,
    train_indices: Sequence[int],
    *,
    epochs: int,
    batch_size: int,
    seed: int,
    device: str,
) -> SmallFashionCNN:
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = SmallFashionCNN().to(device)
    loader = DataLoader(Subset(dataset, list(train_indices)), batch_size=batch_size, shuffle=True, num_workers=0)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    criterion = nn.CrossEntropyLoss()
    for _ in range(int(epochs)):
        model.train()
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(images), labels)
            loss.backward()
            optimizer.step()
    return model


def _extract(
    model: SmallFashionCNN,
    dataset: Dataset,
    indices: Sequence[int],
    batch_size: int,
    device: str,
) -> tuple[np.ndarray, np.ndarray]:
    loader = DataLoader(Subset(dataset, list(indices)), batch_size=batch_size, shuffle=False, num_workers=0)
    embeddings = []
    probabilities = []
    model.eval()
    with torch.no_grad():
        for images, _ in loader:
            images = images.to(device)
            feature = model.forward_features(images)
            logits = model.classifier(feature)
            embeddings.append(feature.cpu().numpy())
            probabilities.append(torch.softmax(logits, dim=1).cpu().numpy())
    return np.concatenate(embeddings, axis=0), np.concatenate(probabilities, axis=0)


def _standardize(values: np.ndarray) -> np.ndarray:
    centered = values - values.mean(axis=0, keepdims=True)
    return centered / np.maximum(values.std(axis=0, keepdims=True), 1e-6)


def _write_reliability_csv(
    path: Path,
    labels: np.ndarray,
    true_noise: np.ndarray,
    probabilities: np.ndarray,
    losses: np.ndarray,
    predicted: np.ndarray,
    payload: Mapping[str, Any],
) -> None:
    fieldnames = [
        "index",
        "label",
        "predicted",
        "max_probability",
        "label_probability",
        "loss",
        "class_distance_z",
        "neighbor_agreement",
        "reliability",
        "rejected",
        "true_noise",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for idx in range(len(labels)):
            writer.writerow(
                {
                    "index": idx,
                    "label": int(labels[idx]),
                    "predicted": int(predicted[idx]),
                    "max_probability": float(probabilities[idx].max()),
                    "label_probability": float(probabilities[idx, labels[idx]]),
                    "loss": float(losses[idx]),
                    "class_distance_z": float(payload["class_distance_z"][idx]),
                    "neighbor_agreement": float(payload["neighbor_agreement"][idx]),
                    "reliability": float(payload["reliability"][idx]),
                    "rejected": int(payload["reject_mask"][idx]),
                    "true_noise": int(true_noise[idx]),
                }
            )


__all__ = ["ProxySignals", "build_proxy_signals", "estimate_reliability"]
