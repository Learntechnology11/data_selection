from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from src.utils.io import ensure_parent, write_json


def load_trajectory_vocab(path: str | Path) -> np.ndarray:
    vocab = np.load(path).astype(np.float32)
    if vocab.ndim == 2:
        if vocab.shape[1] % 2 != 0:
            raise ValueError(f"Invalid flattened trajectory vocab shape: {vocab.shape}")
        vocab = vocab.reshape(vocab.shape[0], vocab.shape[1] // 2, 2)
    if vocab.ndim != 3 or vocab.shape[-1] != 2:
        raise ValueError(f"Expected trajectory vocab shape (K, T, 2), got {vocab.shape}")
    return vocab.astype(np.float32)


def nearest_trajectory_class(target: np.ndarray, vocab: np.ndarray) -> int:
    target_flat = target.reshape(1, -1)
    vocab_flat = vocab.reshape(vocab.shape[0], -1)
    distances = np.linalg.norm(vocab_flat - target_flat, axis=1)
    return int(distances.argmin())


def fit_trajectory_vocab(
    trajectories: np.ndarray,
    num_modes: int,
    random_state: int = 42,
) -> np.ndarray:
    if trajectories.ndim != 3 or trajectories.shape[-1] != 2:
        raise ValueError(f"Expected trajectories shape (N, T, 2), got {trajectories.shape}")
    if len(trajectories) == 0:
        raise ValueError("Cannot fit trajectory vocab from zero trajectories")
    n_clusters = min(int(num_modes), len(trajectories))
    flat = trajectories.reshape(len(trajectories), -1)
    from sklearn.cluster import KMeans

    labels = KMeans(
        n_clusters=n_clusters,
        init="k-means++",
        n_init=10,
        random_state=random_state,
    ).fit(flat)
    centers = labels.cluster_centers_.reshape(n_clusters, trajectories.shape[1], 2)
    return centers.astype(np.float32)


def save_trajectory_vocab(
    vocab: np.ndarray,
    out_path: str | Path,
    metadata: dict[str, Any] | None = None,
) -> None:
    output = ensure_parent(out_path)
    np.save(output, vocab.astype(np.float32))
    meta = {
        "num_modes": int(vocab.shape[0]),
        "future_steps": int(vocab.shape[1]),
        "path": str(output),
    }
    if metadata:
        meta.update(metadata)
    write_json(meta, output.with_suffix(".json"))
