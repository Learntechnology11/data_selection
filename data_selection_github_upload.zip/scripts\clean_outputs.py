from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]


DEFAULT_OUTPUT_DIRS = [
    "analysis",
    "checkpoints",
    "clips",
    "clusters",
    "eval",
    "features",
    "pilot",
    "ranking",
    "results",
    "scaling",
    "selections",
    "splits",
    "vocab",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Safely remove generated MOSAIC outputs.")
    parser.add_argument("--output-root", default="outputs")
    parser.add_argument("--dirs", nargs="*", default=DEFAULT_OUTPUT_DIRS)
    parser.add_argument("--yes", action="store_true", help="Actually remove files.")
    return parser.parse_args()


def assert_inside_repo(path: Path) -> None:
    resolved = path.resolve()
    repo = REPO_ROOT.resolve()
    if resolved == repo:
        raise ValueError("Refusing to remove repository root")
    if repo not in resolved.parents:
        raise ValueError(f"Refusing to remove path outside repository: {resolved}")


def remove_path(path: Path) -> None:
    assert_inside_repo(path)
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def main() -> None:
    args = parse_args()
    output_root = (REPO_ROOT / args.output_root).resolve()
    assert_inside_repo(output_root)
    targets = [output_root / name for name in args.dirs]
    existing = [target for target in targets if target.exists()]

    if not existing:
        print(f"No generated output directories found under {output_root}")
        return

    print("Generated output directories to remove:")
    for target in existing:
        print(f"  {target}")

    if not args.yes:
        print("Dry run only. Re-run with --yes to remove these directories.")
        return

    for target in existing:
        remove_path(target)
    output_root.mkdir(parents=True, exist_ok=True)
    print(f"Cleaned {len(existing)} output directories under {output_root}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"clean_outputs.py failed: {exc}", file=sys.stderr)
        raise
