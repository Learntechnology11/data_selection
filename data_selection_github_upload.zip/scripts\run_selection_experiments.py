from __future__ import annotations

import argparse
import math
import subprocess
import sys
from pathlib import Path
from typing import Any

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.selection.baselines import (
    save_baseline_selection,
    select_cluster_only,
    select_coreset,
    select_full,
    select_random,
    select_ranking_only,
    select_uncertainty,
)
from src.selection.mosaic import save_mosaic_outputs, select_mosaic
from src.utils.io import ensure_dir, read_csv, read_json, read_yaml, write_csv
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the full MOSAIC selection experiment loop.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--budgets", nargs="+", type=int, default=None)
    parser.add_argument("--budget-ratios", nargs="+", default=None)
    parser.add_argument("--methods", nargs="+", required=True)
    parser.add_argument("--seeds", nargs="+", type=int, required=True)
    parser.add_argument("--base-train", default="outputs/splits/base_train.csv")
    parser.add_argument("--val", default="outputs/splits/val.csv")
    parser.add_argument("--pool", default="outputs/splits/pool.csv")
    parser.add_argument("--features", default="outputs/features/clip_features.parquet")
    parser.add_argument("--ranked-pool", default="outputs/ranking/cluster_ranked_pool.csv")
    parser.add_argument("--scaling-params", default="outputs/scaling/scaling_params.json")
    parser.add_argument("--dataroot", default=None)
    parser.add_argument("--version", default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument(
        "--model-type",
        choices=["mlp", "hydra_mdp_lite", "hydra_mdp_nuscenes"],
        default=None,
    )
    parser.add_argument("--out-dir", default="outputs/results")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def parse_budget_ratio(value: str) -> float:
    text = str(value).strip()
    if text.endswith("%"):
        ratio = float(text[:-1]) / 100.0
    else:
        ratio = float(text)
        if ratio > 1.0:
            ratio = ratio / 100.0
    if ratio <= 0:
        raise ValueError(f"Budget ratio must be positive: {value}")
    return min(ratio, 1.0)


def resolve_budget_specs(args: argparse.Namespace, pool_size: int) -> list[dict[str, float | int | str]]:
    if args.budgets is None and args.budget_ratios is None:
        raise ValueError("Either --budgets or --budget-ratios is required")
    specs: list[dict[str, float | int | str]] = []
    if args.budgets is not None:
        for budget in args.budgets:
            if budget <= 0:
                raise ValueError(f"Budget must be positive: {budget}")
            resolved = min(int(budget), pool_size)
            specs.append(
                {
                    "budget": resolved,
                    "budget_ratio": float(resolved) / float(pool_size),
                    "budget_percent": 100.0 * float(resolved) / float(pool_size),
                    "budget_source": "count",
                    "requested_budget": int(budget),
                }
            )
    if args.budget_ratios is not None:
        for raw_ratio in args.budget_ratios:
            ratio = parse_budget_ratio(str(raw_ratio))
            budget = min(pool_size, max(1, int(math.ceil(pool_size * ratio))))
            specs.append(
                {
                    "budget": budget,
                    "budget_ratio": float(budget) / float(pool_size),
                    "budget_percent": 100.0 * float(budget) / float(pool_size),
                    "budget_source": "ratio",
                    "requested_budget_ratio": ratio,
                    "requested_budget_percent": ratio * 100.0,
                }
            )

    deduped: list[dict[str, float | int | str]] = []
    seen: set[int] = set()
    for spec in sorted(specs, key=lambda item: int(item["budget"])):
        budget = int(spec["budget"])
        if budget not in seen:
            deduped.append(spec)
            seen.add(budget)
    return deduped


def combine_manifest(base_train: pd.DataFrame, selected: pd.DataFrame) -> pd.DataFrame:
    common_cols = [col for col in base_train.columns if col in selected.columns]
    combined = pd.concat([base_train, selected[common_cols]], ignore_index=True)
    if combined["clip_id"].duplicated().any():
        combined = combined.drop_duplicates("clip_id", keep="first")
    return combined


def train_and_collect(
    *,
    train_manifest: Path,
    val_path: str,
    config: str,
    exp_name: str,
    dataroot: str | None,
    version: str | None,
    epochs: int | None,
    seed: int,
    model_type: str | None,
    checkpoint_dir: Path,
    eval_dir: Path,
) -> dict[str, Any]:
    cmd = [
        sys.executable,
        "scripts/train_planner.py",
        "--train",
        str(train_manifest),
        "--val",
        val_path,
        "--config",
        config,
        "--exp-name",
        exp_name,
        "--checkpoint-dir",
        str(checkpoint_dir),
        "--eval-dir",
        str(eval_dir),
        "--seed",
        str(seed),
    ]
    if dataroot:
        cmd.extend(["--dataroot", dataroot])
    if version:
        cmd.extend(["--version", version])
    if epochs is not None:
        cmd.extend(["--epochs", str(epochs)])
    if model_type:
        cmd.extend(["--model-type", model_type])
    subprocess.run(cmd, cwd=REPO_ROOT, check=True)
    return read_json(eval_dir / "metrics.json")


def select_method(
    method: str,
    budget: int,
    seed: int,
    pool: pd.DataFrame,
    ranked_pool: pd.DataFrame,
    feature_frame: pd.DataFrame | None,
    scaling_params: dict[str, Any],
) -> pd.DataFrame:
    if method == "random":
        return select_random(pool, budget, seed)
    if method == "full":
        return select_full(pool, seed)
    if method == "coreset":
        if feature_frame is None:
            raise ValueError("coreset needs feature_frame")
        return select_coreset(pool, feature_frame, budget, seed)
    if method == "ranking_only":
        return select_ranking_only(ranked_pool, budget, seed)
    if method == "cluster_only":
        return select_cluster_only(ranked_pool, budget, seed)
    if method == "uncertainty":
        return select_uncertainty(ranked_pool, budget, seed)
    if method == "mosaic":
        selected, _ = select_mosaic(ranked_pool, scaling_params, budget)
        selected["seed"] = seed
        return selected
    raise ValueError(f"Unsupported method: {method}")


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config)
    dataset_cfg = cfg.get("dataset", {})
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version")
    base_train = read_csv(args.base_train)
    pool = read_csv(args.pool)
    ranked_pool = read_csv(args.ranked_pool)
    pool_size = len(pool)
    budget_specs = resolve_budget_specs(args, pool_size)
    scaling_params = read_json(args.scaling_params) if Path(args.scaling_params).exists() else {}
    feature_frame = None
    if Path(args.features).exists():
        feature_frame = pd.read_parquet(args.features) if args.features.endswith(".parquet") else read_csv(args.features)

    out_dir = ensure_dir(args.out_dir)
    selection_dir = ensure_dir("outputs/selections")
    manifest_dir = ensure_dir(out_dir / "train_manifests")
    checkpoint_dir = ensure_dir("outputs/checkpoints")
    result_rows: list[dict[str, Any]] = []
    distribution_rows: list[dict[str, Any]] = []
    completed_full_seeds: set[int] = set()

    for budget_spec in budget_specs:
        budget = int(budget_spec["budget"])
        for method in args.methods:
            for seed in args.seeds:
                if method == "full" and seed in completed_full_seeds:
                    continue
                selected = select_method(
                    method,
                    budget,
                    seed,
                    pool,
                    ranked_pool,
                    feature_frame,
                    scaling_params,
                )
                actual_budget = len(selected)
                actual_budget_ratio = float(actual_budget) / float(pool_size)
                actual_budget_percent = 100.0 * actual_budget_ratio
                if method == "mosaic":
                    selected, trace = select_mosaic(ranked_pool, scaling_params, budget)
                    selected["seed"] = seed
                    save_mosaic_outputs(selected, trace, budget, selection_dir)
                    actual_budget = len(selected)
                    actual_budget_ratio = float(actual_budget) / float(pool_size)
                    actual_budget_percent = 100.0 * actual_budget_ratio
                else:
                    save_baseline_selection(selected, method, actual_budget, seed, selection_dir)
                if "cluster_id" in selected.columns:
                    for cluster_id, count in selected["cluster_id"].value_counts().sort_index().items():
                        distribution_rows.append(
                            {
                                "method": method,
                                "budget": actual_budget,
                                "budget_ratio": actual_budget_ratio,
                                "budget_percent": actual_budget_percent,
                                "seed": seed,
                                "cluster_id": cluster_id,
                                "num_selected": int(count),
                                "ratio_selected": float(count) / float(actual_budget),
                            }
                        )
                train_manifest = combine_manifest(base_train, selected)
                train_path = manifest_dir / f"{method}_budget_{actual_budget}_seed_{seed}.csv"
                write_csv(train_manifest, train_path)
                exp_name = f"{method}_budget_{actual_budget}_seed_{seed}"
                eval_dir = Path("outputs") / "eval" / exp_name
                metrics = train_and_collect(
                    train_manifest=train_path,
                    val_path=args.val,
                    config=args.config,
                    exp_name=exp_name,
                    dataroot=dataroot,
                    version=version,
                    epochs=args.epochs,
                    seed=seed,
                    model_type=args.model_type,
                    checkpoint_dir=checkpoint_dir,
                    eval_dir=eval_dir,
                )
                row = {
                    "dataset_version": version,
                    "method": method,
                    "budget": actual_budget,
                    "budget_ratio": actual_budget_ratio,
                    "budget_percent": actual_budget_percent,
                    "pool_size": pool_size,
                    "requested_budget": budget,
                    "requested_budget_ratio": budget_spec.get("requested_budget_ratio"),
                    "requested_budget_percent": budget_spec.get("requested_budget_percent"),
                    "seed": seed,
                    "utility": metrics.get("utility"),
                    "ade": metrics.get("ade"),
                    "fde": metrics.get("fde"),
                    "heading_error": metrics.get("heading_error"),
                    "collision_proxy": metrics.get("collision_proxy"),
                    "offroad_proxy": metrics.get("offroad_proxy"),
                    "jerk": metrics.get("jerk"),
                }
                result_rows.append(row)
                if method == "full":
                    completed_full_seeds.add(seed)
                logger.info(
                    "method=%s budget=%d budget_percent=%.2f seed=%d utility=%s",
                    method,
                    actual_budget,
                    actual_budget_percent,
                    seed,
                    row["utility"],
                )

    results = pd.DataFrame(result_rows)
    write_csv(results, out_dir / "main_results.csv")
    if distribution_rows:
        write_csv(pd.DataFrame(distribution_rows), out_dir / "cluster_distribution.csv")
    metric_cols = [
        "utility",
        "ade",
        "fde",
        "heading_error",
        "collision_proxy",
        "offroad_proxy",
        "jerk",
    ]
    breakdown = results.melt(
        id_vars=[
            "dataset_version",
            "method",
            "budget",
            "budget_ratio",
            "budget_percent",
            "pool_size",
            "seed",
        ],
        value_vars=[col for col in metric_cols if col in results.columns],
        var_name="metric",
        value_name="value",
    )
    write_csv(breakdown, out_dir / "metric_breakdown.csv")
    logger.info("Wrote main results: %s", out_dir / "main_results.csv")


if __name__ == "__main__":
    main()
