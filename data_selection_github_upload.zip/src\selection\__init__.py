"""Selection, clustering, and MOSAIC helpers."""
