from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from src.utils.io import ensure_dir, write_csv


def _finalize(df: pd.DataFrame, method: str, budget: int, seed: int) -> pd.DataFrame:
    out = df.head(budget).copy().reset_index(drop=True)
    if len(out) != budget:
        raise ValueError(f"{method} selected {len(out)} clips, expected {budget}")
    out["selection_order"] = np.arange(1, budget + 1)
    out["method"] = method
    out["budget"] = budget
    out["seed"] = seed
    return out


def select_random(pool: pd.DataFrame, budget: int, seed: int) -> pd.DataFrame:
    if budget > len(pool):
        raise ValueError("budget cannot exceed pool size")
    return _finalize(pool.sample(n=budget, random_state=seed), "random", budget, seed)


def select_full(pool: pd.DataFrame, seed: int) -> pd.DataFrame:
    return _finalize(pool.copy(), "full", len(pool), seed)


def select_ranking_only(ranked_pool: pd.DataFrame, budget: int, seed: int) -> pd.DataFrame:
    ranked = ranked_pool.sort_values(["importance_score", "clip_id"], ascending=[False, True])
    return _finalize(ranked, "ranking_only", budget, seed)


def select_uncertainty(ranked_pool: pd.DataFrame, budget: int, seed: int) -> pd.DataFrame:
    if "uncertainty_entropy" not in ranked_pool.columns:
        raise ValueError("uncertainty baseline needs uncertainty_entropy from planner logits")
    ranked = ranked_pool.sort_values(["uncertainty_entropy", "clip_id"], ascending=[False, True])
    return _finalize(ranked, "uncertainty", budget, seed)


def select_cluster_only(ranked_pool: pd.DataFrame, budget: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    clusters = sorted(ranked_pool["cluster_id"].unique().tolist())
    selected: list[pd.Series] = []
    used: set[str] = set()
    while len(selected) < budget:
        progressed = False
        for cluster_id in clusters:
            frame = ranked_pool[ranked_pool["cluster_id"] == cluster_id]
            candidates = frame[~frame["clip_id"].astype(str).isin(used)]
            if candidates.empty:
                continue
            row = candidates.iloc[int(rng.integers(0, len(candidates)))].copy()
            used.add(str(row["clip_id"]))
            selected.append(row)
            progressed = True
            if len(selected) == budget:
                break
        if not progressed:
            break
    return _finalize(pd.DataFrame(selected), "cluster_only", budget, seed)


def select_coreset(
    pool: pd.DataFrame,
    feature_frame: pd.DataFrame,
    budget: int,
    seed: int,
) -> pd.DataFrame:
    if budget > len(pool):
        raise ValueError("budget cannot exceed pool size")
    features = pool[["clip_id"]].merge(feature_frame, on="clip_id", how="left")
    numeric_cols = [
        col
        for col in features.columns
        if col != "clip_id" and pd.api.types.is_numeric_dtype(features[col])
    ]
    if not numeric_cols:
        raise ValueError("coreset baseline needs numeric feature columns")
    matrix = features[numeric_cols].copy()
    for col in numeric_cols:
        median = matrix[col].median(skipna=True)
        matrix[col] = matrix[col].fillna(0.0 if pd.isna(median) else median)
    x = matrix.to_numpy(dtype=np.float64)
    x = (x - x.mean(axis=0, keepdims=True)) / (x.std(axis=0, keepdims=True) + 1e-8)
    rng = np.random.default_rng(seed)
    selected_idx = [int(rng.integers(0, len(x)))]
    min_dist = np.linalg.norm(x - x[selected_idx[0]][None, :], axis=1)
    while len(selected_idx) < budget:
        idx = int(np.argmax(min_dist))
        selected_idx.append(idx)
        min_dist = np.minimum(min_dist, np.linalg.norm(x - x[idx][None, :], axis=1))
    selected_ids = features.iloc[selected_idx]["clip_id"].tolist()
    selected = pool.set_index("clip_id").loc[selected_ids].reset_index()
    return _finalize(selected, "coreset", budget, seed)


def save_baseline_selection(selection: pd.DataFrame, method: str, budget: int, seed: int, out_dir: str | Path) -> Path:
    output_dir = ensure_dir(out_dir)
    path = output_dir / f"{method}_budget_{budget}_seed_{seed}.csv"
    write_csv(selection, path)
    return path
