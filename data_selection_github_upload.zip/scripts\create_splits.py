from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.splits import SplitConfig, create_and_save_splits
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Split clip manifests into base_train, pool, and val CSV files."
    )
    parser.add_argument("--config", type=str, default=None, help="Optional YAML config path.")
    parser.add_argument("--clips", type=str, default=None, help="Input clips CSV.")
    parser.add_argument("--mode", choices=["auto", "mini_random", "official_trainval"], default=None)
    parser.add_argument("--base-ratio", type=float, default=None)
    parser.add_argument("--pool-ratio", type=float, default=None)
    parser.add_argument("--base-ratio-within-train", type=float, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--out-dir", type=str, default="outputs/splits")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    split_cfg = cfg.get("split", {})

    clips_path = args.clips or split_cfg.get("clips")
    if not clips_path:
        raise SystemExit("--clips is required unless split.clips is provided by --config")

    config = SplitConfig(
        mode=args.mode or split_cfg.get("mode", "auto"),
        base_ratio=args.base_ratio
        if args.base_ratio is not None
        else float(split_cfg.get("base_ratio", 0.2)),
        pool_ratio=args.pool_ratio
        if args.pool_ratio is not None
        else float(split_cfg.get("pool_ratio", 0.6)),
        base_ratio_within_train=args.base_ratio_within_train
        if args.base_ratio_within_train is not None
        else float(split_cfg.get("base_ratio_within_train", 0.1)),
        seed=args.seed if args.seed is not None else int(split_cfg.get("seed", 42)),
    )
    splits = create_and_save_splits(clips_path, args.out_dir, config)
    for name, frame in splits.items():
        logger.info("Wrote %s: %d clips", name, len(frame))


if __name__ == "__main__":
    main()
