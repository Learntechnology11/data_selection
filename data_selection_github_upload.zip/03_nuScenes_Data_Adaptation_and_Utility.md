# nuScenes 数据适配与 Utility 设计

## 1. 数据集适配原则

nuScenes 与论文中的 OpenScene/Navtrain 不同。因此，本项目只复现 MOSAIC 的数据选择机制，不能强行复现 NAVSIM 的 EPDMS。

适配目标：

```text
nuScenes scene -> 10s virtual clip -> cluster/rank/select -> train planner -> evaluate open-loop utility
```

## 2. 10 秒 clip 构建

nuScenes 的 scene 大约 20 秒。建议每个 scene 切成两个非重叠 10 秒 clip：

```text
clip 1: 0s - 10s
clip 2: 10s - 20s
```

如果某个 clip 不足指定关键帧数量，则丢弃。

### 2.1 clip manifest 字段

输出：

```text
outputs/clips/nuscenes_{version}_clips.csv
```

字段：

```text
clip_id
scene_token
log_token
location
description
start_sample_token
end_sample_token
sample_tokens
num_samples
split
is_train_pool_candidate
```

### 2.2 clip_id 建议格式

```text
{scene_name}_clip_{index}
```

例如：

```text
scene-0061_clip_0
scene-0061_clip_1
```

## 3. Split 设计

### 3.1 v1.0-mini

由于 mini 数据量较小，使用随机 split：

```text
base_train: 20%
pool:       60%
val:        20%
```

必须使用固定 seed。

输出：

```text
outputs/splits/base_train.csv
outputs/splits/pool.csv
outputs/splits/val.csv
```

### 3.2 v1.0-trainval

优先使用官方 train/val scene split。

```text
official train scenes -> base_train + pool
official val scenes   -> val
```

## 4. Feature extraction

特征用途：

```text
1. clustering
2. coreset baseline
3. sample analysis
```

### 4.1 Metadata features

```text
location one-hot
scene description TF-IDF
```

### 4.2 Ego-motion features

从 ego_pose 序列计算：

```text
mean_speed
max_speed
mean_acceleration
max_acceleration
mean_yaw_rate
max_yaw_rate
total_displacement
```

速度近似：

```math
v_t = \frac{\|p_t - p_{t-1}\|_2}{\Delta t}
```

加速度近似：

```math
a_t = \frac{v_t - v_{t-1}}{\Delta t}
```

yaw rate 近似：

```math
\omega_t = \frac{yaw_t - yaw_{t-1}}{\Delta t}
```

需要注意 yaw angle unwrap。

### 4.3 Agent-density features

从 sample_annotation 统计：

```text
mean_num_agents
mean_num_vehicles
mean_num_pedestrians
max_num_agents
min_distance_to_agent
mean_distance_to_nearest_agent
```

### 4.4 Map proxy features，可选

如果 nuScenes map API 可用：

```text
near_intersection
near_crosswalk
near_lane_divider
lane_count_nearby
is_offroad_ratio_ground_truth
```

如果暂时实现困难，可以先设置为 optional。

## 5. Clustering 方案

### 5.1 location clustering

直接按 `location` 分组。

优点：

```text
简单、稳定、可解释，类似论文中的 geolocation clustering。
```

缺点：

```text
nuScenes location 数量有限，cluster 内部仍然混杂。
```

### 5.2 KMeans clustering

输入：

```text
location one-hot + description TF-IDF + ego-motion + agent-density
```

推荐：

```text
mini: M = 4
trainval: M = 6 or 8
```

输出：

```text
outputs/clusters/cluster_assignments.csv
outputs/clusters/cluster_summary.csv
```

## 6. Planner 输入输出设计

第一版使用轻量 open-loop planner。

### 6.1 输入

```text
past ego states over H_past frames:
  x, y, yaw, speed

optional:
  clip-level features
  agent-density features
  map proxy features
```

### 6.2 输出

```text
future ego trajectory over H_future frames:
  future x/y offsets in ego-centric coordinate
```

### 6.3 推荐模型

```text
MLPPlanner: 简单、易跑通
GRUPlanner: 更适合序列，但稍复杂
```

第一版建议优先 MLPPlanner。

## 7. Evaluation metrics

### 7.1 ADE

```math
ADE = \frac{1}{T}\sum_{t=1}^{T}\|\hat{p}_t - p_t\|_2
```

### 7.2 FDE

```math
FDE = \|\hat{p}_T - p_T\|_2
```

### 7.3 heading error

如果模型预测 heading，则直接计算。否则可用预测轨迹末端方向近似：

```math
\hat{yaw}_T = atan2(\hat{y}_T - \hat{y}_{T-1}, \hat{x}_T - \hat{x}_{T-1})
```

### 7.4 collision proxy

简单近似：

```text
如果预测轨迹点与任意 agent box center 的距离小于阈值，则认为存在 collision risk。
```

建议阈值：

```text
vehicle: 2.0m
pedestrian: 1.0m
```

第一版可以使用 center distance，后续再升级为 box overlap。

### 7.5 off-road proxy

如果 map API 可用：判断预测点是否在 drivable area。

如果暂时不可用：

```text
offroad_proxy = NaN
```

utility 计算时自动跳过。

### 7.6 jerk

根据预测轨迹计算三阶差分，衡量平滑性。

## 8. Utility 计算

定义 higher-is-better utility：

```text
U = 100 - weighted_penalty
```

其中：

```text
weighted_penalty =
  w_ade * normalized_ADE
+ w_fde * normalized_FDE
+ w_heading * normalized_heading_error
+ w_collision * normalized_collision_proxy
+ w_offroad * normalized_offroad_proxy
+ w_jerk * normalized_jerk
```

默认权重：

```yaml
utility_weights:
  ade: 30
  fde: 30
  heading_error: 10
  collision_proxy: 15
  offroad_proxy: 10
  jerk: 5
```

## 9. 指标归一化

推荐 robust normalization：

```math
x_{norm} = \frac{x - median(x)}{IQR(x) + \epsilon}
```

然后 clip：

```text
x_norm = clip(x_norm, 0, 5)
```

为了让 utility 稳定，也可以使用 config 中固定 normalization constants。

## 10. Pool importance score

对每个 pool clip，用 base planner 计算 clip-level metrics，再得到 importance：

```text
importance =
  0.35 * normalized_ADE
+ 0.35 * normalized_FDE
+ 0.10 * normalized_heading_error
+ 0.10 * normalized_collision_proxy
+ 0.10 * normalized_offroad_proxy
```

如果 offroad_proxy 不可用，则重新归一化其余权重。

## 11. Pilot experiments

对每个 cluster：

```text
n in pilot_budgets
选取该 cluster 内 importance 最高的 top-n clips
D_train_i_n = D_train_base + top-n clips
训练或 fine-tune planner
在 D_val 上评估 utility
Delta_U_i(n) = U_i(n) - U_base
```

mini 推荐：

```text
pilot_budgets = [5, 10, 20]
```

trainval 推荐：

```text
pilot_budgets = [50, 100, 200]
```

## 12. 结果解释方式

如果 MOSAIC 有效，预期现象是：

```text
1. MOSAIC 在相同 budget 下 utility 高于 Random；
2. MOSAIC 的 cluster distribution 不是均匀的，而是向高收益 cluster 倾斜；
3. 早期偏向快速增长 cluster，后期转向收益更持久的 cluster；
4. Ranking-only 在低预算可能较强，但高预算可能不如 MOSAIC；
5. Cluster-only 说明 scaling allocation 有用，但 cluster 内 ranking 也重要。
```
