from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.selection.mosaic import save_mosaic_outputs, select_mosaic
from src.utils.io import read_csv, read_json
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Select clips with scaling-aware MOSAIC.")
    parser.add_argument("--ranked-pool", required=True)
    parser.add_argument("--scaling-params", required=True)
    parser.add_argument("--budget", type=int, required=True)
    parser.add_argument("--step", type=int, default=1)
    parser.add_argument("--out-dir", default="outputs/selections")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    ranked_pool = read_csv(args.ranked_pool)
    scaling_params = read_json(args.scaling_params)
    selected, trace = select_mosaic(ranked_pool, scaling_params, args.budget, args.step)
    save_mosaic_outputs(selected, trace, args.budget, args.out_dir)
    logger.info("Wrote MOSAIC selection with %d clips", len(selected))


if __name__ == "__main__":
    main()
