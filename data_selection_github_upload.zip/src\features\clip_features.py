from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.data.nuscenes_clips import load_nuscenes
from src.utils.io import ensure_dir, parse_json_list, read_csv, write_json


ID_COLUMNS = {"clip_id", "location", "description"}
RAW_NUMERIC_COLUMNS = [
    "num_samples",
    "mean_speed",
    "max_speed",
    "mean_acceleration",
    "max_acceleration",
    "mean_yaw_rate",
    "max_yaw_rate",
    "total_displacement",
    "mean_num_agents",
    "mean_num_vehicles",
    "mean_num_pedestrians",
    "max_num_agents",
    "min_distance_to_agent",
    "mean_distance_to_nearest_agent",
]


@dataclass(frozen=True)
class FeatureConfig:
    dataroot: str
    version: str
    use_location: bool = True
    use_description_tfidf: bool = True
    tfidf_max_features: int = 256
    use_ego_motion: bool = True
    use_agent_density: bool = True
    fill_nan: str = "median"
    verbose: bool = True


def _sample_ego_pose(nusc: Any, sample: dict[str, Any]) -> dict[str, Any] | None:
    data = sample.get("data", {})
    sample_data_token = data.get("LIDAR_TOP") or next(iter(data.values()), None)
    if not sample_data_token:
        return None
    sample_data = nusc.get("sample_data", sample_data_token)
    return nusc.get("ego_pose", sample_data["ego_pose_token"])


def _yaw_from_rotation(rotation: list[float]) -> float:
    from pyquaternion import Quaternion

    return float(Quaternion(rotation).yaw_pitch_roll[0])


def _clip_pose_sequence(nusc: Any, sample_tokens: list[str]) -> list[dict[str, float]]:
    poses: list[dict[str, float]] = []
    for token in sample_tokens:
        sample = nusc.get("sample", token)
        ego_pose = _sample_ego_pose(nusc, sample)
        if ego_pose is None:
            continue
        translation = ego_pose["translation"]
        poses.append(
            {
                "timestamp": float(sample["timestamp"]) / 1_000_000.0,
                "x": float(translation[0]),
                "y": float(translation[1]),
                "yaw": _yaw_from_rotation(ego_pose["rotation"]),
            }
        )
    poses.sort(key=lambda item: item["timestamp"])
    return poses


def _nanmean(values: np.ndarray) -> float:
    if values.size == 0:
        return float("nan")
    return float(np.nanmean(values))


def _nanmax(values: np.ndarray) -> float:
    if values.size == 0:
        return float("nan")
    return float(np.nanmax(values))


def compute_ego_motion_features(nusc: Any, sample_tokens: list[str]) -> dict[str, float]:
    poses = _clip_pose_sequence(nusc, sample_tokens)
    if len(poses) < 2:
        return {
            "mean_speed": 0.0,
            "max_speed": 0.0,
            "mean_acceleration": 0.0,
            "max_acceleration": 0.0,
            "mean_yaw_rate": 0.0,
            "max_yaw_rate": 0.0,
            "total_displacement": 0.0,
        }

    timestamps = np.asarray([pose["timestamp"] for pose in poses], dtype=np.float64)
    xy = np.asarray([[pose["x"], pose["y"]] for pose in poses], dtype=np.float64)
    yaws = np.unwrap(np.asarray([pose["yaw"] for pose in poses], dtype=np.float64))

    dt = np.diff(timestamps)
    valid = dt > 1e-6
    if not valid.any():
        return {
            "mean_speed": 0.0,
            "max_speed": 0.0,
            "mean_acceleration": 0.0,
            "max_acceleration": 0.0,
            "mean_yaw_rate": 0.0,
            "max_yaw_rate": 0.0,
            "total_displacement": 0.0,
        }

    distances = np.linalg.norm(np.diff(xy, axis=0), axis=1)[valid]
    dt_valid = dt[valid]
    speeds = distances / dt_valid
    yaw_rates = np.abs(np.diff(yaws)[valid] / dt_valid)
    if speeds.size >= 2:
        speed_times = timestamps[1:][valid]
        speed_dt = np.diff(speed_times)
        speed_dt = np.where(speed_dt > 1e-6, speed_dt, np.nan)
        accelerations = np.abs(np.diff(speeds) / speed_dt)
    else:
        accelerations = np.asarray([], dtype=np.float64)

    total_displacement = float(np.linalg.norm(xy[-1] - xy[0]))
    return {
        "mean_speed": _nanmean(speeds),
        "max_speed": _nanmax(speeds),
        "mean_acceleration": _nanmean(accelerations),
        "max_acceleration": _nanmax(accelerations),
        "mean_yaw_rate": _nanmean(yaw_rates),
        "max_yaw_rate": _nanmax(yaw_rates),
        "total_displacement": total_displacement,
    }


def _is_vehicle(category_name: str) -> bool:
    category = category_name.lower()
    return category.startswith("vehicle") or ".vehicle" in category


def _is_pedestrian(category_name: str) -> bool:
    category = category_name.lower()
    return category.startswith("human.pedestrian") or "pedestrian" in category


def compute_agent_density_features(nusc: Any, sample_tokens: list[str]) -> dict[str, float]:
    total_counts: list[int] = []
    vehicle_counts: list[int] = []
    pedestrian_counts: list[int] = []
    nearest_distances: list[float] = []
    all_distances: list[float] = []

    for token in sample_tokens:
        sample = nusc.get("sample", token)
        ego_pose = _sample_ego_pose(nusc, sample)
        ego_xy = None
        if ego_pose is not None:
            ego_xy = np.asarray(ego_pose["translation"][:2], dtype=np.float64)

        vehicles = 0
        pedestrians = 0
        sample_distances: list[float] = []
        for ann_token in sample.get("anns", []):
            ann = nusc.get("sample_annotation", ann_token)
            category_name = ann.get("category_name", "")
            vehicles += int(_is_vehicle(category_name))
            pedestrians += int(_is_pedestrian(category_name))
            if ego_xy is not None:
                ann_xy = np.asarray(ann["translation"][:2], dtype=np.float64)
                distance = float(np.linalg.norm(ann_xy - ego_xy))
                sample_distances.append(distance)
                all_distances.append(distance)

        total_counts.append(len(sample.get("anns", [])))
        vehicle_counts.append(vehicles)
        pedestrian_counts.append(pedestrians)
        nearest_distances.append(min(sample_distances) if sample_distances else float("nan"))

    return {
        "mean_num_agents": _nanmean(np.asarray(total_counts, dtype=np.float64)),
        "mean_num_vehicles": _nanmean(np.asarray(vehicle_counts, dtype=np.float64)),
        "mean_num_pedestrians": _nanmean(np.asarray(pedestrian_counts, dtype=np.float64)),
        "max_num_agents": _nanmax(np.asarray(total_counts, dtype=np.float64)),
        "min_distance_to_agent": float(np.nanmin(all_distances)) if all_distances else float("nan"),
        "mean_distance_to_nearest_agent": _nanmean(
            np.asarray(nearest_distances, dtype=np.float64)
        ),
    }


def _empty_ego_motion() -> dict[str, float]:
    return {
        "mean_speed": float("nan"),
        "max_speed": float("nan"),
        "mean_acceleration": float("nan"),
        "max_acceleration": float("nan"),
        "mean_yaw_rate": float("nan"),
        "max_yaw_rate": float("nan"),
        "total_displacement": float("nan"),
    }


def _empty_agent_density() -> dict[str, float]:
    return {
        "mean_num_agents": float("nan"),
        "mean_num_vehicles": float("nan"),
        "mean_num_pedestrians": float("nan"),
        "max_num_agents": float("nan"),
        "min_distance_to_agent": float("nan"),
        "mean_distance_to_nearest_agent": float("nan"),
    }


def build_raw_feature_frame(nusc: Any, clips: pd.DataFrame, config: FeatureConfig) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for _, clip in clips.iterrows():
        sample_tokens = parse_json_list(clip["sample_tokens"])
        row: dict[str, Any] = {
            "clip_id": clip["clip_id"],
            "location": clip.get("location", "unknown"),
            "description": clip.get("description", ""),
            "num_samples": int(clip.get("num_samples", len(sample_tokens))),
        }
        if config.use_ego_motion:
            row.update(compute_ego_motion_features(nusc, sample_tokens))
        else:
            row.update(_empty_ego_motion())
        if config.use_agent_density:
            row.update(compute_agent_density_features(nusc, sample_tokens))
        else:
            row.update(_empty_agent_density())
        rows.append(row)
    return pd.DataFrame(rows)


def fill_numeric_nans(df: pd.DataFrame, fill_nan: str) -> pd.DataFrame:
    result = df.copy()
    numeric_cols = result.select_dtypes(include=[np.number]).columns.tolist()
    if fill_nan not in {"median", "zero"}:
        raise ValueError("fill_nan must be either 'median' or 'zero'")
    for column in numeric_cols:
        if fill_nan == "median":
            value = result[column].median(skipna=True)
            if pd.isna(value):
                value = 0.0
        else:
            value = 0.0
        result[column] = result[column].fillna(value)
    return result


def append_metadata_features(raw: pd.DataFrame, config: FeatureConfig) -> pd.DataFrame:
    frames = [raw]
    if config.use_location:
        locations = raw["location"].fillna("unknown").astype(str)
        one_hot = pd.get_dummies(locations, prefix="location", dtype=float)
        frames.append(one_hot)

    if config.use_description_tfidf:
        descriptions = raw["description"].fillna("").astype(str).tolist()
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer

            vectorizer = TfidfVectorizer(
                max_features=config.tfidf_max_features,
                lowercase=True,
                stop_words="english",
            )
            matrix = vectorizer.fit_transform(descriptions)
            terms = vectorizer.get_feature_names_out()
            tfidf = pd.DataFrame(
                matrix.toarray(),
                columns=[f"description_tfidf_{term}" for term in terms],
                index=raw.index,
            )
            frames.append(tfidf)
        except ValueError:
            pass

    features = pd.concat(frames, axis=1)
    features = fill_numeric_nans(features, config.fill_nan)
    return features


def feature_columns(features: pd.DataFrame) -> list[str]:
    columns = [
        column
        for column in features.columns
        if column not in ID_COLUMNS and pd.api.types.is_numeric_dtype(features[column])
    ]
    return columns


def extract_clip_features(clips: pd.DataFrame, config: FeatureConfig) -> tuple[pd.DataFrame, list[str]]:
    nusc = load_nuscenes(config.dataroot, config.version, config.verbose)
    raw = build_raw_feature_frame(nusc, clips, config)
    features = append_metadata_features(raw, config)
    columns = feature_columns(features)
    if not columns:
        raise ValueError("No numeric feature columns were produced")
    if features[columns].isna().any().any():
        bad_columns = features[columns].columns[features[columns].isna().any()].tolist()
        raise ValueError(f"Feature frame still contains NaN values: {bad_columns}")
    return features, columns


def save_feature_outputs(
    features: pd.DataFrame,
    columns: list[str],
    out_dir: str | Path,
) -> dict[str, Path]:
    output_dir = ensure_dir(out_dir)
    parquet_path = output_dir / "clip_features.parquet"
    npy_path = output_dir / "clip_features.npy"
    columns_path = output_dir / "clip_feature_columns.json"
    ids_path = output_dir / "clip_feature_ids.json"

    features.to_parquet(parquet_path, index=False)
    np.save(npy_path, features[columns].to_numpy(dtype=np.float32))
    write_json(columns, columns_path)
    write_json(features["clip_id"].astype(str).tolist(), ids_path)
    return {
        "parquet": parquet_path,
        "npy": npy_path,
        "columns": columns_path,
        "ids": ids_path,
    }


def extract_and_save_features(
    clips_path: str | Path,
    out_dir: str | Path,
    config: FeatureConfig,
) -> tuple[pd.DataFrame, list[str], dict[str, Path]]:
    clips = read_csv(clips_path)
    for column in ["clip_id", "location", "description", "sample_tokens"]:
        if column not in clips.columns:
            raise ValueError(f"clips file missing required column: {column}")
    if clips["clip_id"].duplicated().any():
        raise ValueError("clips file contains duplicate clip_id values")
    features, columns = extract_clip_features(clips, config)
    paths = save_feature_outputs(features, columns, out_dir)
    return features, columns, paths
