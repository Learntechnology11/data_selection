# 工程路线图：MOSAIC-on-nuScenes

## 1. 推荐目录结构

```text
mosaic-nuscenes/
  configs/
    mosaic_nuscenes_mini.yaml
    mosaic_nuscenes_trainval.yaml
  scripts/
    build_nuscenes_clips.py
    create_splits.py
    extract_clip_features.py
    cluster_pool.py
    train_planner.py
    evaluate_planner.py
    rank_pool.py
    run_pilot_experiments.py
    fit_scaling_laws.py
    select_mosaic.py
    select_baselines.py
    run_selection_experiments.py
  src/
    data/
      nuscenes_clips.py
      splits.py
    features/
      clip_features.py
    models/
      ego_planner_dataset.py
      ego_planner.py
      train_utils.py
    evaluation/
      metrics.py
      utility.py
    selection/
      clustering.py
      ranking.py
      scaling.py
      mosaic.py
      baselines.py
    utils/
      io.py
      seed.py
      logging.py
  outputs/
    clips/
    splits/
    features/
    clusters/
    checkpoints/
    eval/
    ranking/
    pilot/
    scaling/
    selections/
    results/
  README_REPRO.md
  requirements.txt
```

## 2. 阶段 1：项目骨架

### 目标

创建目录、配置文件、requirements、README。

### 验收

```bash
python -m compileall src scripts
```

没有语法错误。

## 3. 阶段 2：构建 nuScenes clips

### 脚本

```text
scripts/build_nuscenes_clips.py
src/data/nuscenes_clips.py
```

### 命令

```bash
python scripts/build_nuscenes_clips.py \
    --dataroot /path/to/nuscenes \
    --version v1.0-mini \
    --out outputs/clips/nuscenes_mini_clips.csv
```

### 输出

```text
outputs/clips/nuscenes_mini_clips.csv
```

### 验收

```text
clip_id 唯一
sample_tokens 不为空
每个 clip 的 num_samples 达到最低要求
```

## 4. 阶段 3：划分 split

### 脚本

```text
scripts/create_splits.py
src/data/splits.py
```

### 命令

```bash
python scripts/create_splits.py \
    --clips outputs/clips/nuscenes_mini_clips.csv \
    --mode mini_random \
    --base-ratio 0.2 \
    --pool-ratio 0.6 \
    --seed 42 \
    --out-dir outputs/splits
```

### 输出

```text
outputs/splits/base_train.csv
outputs/splits/pool.csv
outputs/splits/val.csv
```

### 验收

```text
base_train、pool、val 三者 clip_id 无交集
三者合并数量等于原 clips 数量
```

## 5. 阶段 4：抽取 clip features

### 脚本

```text
scripts/extract_clip_features.py
src/features/clip_features.py
```

### 命令

```bash
python scripts/extract_clip_features.py \
    --dataroot /path/to/nuscenes \
    --version v1.0-mini \
    --clips outputs/clips/nuscenes_mini_clips.csv \
    --out-dir outputs/features
```

### 输出

```text
outputs/features/clip_features.parquet
outputs/features/clip_features.npy
outputs/features/clip_feature_columns.json
```

### 验收

```text
没有 NaN
每个 clip 都有 feature
feature columns 与 npy 维度一致
```

## 6. 阶段 5：聚类

### 脚本

```text
scripts/cluster_pool.py
src/selection/clustering.py
```

### 命令

```bash
python scripts/cluster_pool.py \
    --pool outputs/splits/pool.csv \
    --features outputs/features/clip_features.parquet \
    --method kmeans \
    --num-clusters 4 \
    --out-dir outputs/clusters
```

### 输出

```text
outputs/clusters/cluster_assignments.csv
outputs/clusters/cluster_summary.csv
```

### 验收

```text
cluster_assignments 覆盖所有 pool clips
cluster_id 从 0 或 1 连续编号
每个 cluster 至少有 1 个样本
```

## 7. 阶段 6：训练 base planner

### 脚本

```text
scripts/train_planner.py
scripts/evaluate_planner.py
src/models/ego_planner.py
src/models/ego_planner_dataset.py
```

### 命令

```bash
python scripts/train_planner.py \
    --train outputs/splits/base_train.csv \
    --val outputs/splits/val.csv \
    --dataroot /path/to/nuscenes \
    --version v1.0-mini \
    --config configs/mosaic_nuscenes_mini.yaml \
    --exp-name base_train
```

### 输出

```text
outputs/checkpoints/base_train.pt
outputs/eval/base_train/metrics.json
outputs/eval/base_train/per_clip_metrics.csv
```

### 验收

```text
训练 loss 下降
validation metrics 可以正常输出
checkpoint 可以被 evaluate_planner.py 重新加载
```

## 8. 阶段 7：Pool ranking

### 脚本

```text
scripts/rank_pool.py
src/selection/ranking.py
```

### 命令

```bash
python scripts/rank_pool.py \
    --checkpoint outputs/checkpoints/base_train.pt \
    --pool outputs/splits/pool.csv \
    --clusters outputs/clusters/cluster_assignments.csv \
    --dataroot /path/to/nuscenes \
    --version v1.0-mini \
    --out-dir outputs/ranking
```

### 输出

```text
outputs/ranking/pool_importance_scores.csv
outputs/ranking/cluster_ranked_pool.csv
```

### 验收

```text
每个 pool clip 有 importance_score
每个 cluster 内 rank_within_cluster 连续
importance_score 越高，rank 越靠前
```

## 9. 阶段 8：Pilot + scaling

### 脚本

```text
scripts/run_pilot_experiments.py
scripts/fit_scaling_laws.py
src/selection/scaling.py
```

### 命令

```bash
python scripts/run_pilot_experiments.py \
    --base-train outputs/splits/base_train.csv \
    --val outputs/splits/val.csv \
    --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
    --pilot-budgets 5 10 20 \
    --mode finetune \
    --config configs/mosaic_nuscenes_mini.yaml \
    --out outputs/pilot/pilot_results.csv

python scripts/fit_scaling_laws.py \
    --pilot-results outputs/pilot/pilot_results.csv \
    --out-dir outputs/scaling
```

### 输出

```text
outputs/pilot/pilot_results.csv
outputs/scaling/scaling_params.json
outputs/scaling/scaling_fit_plot_cluster_{i}.png
```

### 验收

```text
每个 cluster 都有至少一个 pilot result
每个 cluster 都有 a 和 tau
fitting 失败时有 fallback，不中断整体流程
```

## 10. 阶段 9：MOSAIC selection

### 脚本

```text
scripts/select_mosaic.py
src/selection/mosaic.py
```

### 命令

```bash
python scripts/select_mosaic.py \
    --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
    --scaling-params outputs/scaling/scaling_params.json \
    --budget 40 \
    --out-dir outputs/selections
```

### 输出

```text
outputs/selections/mosaic_budget_40.csv
outputs/selections/mosaic_trace_budget_40.csv
```

### 验收

```text
selected 数量等于 budget
所有 selected clips 来自 pool
trace 中每一步都有 estimated_marginal_gain
```

## 11. 阶段 10：Baselines

### 脚本

```text
scripts/select_baselines.py
src/selection/baselines.py
```

### 命令

```bash
python scripts/select_baselines.py \
    --method random \
    --pool outputs/splits/pool.csv \
    --budget 40 \
    --seed 42 \
    --out-dir outputs/selections
```

### baseline 清单

```text
random
coreset
ranking_only
cluster_only
uncertainty 或 error_ranking
```

## 12. 阶段 11：一键运行实验

### 脚本

```text
scripts/run_selection_experiments.py
```

### 命令

```bash
python scripts/run_selection_experiments.py \
    --config configs/mosaic_nuscenes_mini.yaml \
    --budgets 20 40 80 \
    --methods random coreset ranking_only mosaic \
    --seeds 0 2025 424242
```

### 输出

```text
outputs/results/main_results.csv
outputs/results/metric_breakdown.csv
outputs/results/cluster_distribution.csv
```

## 13. 推荐实现顺序

Codex 每次只做一段：

```text
1. 先建工程骨架
2. 再 build_nuscenes_clips
3. 再 create_splits
4. 再 extract_clip_features
5. 再 cluster_pool
6. 再 planner
7. 再 ranking
8. 再 pilot/scaling
9. 再 mosaic selection
10. 最后 baselines + run_selection_experiments
```

不要一次性要求 Codex 完成所有模块。
