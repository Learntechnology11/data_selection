"""Small Fashion-MNIST model and convergence-oriented training helpers."""

from __future__ import annotations

import csv
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset, Subset, WeightedRandomSampler


class SmallFashionCNN(nn.Module):
    """Compact CNN for subset comparison on Fashion-MNIST."""

    def __init__(self) -> None:
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(64 * 7 * 7, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
        )
        self.classifier = nn.Linear(128, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.forward_features(x))

    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        """Return the penultimate 128-dimensional representation."""

        return self.features(x)


def train_validate_test(
    train_dataset: Dataset,
    val_indices: Sequence[int],
    test_dataset: Dataset,
    selected_indices: Sequence[int],
    weights: Sequence[float],
    *,
    epochs: int,
    patience: int,
    min_delta: float,
    batch_size: int,
    seed: int,
    device: str,
    run_dir: Path,
    val_dataset: Dataset | None = None,
) -> Dict[str, Any]:
    """Train with validation early stopping and evaluate on the test set."""

    torch.manual_seed(seed)
    np.random.seed(seed)
    if device == "cuda":
        torch.cuda.manual_seed_all(seed)

    run_dir.mkdir(parents=True, exist_ok=True)
    model = SmallFashionCNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)

    train_loader = _train_loader(train_dataset, selected_indices, weights, batch_size)
    validation_data = val_dataset if val_dataset is not None else Subset(train_dataset, list(val_indices))
    val_loader = DataLoader(validation_data, batch_size=batch_size, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0)

    best_val_loss = float("inf")
    best_epoch = -1
    best_state = deepcopy(model.state_dict())
    wait = 0
    history: List[Dict[str, float]] = []

    for epoch in range(1, int(epochs) + 1):
        train_loss = _train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_metrics = evaluate(model, val_loader, device)
        row = {
            "epoch": float(epoch),
            "train_loss": float(train_loss),
            "val_loss": float(val_metrics["loss"]),
            "val_accuracy": float(val_metrics["accuracy"]),
            "val_balanced_accuracy": float(val_metrics["balanced_accuracy"]),
            "val_macro_f1": float(val_metrics["macro_f1"]),
        }
        history.append(row)

        improved = row["val_loss"] < best_val_loss - float(min_delta)
        if improved:
            best_val_loss = row["val_loss"]
            best_epoch = epoch
            best_state = deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
            if wait >= int(patience):
                break

    model.load_state_dict(best_state)
    test_metrics = evaluate(model, test_loader, device)
    torch.save({"model": best_state, "best_epoch": best_epoch, "seed": seed}, run_dir / "best.pt")
    _write_history(history, run_dir / "history.csv")
    result: Dict[str, Any] = {
        **{
            f"test_{key}": value
            for key, value in test_metrics.items()
            if key not in {"confusion_matrix", "per_class_accuracy"}
        },
        "best_epoch": best_epoch,
        "best_val_loss": best_val_loss,
        "epochs_ran": len(history),
        "history_path": str(run_dir / "history.csv"),
        "checkpoint_path": str(run_dir / "best.pt"),
        "confusion_matrix": test_metrics["confusion_matrix"],
        "per_class_accuracy": test_metrics["per_class_accuracy"],
    }
    return result


def evaluate(model: nn.Module, loader: DataLoader, device: str) -> Dict[str, Any]:
    """Evaluate loss, accuracy, balanced accuracy, macro-F1, and confusion."""

    criterion = nn.CrossEntropyLoss(reduction="sum")
    model.eval()
    confusion = np.zeros((10, 10), dtype=np.int64)
    loss_total = 0.0
    total = 0
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)
            logits = model(images)
            loss_total += float(criterion(logits, labels).item())
            pred = logits.argmax(dim=1)
            for target, output in zip(labels.detach().cpu().numpy(), pred.detach().cpu().numpy()):
                confusion[int(target), int(output)] += 1
            total += int(labels.numel())

    per_class_total = confusion.sum(axis=1)
    per_class_correct = np.diag(confusion)
    per_class_acc = np.divide(
        per_class_correct,
        np.maximum(per_class_total, 1),
        out=np.zeros_like(per_class_correct, dtype=np.float64),
        where=per_class_total > 0,
    )
    precision = np.divide(
        per_class_correct,
        np.maximum(confusion.sum(axis=0), 1),
        out=np.zeros_like(per_class_correct, dtype=np.float64),
        where=confusion.sum(axis=0) > 0,
    )
    recall = per_class_acc
    f1 = np.divide(
        2.0 * precision * recall,
        np.maximum(precision + recall, 1e-12),
        out=np.zeros_like(precision, dtype=np.float64),
        where=(precision + recall) > 0,
    )
    return {
        "accuracy": float(per_class_correct.sum() / max(total, 1)),
        "balanced_accuracy": float(per_class_acc.mean()),
        "macro_f1": float(f1.mean()),
        "loss": float(loss_total / max(total, 1)),
        "num_samples": float(total),
        "per_class_accuracy": {str(cls): float(per_class_acc[cls]) for cls in range(10)},
        "confusion_matrix": confusion.tolist(),
    }


def _train_loader(
    train_dataset: Dataset,
    selected_indices: Sequence[int],
    weights: Sequence[float],
    batch_size: int,
) -> DataLoader:
    subset = Subset(train_dataset, list(selected_indices))
    if weights:
        sampler = WeightedRandomSampler(
            torch.as_tensor(weights, dtype=torch.double),
            num_samples=len(weights),
            replacement=True,
        )
        return DataLoader(subset, batch_size=batch_size, sampler=sampler, num_workers=0)
    return DataLoader(subset, batch_size=batch_size, shuffle=True, num_workers=0)


def _train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: str,
) -> float:
    model.train()
    loss_total = 0.0
    total = 0
    for images, labels in loader:
        images = images.to(device)
        labels = labels.to(device)
        optimizer.zero_grad(set_to_none=True)
        loss = criterion(model(images), labels)
        loss.backward()
        optimizer.step()
        loss_total += float(loss.detach().item()) * int(labels.numel())
        total += int(labels.numel())
    return loss_total / max(total, 1)


def _write_history(history: Sequence[Mapping[str, float]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not history:
        return
    fieldnames = ["epoch", "train_loss", "val_loss", "val_accuracy", "val_balanced_accuracy", "val_macro_f1"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in history:
            writer.writerow({key: row.get(key, "") for key in fieldnames})
