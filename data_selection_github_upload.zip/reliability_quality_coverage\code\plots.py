"""Plot helpers for Fashion-MNIST coreset diagnostics."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np


def plot_class_distribution(labels_by_run: Mapping[str, Sequence[int]], path: Path) -> None:
    """Plot class proportions for full data and selected subsets."""

    plt = _pyplot()
    names = list(labels_by_run.keys())
    classes = list(range(10))
    values = []
    for name in names:
        labels = np.asarray(labels_by_run[name], dtype=int)
        counts = np.bincount(labels, minlength=10).astype(float)
        values.append(counts / max(counts.sum(), 1.0))
    values_arr = np.asarray(values)
    x = np.arange(10)
    width = min(0.8 / max(len(names), 1), 0.12)
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(10, 4.8))
    for idx, name in enumerate(names):
        offset = (idx - (len(names) - 1) / 2.0) * width
        plt.bar(x + offset, values_arr[idx], width=width, label=name)
    plt.xticks(x, [str(c) for c in classes])
    plt.xlabel("Fashion-MNIST class")
    plt.ylabel("proportion")
    plt.title("Class distribution")
    plt.legend(fontsize=7, ncol=2)
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def plot_pca_overlay(features: np.ndarray, labels: np.ndarray, selected_mask: np.ndarray, title: str, path: Path) -> None:
    """Plot selected samples over full data in 2D PCA space."""

    if features.shape[0] < 2:
        return
    xy = _pca2(features)
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6.5, 5.5))
    plt.scatter(xy[:, 0], xy[:, 1], s=8, c=labels, cmap="tab10", alpha=0.18, label="full train")
    plt.scatter(xy[selected_mask, 0], xy[selected_mask, 1], s=18, facecolors="none", edgecolors="black", linewidths=0.8, label="selected")
    plt.title(title)
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def plot_training_history(history_csv: Path, path: Path, title: str) -> None:
    """Plot train and validation loss curves for one run."""

    import csv

    if not history_csv.exists():
        return
    rows = []
    with history_csv.open("r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rows.append(row)
    if not rows:
        return
    epochs = [int(float(row["epoch"])) for row in rows]
    train_loss = [float(row["train_loss"]) for row in rows]
    val_loss = [float(row["val_loss"]) for row in rows]
    val_acc = [float(row["val_accuracy"]) for row in rows]
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax1 = plt.subplots(figsize=(6.5, 4.5))
    ax1.plot(epochs, train_loss, marker="o", label="train loss")
    ax1.plot(epochs, val_loss, marker="o", label="val loss")
    ax1.set_xlabel("epoch")
    ax1.set_ylabel("loss")
    ax2 = ax1.twinx()
    ax2.plot(epochs, val_acc, color="tab:green", marker="s", label="val accuracy")
    ax2.set_ylabel("accuracy")
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, loc="best")
    ax1.set_title(title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def plot_metric_by_budget(rows: Sequence[Mapping[str, object]], metric: str, path: Path) -> None:
    """Plot one metric across budgets for each method."""

    methods = sorted({str(row.get("method", "")) for row in rows if str(row.get("budget", "")) != "100"})
    if not methods:
        return
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6.8, 4.5))
    for method in methods:
        method_rows = [row for row in rows if str(row.get("method", "")) == method]
        points = []
        for row in method_rows:
            try:
                budget = float(row.get("budget", 0))
                value = float(row.get(metric, "nan"))
            except (TypeError, ValueError):
                continue
            if np.isfinite(value):
                points.append((budget, value))
        if not points:
            continue
        points.sort()
        plt.plot([p[0] for p in points], [p[1] for p in points], marker="o", label=method)
    full_rows = [row for row in rows if str(row.get("run", "")) == "full_data"]
    if full_rows:
        try:
            full_value = float(full_rows[0].get(metric, "nan"))
            if np.isfinite(full_value):
                plt.axhline(full_value, color="black", linestyle="--", linewidth=1.2, label="full_data")
        except (TypeError, ValueError):
            pass
    plt.xlabel("budget percent")
    plt.ylabel(metric)
    plt.title(f"{metric} vs budget")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def plot_confusion_matrix(confusion: Sequence[Sequence[int]], path: Path, title: str) -> None:
    """Plot a confusion matrix."""

    matrix = np.asarray(confusion, dtype=np.float64)
    if matrix.size == 0:
        return
    row_sums = np.maximum(matrix.sum(axis=1, keepdims=True), 1.0)
    normalized = matrix / row_sums
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6, 5.5))
    plt.imshow(normalized, cmap="Blues", vmin=0.0, vmax=1.0)
    plt.colorbar(label="row-normalized rate")
    plt.xticks(range(10), range(10))
    plt.yticks(range(10), range(10))
    plt.xlabel("predicted")
    plt.ylabel("target")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def plot_image_grid(images: np.ndarray, labels: np.ndarray, selected_local: Sequence[int], path: Path, title: str, limit: int = 64) -> None:
    """Save a visual grid of selected Fashion-MNIST images."""

    selected = list(selected_local)[:limit]
    if not selected:
        return
    cols = 8
    rows = int(np.ceil(len(selected) / cols))
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 1.2, rows * 1.35))
    axes_arr = np.asarray(axes).reshape(-1)
    for ax in axes_arr:
        ax.axis("off")
    for ax, idx in zip(axes_arr, selected):
        ax.imshow(images[idx], cmap="gray")
        ax.set_title(str(int(labels[idx])), fontsize=8)
        ax.axis("off")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_json(payload: object, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def _pca2(features: np.ndarray) -> np.ndarray:
    centered = features - features.mean(axis=0, keepdims=True)
    centered = centered / np.maximum(centered.std(axis=0, keepdims=True), 1e-9)
    _, _, vt = np.linalg.svd(centered, full_matrices=False)
    return centered @ vt[:2].T


def _pyplot():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt
