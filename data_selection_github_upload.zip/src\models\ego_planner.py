from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torch import nn

from src.models.hydra_mdp_lite import HydraMDPLite, HydraMDPLiteConfig
from src.models.hydra_mdp_nuscenes import HydraMDPNuScenes, HydraMDPNuScenesConfig


@dataclass(frozen=True)
class MLPPlannerConfig:
    input_dim: int
    future_steps: int
    hidden_dim: int = 128
    num_layers: int = 2
    dropout: float = 0.1

    @property
    def output_dim(self) -> int:
        return self.future_steps * 2


class MLPPlanner(nn.Module):
    def __init__(self, config: MLPPlannerConfig) -> None:
        super().__init__()
        if config.num_layers < 1:
            raise ValueError("num_layers must be at least 1")
        layers: list[nn.Module] = []
        in_dim = config.input_dim
        for _ in range(config.num_layers):
            layers.append(nn.Linear(in_dim, config.hidden_dim))
            layers.append(nn.ReLU())
            if config.dropout > 0:
                layers.append(nn.Dropout(config.dropout))
            in_dim = config.hidden_dim
        layers.append(nn.Linear(in_dim, config.output_dim))
        self.net = nn.Sequential(*layers)
        self.future_steps = config.future_steps

    def forward(self, inputs: torch.Tensor | dict[str, torch.Tensor]) -> torch.Tensor:
        if isinstance(inputs, dict):
            inputs = inputs["inputs"] if "inputs" in inputs else inputs["ego"]
        if inputs.ndim > 2:
            inputs = inputs.flatten(start_dim=1)
        outputs = self.net(inputs)
        return outputs.view(inputs.shape[0], self.future_steps, 2)


def select_device(device: str = "auto") -> torch.device:
    requested = (device or "auto").lower()
    if requested == "auto":
        try:
            import torch_npu  # noqa: F401
        except ImportError:
            pass
        if hasattr(torch, "npu") and torch.npu.is_available():
            return torch.device("npu:0")
        if torch.cuda.is_available():
            return torch.device("cuda:0")
        return torch.device("cpu")
    if requested.startswith("npu"):
        try:
            import torch_npu  # noqa: F401
        except ImportError as exc:
            raise ImportError("torch-npu is required for NPU execution") from exc
    return torch.device(device)


def build_mlp_planner(
    input_dim: int,
    future_steps: int,
    planner_cfg: dict[str, Any],
) -> MLPPlanner:
    config = MLPPlannerConfig(
        input_dim=input_dim,
        future_steps=future_steps,
        hidden_dim=int(planner_cfg.get("hidden_dim", 128)),
        num_layers=int(planner_cfg.get("num_layers", 2)),
        dropout=float(planner_cfg.get("dropout", 0.1)),
    )
    return MLPPlanner(config)


def build_planner(
    input_dim: int,
    future_steps: int,
    planner_cfg: dict[str, Any],
    camera_feature_dim: int = 0,
    trajectory_vocab: torch.Tensor | None = None,
) -> tuple[nn.Module, dict[str, Any]]:
    model_type = str(planner_cfg.get("model_type", "mlp")).lower()
    if model_type == "mlp":
        config = MLPPlannerConfig(
            input_dim=input_dim,
            future_steps=future_steps,
            hidden_dim=int(planner_cfg.get("hidden_dim", 128)),
            num_layers=int(planner_cfg.get("num_layers", 2)),
            dropout=float(planner_cfg.get("dropout", 0.1)),
        )
        return MLPPlanner(config), {
            "model_type": "mlp",
            "input_dim": config.input_dim,
            "future_steps": config.future_steps,
            "hidden_dim": config.hidden_dim,
            "num_layers": config.num_layers,
            "dropout": config.dropout,
        }
    if model_type in {"hydra_mdp_lite", "hydra-lite", "hydra_lite"}:
        config = HydraMDPLiteConfig(
            ego_input_dim=input_dim,
            camera_feature_dim=camera_feature_dim,
            future_steps=future_steps,
            hidden_dim=int(planner_cfg.get("hidden_dim", 256)),
            fusion_dim=int(planner_cfg.get("fusion_dim", planner_cfg.get("hidden_dim", 256))),
            num_layers=int(planner_cfg.get("num_layers", 2)),
            dropout=float(planner_cfg.get("dropout", 0.1)),
            trajectory_vocab=trajectory_vocab,
            num_modes=0 if trajectory_vocab is None else int(trajectory_vocab.shape[0]),
        )
        return HydraMDPLite(config), {
            "model_type": "hydra_mdp_lite",
            "input_dim": input_dim,
            "ego_input_dim": config.ego_input_dim,
            "camera_feature_dim": config.camera_feature_dim,
            "future_steps": config.future_steps,
            "hidden_dim": config.hidden_dim,
            "fusion_dim": config.fusion_dim,
            "num_layers": config.num_layers,
            "dropout": config.dropout,
            "num_modes": config.num_modes,
        }
    if model_type in {"hydra_mdp_nuscenes", "hydra-mdp-nuscenes", "hydra_nuscenes"}:
        config = HydraMDPNuScenesConfig(
            ego_input_dim=input_dim,
            camera_feature_dim=camera_feature_dim,
            agent_token_dim=int(planner_cfg.get("agent_token_dim", 15)),
            future_steps=future_steps,
            hidden_dim=int(planner_cfg.get("hidden_dim", 256)),
            fusion_dim=int(planner_cfg.get("fusion_dim", planner_cfg.get("hidden_dim", 256))),
            num_layers=int(planner_cfg.get("num_layers", 2)),
            num_attention_heads=int(planner_cfg.get("num_attention_heads", 4)),
            decoder_layers=int(planner_cfg.get("decoder_layers", planner_cfg.get("num_layers", 2))),
            dropout=float(planner_cfg.get("dropout", 0.1)),
            num_cameras=int(planner_cfg.get("num_cameras", 6)),
            trajectory_vocab=trajectory_vocab,
            num_modes=0 if trajectory_vocab is None else int(trajectory_vocab.shape[0]),
            metric_head_dim=int(planner_cfg.get("metric_head_dim", 3)),
            metric_score_weights=tuple(planner_cfg.get("metric_score_weights", [0.50, 0.30, 0.20])),
        )
        model = HydraMDPNuScenes(config)
        return model, {
            "model_type": "hydra_mdp_nuscenes",
            "input_dim": input_dim,
            "ego_input_dim": config.ego_input_dim,
            "camera_feature_dim": config.camera_feature_dim,
            "agent_token_dim": config.agent_token_dim,
            "future_steps": config.future_steps,
            "hidden_dim": config.hidden_dim,
            "fusion_dim": config.fusion_dim,
            "num_layers": config.num_layers,
            "num_attention_heads": config.num_attention_heads,
            "decoder_layers": config.decoder_layers,
            "dropout": config.dropout,
            "num_cameras": config.num_cameras,
            "num_modes": model.num_modes,
            "metric_head_dim": config.metric_head_dim,
            "metric_score_weights": list(config.metric_score_weights),
        }
    raise ValueError(f"Unsupported planner model_type: {model_type}")


def model_config_dict(model: MLPPlanner, config: MLPPlannerConfig | None = None) -> dict[str, Any]:
    if config is not None:
        return {
            "model_type": "mlp",
            "input_dim": config.input_dim,
            "future_steps": config.future_steps,
            "hidden_dim": config.hidden_dim,
            "num_layers": config.num_layers,
            "dropout": config.dropout,
        }
    linear_layers = [module for module in model.net if isinstance(module, nn.Linear)]
    hidden_dim = linear_layers[0].out_features if linear_layers else 128
    num_layers = max(1, len(linear_layers) - 1)
    dropout = next((module.p for module in model.net if isinstance(module, nn.Dropout)), 0.0)
    return {
        "model_type": "mlp",
        "input_dim": linear_layers[0].in_features,
        "future_steps": model.future_steps,
        "hidden_dim": hidden_dim,
        "num_layers": num_layers,
        "dropout": dropout,
    }


def build_model_from_checkpoint(checkpoint: dict[str, Any]) -> nn.Module:
    cfg = checkpoint.get("model_config", {})
    model_type = cfg.get("model_type", "mlp")
    if model_type == "mlp":
        model = MLPPlanner(
            MLPPlannerConfig(
                input_dim=int(cfg["input_dim"]),
                future_steps=int(cfg["future_steps"]),
                hidden_dim=int(cfg.get("hidden_dim", 128)),
                num_layers=int(cfg.get("num_layers", 2)),
                dropout=float(cfg.get("dropout", 0.1)),
            )
        )
    elif model_type == "hydra_mdp_lite":
        model = HydraMDPLite(
            HydraMDPLiteConfig(
                ego_input_dim=int(cfg.get("ego_input_dim", cfg["input_dim"])),
                camera_feature_dim=int(cfg["camera_feature_dim"]),
                future_steps=int(cfg["future_steps"]),
                hidden_dim=int(cfg.get("hidden_dim", 256)),
                fusion_dim=int(cfg.get("fusion_dim", cfg.get("hidden_dim", 256))),
                num_layers=int(cfg.get("num_layers", 2)),
                dropout=float(cfg.get("dropout", 0.1)),
                trajectory_vocab=None,
                num_modes=int(cfg.get("num_modes", 0)),
            )
        )
    elif model_type == "hydra_mdp_nuscenes":
        model = HydraMDPNuScenes(
            HydraMDPNuScenesConfig(
                ego_input_dim=int(cfg.get("ego_input_dim", cfg["input_dim"])),
                camera_feature_dim=int(cfg["camera_feature_dim"]),
                agent_token_dim=int(cfg.get("agent_token_dim", 15)),
                future_steps=int(cfg["future_steps"]),
                hidden_dim=int(cfg.get("hidden_dim", 256)),
                fusion_dim=int(cfg.get("fusion_dim", cfg.get("hidden_dim", 256))),
                num_layers=int(cfg.get("num_layers", 2)),
                num_attention_heads=int(cfg.get("num_attention_heads", 4)),
                decoder_layers=int(cfg.get("decoder_layers", cfg.get("num_layers", 2))),
                dropout=float(cfg.get("dropout", 0.1)),
                num_cameras=int(cfg.get("num_cameras", 6)),
                trajectory_vocab=None,
                num_modes=int(cfg.get("num_modes", 0)),
                metric_head_dim=int(cfg.get("metric_head_dim", 3)),
                metric_score_weights=tuple(cfg.get("metric_score_weights", [0.50, 0.30, 0.20])),
            )
        )
    else:
        raise ValueError(f"Unsupported model_type in checkpoint: {model_type}")
    model.load_state_dict(checkpoint["model_state_dict"])
    return model
