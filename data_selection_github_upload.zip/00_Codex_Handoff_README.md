# Codex 交付说明：MOSAIC-on-nuScenes 复现任务

> 用途：把本文件夹里的 `.md` 文件和原始论文识别版 Markdown 一起发给 Codex，让 Codex 按阶段完成 nuScenes 上的数据选择算法复现。

## 1. 文件说明

建议一次性上传给 Codex 的文件包括：

1. `Scaling_Aware_Data_Selection_for_E2E_AD_recognized.md`  
   原论文识别整理版，用于让 Codex 理解 MOSAIC 的理论来源。

2. `00_Codex_Handoff_README.md`  
   当前文件，说明如何使用这些文档。

3. `01_MOSAIC_nuScenes_Task_Brief.md`  
   总任务书，说明项目目标、复现边界、输入输出、实验原则。

4. `02_MOSAIC_Algorithm_Spec.md`  
   MOSAIC 算法说明，包括数学定义、数据结构、伪代码、边界条件。

5. `03_nuScenes_Data_Adaptation_and_Utility.md`  
   nuScenes 适配说明，包括 clip 构建、特征抽取、utility 替代方案、指标定义。

6. `04_Engineering_Roadmap.md`  
   工程路线图，包括目录结构、脚本清单、阶段验收标准、命令行示例。

7. `05_Codex_Prompts.md`  
   可直接复制给 Codex 的分阶段提示词。

8. `06_Config_and_Output_Spec.md`  
   YAML 配置模板、输出文件规范、CSV/JSON 字段规范。

## 2. 给 Codex 的推荐使用顺序

不要让 Codex 一次性写完整系统。建议按下面顺序逐步推进：

```text
阶段 1：建立项目骨架
阶段 2：构建 nuScenes 10s clip
阶段 3：划分 base_train / pool / val
阶段 4：抽取 clip features
阶段 5：聚类 cluster_pool
阶段 6：训练轻量 open-loop planner
阶段 7：pool 样本重要性排序
阶段 8：pilot 实验 + scaling law 拟合
阶段 9：MOSAIC 选择器
阶段 10：baseline 对比实验
阶段 11：一键实验入口与结果汇总
```

## 3. 最重要的复现原则

### 3.1 不要强行复现论文原实验环境

原论文实验使用 OpenScene/Navtrain/NAVSIM/Hydra-MDP/EPDMS。当前项目使用 nuScenes，因此目标是：

```text
复现 MOSAIC 的算法机制，而不是逐项复现论文原实验数值。
```

### 3.2 先做最小闭环

第一版必须优先保证 nuScenes v1.0-mini 能跑通：

```text
clip 构建 -> split -> feature extraction -> clustering -> planner training -> ranking -> pilot -> scaling -> MOSAIC selection -> baseline comparison
```

### 3.3 utility 必须适配 nuScenes

nuScenes 没有论文中的 EPDMS，因此使用 open-loop planning utility：

```text
U = 100
    - w_ade * normalized_ADE
    - w_fde * normalized_FDE
    - w_heading * normalized_heading_error
    - w_collision * normalized_collision_proxy
    - w_offroad * normalized_offroad_proxy
    - w_jerk * normalized_jerk
```

如果 off-road proxy 暂时无法实现，必须设置为 optional，并在 utility 中自动跳过缺失指标、重新归一化权重。

## 4. 给 Codex 的第一条建议提示词

```text
请先阅读我上传的所有 Markdown 文件，特别是 01_MOSAIC_nuScenes_Task_Brief.md、02_MOSAIC_Algorithm_Spec.md、03_nuScenes_Data_Adaptation_and_Utility.md、04_Engineering_Roadmap.md 和 05_Codex_Prompts.md。

当前任务不是一次性写完整系统，而是先完成第一阶段：建立项目骨架、nuScenes 10秒 clip 构建、split 划分、clip feature 抽取、cluster_pool 聚类。

请严格按文档中的输入输出字段、目录结构、命令行接口实现。不要 mock 数据，不要跳过真实 nuScenes-devkit 读取逻辑。完成后请给出运行命令和每个输出文件的字段说明。
```

## 5. 交付检查清单

让 Codex 每个阶段完成后都检查：

- [ ] 所有脚本可通过命令行运行。
- [ ] 所有路径通过 YAML 或 argparse 配置，不硬编码。
- [ ] 所有输出 CSV/JSON/Parquet 字段与文档一致。
- [ ] base_train、pool、val 三者没有 clip_id 重叠。
- [ ] selected clips 全部来自 D_pool。
- [ ] cluster assignments 覆盖所有 pool clips。
- [ ] scaling params 中每个 cluster 都有 `a` 和 `tau`。
- [ ] MOSAIC selection 的输出数量等于 budget B。
- [ ] README_REPRO.md 中有从零运行 nuScenes mini 的完整命令。
