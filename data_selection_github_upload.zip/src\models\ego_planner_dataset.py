from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from src.data.nuscenes_clips import load_nuscenes
from src.features.camera_features import load_cached_camera_features
from src.models.trajectory_vocab import load_trajectory_vocab, nearest_trajectory_class
from src.utils.io import parse_json_list, read_csv, require_columns


@dataclass(frozen=True)
class PlannerDatasetConfig:
    past_horizon_sec: float = 2.0
    future_horizon_sec: float = 3.0
    sample_interval_sec: float = 0.5
    collision_distance_m: float = 2.0
    max_windows_per_clip: int | None = None
    camera_features_path: str | None = None
    trajectory_vocab_path: str | None = None
    max_agents: int = 32

    @property
    def past_steps(self) -> int:
        return max(2, int(round(self.past_horizon_sec / self.sample_interval_sec)) + 1)

    @property
    def future_steps(self) -> int:
        return max(1, int(round(self.future_horizon_sec / self.sample_interval_sec)))

    @property
    def input_dim(self) -> int:
        return self.past_steps * 4

    @property
    def output_dim(self) -> int:
        return self.future_steps * 2

    @property
    def agent_token_dim(self) -> int:
        return 15


@dataclass
class PlannerRecord:
    clip_id: str
    anchor_sample_token: str
    future_sample_tokens: list[str]
    inputs: np.ndarray
    targets: np.ndarray
    agent_tokens: np.ndarray
    future_agent_centers_padded: np.ndarray
    future_agent_mask: np.ndarray
    future_agent_centers: list[np.ndarray]


def normalize_angle(angle: float | np.ndarray) -> float | np.ndarray:
    return (angle + np.pi) % (2.0 * np.pi) - np.pi


def global_to_local(points_xy: np.ndarray, anchor_xy: np.ndarray, anchor_yaw: float) -> np.ndarray:
    delta = points_xy - anchor_xy[None, :]
    cos_yaw = math.cos(anchor_yaw)
    sin_yaw = math.sin(anchor_yaw)
    x_local = cos_yaw * delta[:, 0] + sin_yaw * delta[:, 1]
    y_local = -sin_yaw * delta[:, 0] + cos_yaw * delta[:, 1]
    return np.stack([x_local, y_local], axis=1)


def yaw_from_rotation(rotation: list[float]) -> float:
    from pyquaternion import Quaternion

    return float(Quaternion(rotation).yaw_pitch_roll[0])


def sample_ego_pose(nusc: Any, sample: dict[str, Any]) -> dict[str, Any] | None:
    sample_data = sample.get("data", {})
    sample_data_token = sample_data.get("LIDAR_TOP") or next(iter(sample_data.values()), None)
    if not sample_data_token:
        return None
    sd = nusc.get("sample_data", sample_data_token)
    return nusc.get("ego_pose", sd["ego_pose_token"])


def load_clip_poses(nusc: Any, sample_tokens: list[str]) -> list[dict[str, Any]]:
    poses: list[dict[str, Any]] = []
    for token in sample_tokens:
        sample = nusc.get("sample", token)
        ego_pose = sample_ego_pose(nusc, sample)
        if ego_pose is None:
            continue
        translation = ego_pose["translation"]
        poses.append(
            {
                "sample_token": token,
                "timestamp": float(sample["timestamp"]) / 1_000_000.0,
                "x": float(translation[0]),
                "y": float(translation[1]),
                "yaw": yaw_from_rotation(ego_pose["rotation"]),
            }
        )
    poses.sort(key=lambda pose: pose["timestamp"])
    return poses


def estimate_speeds(poses: list[dict[str, Any]]) -> np.ndarray:
    if not poses:
        return np.zeros((0,), dtype=np.float32)
    speeds = np.zeros((len(poses),), dtype=np.float32)
    for idx in range(1, len(poses)):
        dt = float(poses[idx]["timestamp"] - poses[idx - 1]["timestamp"])
        if dt <= 1e-6:
            continue
        dx = float(poses[idx]["x"] - poses[idx - 1]["x"])
        dy = float(poses[idx]["y"] - poses[idx - 1]["y"])
        speeds[idx] = math.sqrt(dx * dx + dy * dy) / dt
    if len(speeds) > 1:
        speeds[0] = speeds[1]
    return speeds


def future_agent_centers_local(
    nusc: Any,
    future_sample_tokens: list[str],
    anchor_xy: np.ndarray,
    anchor_yaw: float,
) -> list[np.ndarray]:
    centers_by_step: list[np.ndarray] = []
    for sample_token in future_sample_tokens:
        sample = nusc.get("sample", sample_token)
        centers: list[list[float]] = []
        for ann_token in sample.get("anns", []):
            ann = nusc.get("sample_annotation", ann_token)
            centers.append([float(ann["translation"][0]), float(ann["translation"][1])])
        if centers:
            centers_by_step.append(
                global_to_local(np.asarray(centers, dtype=np.float32), anchor_xy, anchor_yaw)
            )
        else:
            centers_by_step.append(np.zeros((0, 2), dtype=np.float32))
    return centers_by_step


def vector_global_to_local(vector_xy: np.ndarray, anchor_yaw: float) -> np.ndarray:
    cos_yaw = math.cos(anchor_yaw)
    sin_yaw = math.sin(anchor_yaw)
    return np.asarray(
        [
            cos_yaw * float(vector_xy[0]) + sin_yaw * float(vector_xy[1]),
            -sin_yaw * float(vector_xy[0]) + cos_yaw * float(vector_xy[1]),
        ],
        dtype=np.float32,
    )


def category_flags(category_name: str) -> tuple[float, float, float, float]:
    name = category_name.lower()
    is_vehicle = float("vehicle" in name)
    is_pedestrian = float("pedestrian" in name or "human" in name)
    is_cycle = float("bicycle" in name or "motorcycle" in name or "cycle" in name)
    is_barrier = float("barrier" in name or "trafficcone" in name or "construction" in name)
    return is_vehicle, is_pedestrian, is_cycle, is_barrier


def anchor_agent_tokens_local(
    nusc: Any,
    sample_token: str,
    anchor_xy: np.ndarray,
    anchor_yaw: float,
    max_agents: int,
) -> np.ndarray:
    sample = nusc.get("sample", sample_token)
    rows: list[np.ndarray] = []
    for ann_token in sample.get("anns", []):
        ann = nusc.get("sample_annotation", ann_token)
        center = np.asarray(ann["translation"][:2], dtype=np.float32)
        local_xy = global_to_local(center.reshape(1, 2), anchor_xy, anchor_yaw)[0]
        distance = float(np.linalg.norm(local_xy))
        try:
            velocity = np.asarray(nusc.box_velocity(ann_token)[:2], dtype=np.float32)
            if not np.isfinite(velocity).all():
                velocity = np.zeros(2, dtype=np.float32)
        except Exception:
            velocity = np.zeros(2, dtype=np.float32)
        local_velocity = vector_global_to_local(velocity, anchor_yaw)
        speed = float(np.linalg.norm(local_velocity))
        size = ann.get("size", [0.0, 0.0, 0.0])
        width = float(size[0]) if len(size) > 0 else 0.0
        length = float(size[1]) if len(size) > 1 else 0.0
        height = float(size[2]) if len(size) > 2 else 0.0
        yaw_delta = normalize_angle(yaw_from_rotation(ann["rotation"]) - anchor_yaw)
        flags = category_flags(str(ann.get("category_name", "")))
        point_count = math.log1p(float(ann.get("num_lidar_pts", 0)) + float(ann.get("num_radar_pts", 0)))
        rows.append(
            np.asarray(
                [
                    float(local_xy[0]) / 50.0,
                    float(local_xy[1]) / 50.0,
                    distance / 50.0,
                    float(yaw_delta) / math.pi,
                    length / 10.0,
                    width / 10.0,
                    height / 5.0,
                    float(local_velocity[0]) / 20.0,
                    float(local_velocity[1]) / 20.0,
                    speed / 20.0,
                    *flags,
                    point_count / 5.0,
                ],
                dtype=np.float32,
            )
        )
    rows.sort(key=lambda row: float(row[2]))
    tokens = np.zeros((max_agents, 15), dtype=np.float32)
    if rows:
        kept = np.stack(rows[:max_agents], axis=0).astype(np.float32)
        tokens[: len(kept)] = kept
    return tokens


def pad_future_agent_centers(
    future_agent_centers: list[np.ndarray],
    future_steps: int,
    max_agents: int,
) -> tuple[np.ndarray, np.ndarray]:
    padded = np.zeros((future_steps, max_agents, 2), dtype=np.float32)
    mask = np.zeros((future_steps, max_agents), dtype=np.float32)
    for step, centers in enumerate(future_agent_centers[:future_steps]):
        if centers is None or len(centers) == 0:
            continue
        kept = np.asarray(centers, dtype=np.float32)[:max_agents]
        padded[step, : len(kept)] = kept
        mask[step, : len(kept)] = 1.0
    return padded, mask


def build_records_for_clip(
    nusc: Any,
    clip_id: str,
    sample_tokens: list[str],
    config: PlannerDatasetConfig,
) -> list[PlannerRecord]:
    poses = load_clip_poses(nusc, sample_tokens)
    min_required = config.past_steps + config.future_steps
    if len(poses) < min_required:
        return []

    speeds = estimate_speeds(poses)
    xy = np.asarray([[pose["x"], pose["y"]] for pose in poses], dtype=np.float32)
    yaws = np.unwrap(np.asarray([pose["yaw"] for pose in poses], dtype=np.float32))
    records: list[PlannerRecord] = []

    first_anchor = config.past_steps - 1
    last_anchor_exclusive = len(poses) - config.future_steps
    for anchor_idx in range(first_anchor, last_anchor_exclusive):
        past_start = anchor_idx - config.past_steps + 1
        past_end = anchor_idx + 1
        future_start = anchor_idx + 1
        future_end = future_start + config.future_steps

        anchor_xy = xy[anchor_idx].astype(np.float32)
        anchor_yaw = float(yaws[anchor_idx])
        past_xy_local = global_to_local(xy[past_start:past_end], anchor_xy, anchor_yaw)
        past_yaw_delta = normalize_angle(yaws[past_start:past_end] - anchor_yaw).astype(
            np.float32
        )
        past_speeds = speeds[past_start:past_end].astype(np.float32)
        inputs = np.column_stack([past_xy_local, past_yaw_delta, past_speeds]).astype(
            np.float32
        )
        targets = global_to_local(xy[future_start:future_end], anchor_xy, anchor_yaw).astype(
            np.float32
        )
        future_tokens = [str(poses[idx]["sample_token"]) for idx in range(future_start, future_end)]
        agent_tokens = anchor_agent_tokens_local(
            nusc,
            sample_token=str(poses[anchor_idx]["sample_token"]),
            anchor_xy=anchor_xy,
            anchor_yaw=anchor_yaw,
            max_agents=int(config.max_agents),
        )
        future_agents = future_agent_centers_local(
            nusc, future_tokens, anchor_xy, anchor_yaw
        )
        future_agents_padded, future_agent_mask = pad_future_agent_centers(
            future_agents,
            future_steps=config.future_steps,
            max_agents=int(config.max_agents),
        )
        records.append(
            PlannerRecord(
                clip_id=str(clip_id),
                anchor_sample_token=str(poses[anchor_idx]["sample_token"]),
                future_sample_tokens=future_tokens,
                inputs=inputs,
                targets=targets,
                agent_tokens=agent_tokens,
                future_agent_centers_padded=future_agents_padded,
                future_agent_mask=future_agent_mask,
                future_agent_centers=future_agents,
            )
        )

    if config.max_windows_per_clip is not None and len(records) > config.max_windows_per_clip:
        records = records[: config.max_windows_per_clip]
    return records


class EgoTrajectoryDataset(Dataset):
    def __init__(
        self,
        manifest: str | Path | pd.DataFrame,
        dataroot: str,
        version: str,
        config: PlannerDatasetConfig,
        nusc: Any | None = None,
        verbose: bool = True,
    ) -> None:
        self.config = config
        self.manifest = (
            read_csv(manifest) if isinstance(manifest, (str, Path)) else manifest.copy()
        )
        require_columns(self.manifest, ["clip_id", "sample_tokens"], "planner manifest")
        self.nusc = nusc or load_nuscenes(dataroot, version, verbose=verbose)
        self.camera_features: dict[str, np.ndarray] | None = None
        self.camera_feature_dim = 0
        if config.camera_features_path:
            self.camera_features, self.camera_feature_dim = load_cached_camera_features(
                config.camera_features_path
            )
        self.trajectory_vocab: np.ndarray | None = None
        if config.trajectory_vocab_path:
            self.trajectory_vocab = load_trajectory_vocab(config.trajectory_vocab_path)
            if self.trajectory_vocab.shape[1] != config.future_steps:
                raise ValueError(
                    "trajectory vocab future_steps "
                    f"{self.trajectory_vocab.shape[1]} != dataset future_steps {config.future_steps}"
                )
        self.records = self._build_records()
        if not self.records:
            raise ValueError(
                "No planner training windows were built. "
                "Check clip length, sample_tokens, and planner horizon settings."
            )

    def _build_records(self) -> list[PlannerRecord]:
        records: list[PlannerRecord] = []
        for _, row in self.manifest.iterrows():
            sample_tokens = parse_json_list(row["sample_tokens"])
            records.extend(
                build_records_for_clip(
                    self.nusc,
                    clip_id=str(row["clip_id"]),
                    sample_tokens=sample_tokens,
                    config=self.config,
                )
            )
        return records

    @property
    def input_dim(self) -> int:
        return self.config.input_dim

    @property
    def future_steps(self) -> int:
        return self.config.future_steps

    @property
    def num_trajectory_modes(self) -> int:
        return 0 if self.trajectory_vocab is None else int(self.trajectory_vocab.shape[0])

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        record = self.records[idx]
        item: dict[str, Any] = {
            "inputs": torch.from_numpy(record.inputs.reshape(-1)),
            "targets": torch.from_numpy(record.targets),
            "record_index": idx,
            "clip_id": record.clip_id,
            "anchor_sample_token": record.anchor_sample_token,
            "agent_tokens": torch.from_numpy(record.agent_tokens),
            "future_agent_centers": torch.from_numpy(record.future_agent_centers_padded),
            "future_agent_mask": torch.from_numpy(record.future_agent_mask),
        }
        if self.camera_features is not None:
            camera_features = self.camera_features.get(record.anchor_sample_token)
            if camera_features is None:
                camera_features = np.zeros((self.camera_feature_dim,), dtype=np.float32)
            item["camera_features"] = torch.from_numpy(camera_features.astype(np.float32))
        if self.trajectory_vocab is not None:
            item["trajectory_class"] = torch.tensor(
                nearest_trajectory_class(record.targets, self.trajectory_vocab),
                dtype=torch.long,
            )
        return item
