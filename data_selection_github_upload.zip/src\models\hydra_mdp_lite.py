from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn


@dataclass(frozen=True)
class HydraMDPLiteConfig:
    ego_input_dim: int
    camera_feature_dim: int
    future_steps: int
    hidden_dim: int = 256
    fusion_dim: int = 256
    num_layers: int = 2
    dropout: float = 0.1
    trajectory_vocab: torch.Tensor | None = None
    num_modes: int = 0


def mlp_block(input_dim: int, hidden_dim: int, num_layers: int, dropout: float) -> nn.Sequential:
    if num_layers < 1:
        raise ValueError("num_layers must be at least 1")
    layers: list[nn.Module] = []
    in_dim = input_dim
    for _ in range(num_layers):
        layers.append(nn.Linear(in_dim, hidden_dim))
        layers.append(nn.LayerNorm(hidden_dim))
        layers.append(nn.ReLU())
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        in_dim = hidden_dim
    return nn.Sequential(*layers)


class HydraMDPLite(nn.Module):
    """A compact Hydra-MDP-inspired planner.

    It uses cached multi-camera visual features plus ego history. If a trajectory
    vocabulary is supplied, the model predicts trajectory logits and a residual,
    echoing the vocabulary-based planner head used by Hydra-MDP at a smaller scale.
    """

    def __init__(self, config: HydraMDPLiteConfig) -> None:
        super().__init__()
        if config.camera_feature_dim <= 0:
            raise ValueError("HydraMDPLite requires cached camera features")
        self.future_steps = config.future_steps
        self.ego_encoder = mlp_block(
            config.ego_input_dim,
            config.hidden_dim,
            max(1, config.num_layers),
            config.dropout,
        )
        self.camera_encoder = mlp_block(
            config.camera_feature_dim,
            config.hidden_dim,
            max(1, config.num_layers),
            config.dropout,
        )
        self.fusion = mlp_block(
            config.hidden_dim * 2,
            config.fusion_dim,
            max(1, config.num_layers),
            config.dropout,
        )
        self.regression_head = nn.Linear(config.fusion_dim, config.future_steps * 2)

        vocab = config.trajectory_vocab
        if vocab is not None:
            vocab = vocab.detach().float().view(vocab.shape[0], config.future_steps, 2)
            num_modes = int(vocab.shape[0])
        else:
            num_modes = int(config.num_modes)
            if num_modes > 0:
                vocab = torch.zeros(num_modes, config.future_steps, 2, dtype=torch.float32)

        self.num_modes = num_modes
        if num_modes > 0 and vocab is not None:
            self.register_buffer("trajectory_vocab", vocab)
            self.logits_head = nn.Linear(config.fusion_dim, num_modes)
        else:
            self.register_buffer(
                "trajectory_vocab", torch.zeros(0, config.future_steps, 2, dtype=torch.float32)
            )
            self.logits_head = None

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        ego = batch["inputs"] if "inputs" in batch else batch["ego"]
        if ego.ndim > 2:
            ego = ego.flatten(start_dim=1)
        camera_features = batch["camera_features"]
        if camera_features.ndim > 2:
            camera_features = camera_features.flatten(start_dim=1)

        ego_feat = self.ego_encoder(ego)
        camera_feat = self.camera_encoder(camera_features)
        fused = self.fusion(torch.cat([ego_feat, camera_feat], dim=1))
        residual_or_traj = self.regression_head(fused).view(ego.shape[0], self.future_steps, 2)

        outputs: dict[str, torch.Tensor] = {"features": fused}
        if self.logits_head is not None:
            logits = self.logits_head(fused)
            weights = torch.softmax(logits, dim=1)
            base = torch.einsum("bm,mtc->btc", weights, self.trajectory_vocab)
            outputs["trajectory"] = base + residual_or_traj
            outputs["trajectory_logits"] = logits
        else:
            outputs["trajectory"] = residual_or_traj
        return outputs
