from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.nuscenes_clips import load_nuscenes
from src.selection.ranking import build_ranked_pool, save_ranking_outputs
from src.utils.io import read_csv, read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Rank pool clips by base planner metrics.")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--pool", required=True)
    parser.add_argument("--clusters", required=True)
    parser.add_argument("--dataroot", default=None)
    parser.add_argument("--version", default=None)
    parser.add_argument("--config", default=None)
    parser.add_argument("--out-dir", default="outputs/ranking")
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--camera-features", default=None)
    parser.add_argument("--trajectory-vocab", default=None)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def dataset_config_from_sources(checkpoint: dict[str, Any], planner_cfg: dict[str, Any]) -> Any:
    from src.models.ego_planner_dataset import PlannerDatasetConfig

    checkpoint_cfg = checkpoint.get("dataset_config", {})
    return PlannerDatasetConfig(
        past_horizon_sec=float(
            planner_cfg.get("past_horizon_sec", checkpoint_cfg.get("past_horizon_sec", 2.0))
        ),
        future_horizon_sec=float(
            planner_cfg.get("future_horizon_sec", checkpoint_cfg.get("future_horizon_sec", 3.0))
        ),
        sample_interval_sec=float(
            planner_cfg.get("sample_interval_sec", checkpoint_cfg.get("sample_interval_sec", 0.5))
        ),
        collision_distance_m=float(
            planner_cfg.get("collision_distance_m", checkpoint_cfg.get("collision_distance_m", 2.0))
        ),
        max_windows_per_clip=planner_cfg.get(
            "max_windows_per_clip", checkpoint_cfg.get("max_windows_per_clip")
        ),
        camera_features_path=planner_cfg.get(
            "camera_features_path", checkpoint_cfg.get("camera_features_path")
        ),
        trajectory_vocab_path=planner_cfg.get(
            "trajectory_vocab_path", checkpoint_cfg.get("trajectory_vocab_path")
        ),
        max_agents=int(planner_cfg.get("max_agents", checkpoint_cfg.get("max_agents", 32))),
    )


def main() -> None:
    args = parse_args()
    try:
        import torch
    except ImportError as exc:
        raise SystemExit("torch is required to rank pool clips with a planner checkpoint") from exc

    from src.evaluation.metrics import aggregate_window_metrics
    from src.models.ego_planner import build_model_from_checkpoint, select_device
    from src.models.ego_planner_dataset import EgoTrajectoryDataset
    from src.models.train_utils import collect_window_metrics, make_dataloader

    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    dataset_cfg = cfg.get("dataset", {})
    planner_cfg = cfg.get("planner", {})
    if args.camera_features:
        planner_cfg = {**planner_cfg, "camera_features_path": args.camera_features}
    if args.trajectory_vocab:
        planner_cfg = {**planner_cfg, "trajectory_vocab_path": args.trajectory_vocab}
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    version = args.version or dataset_cfg.get("version") or checkpoint.get("dataset_version", "v1.0-mini")
    if not dataroot:
        raise SystemExit("--dataroot is required unless dataset.dataroot is set in --config")

    nusc = load_nuscenes(dataroot, version, verbose=not args.quiet)
    dataset_config = dataset_config_from_sources(checkpoint, planner_cfg)
    pool_dataset = EgoTrajectoryDataset(
        args.pool,
        dataroot=dataroot,
        version=version,
        config=dataset_config,
        nusc=nusc,
        verbose=False,
    )
    device = select_device(args.device or planner_cfg.get("device", "auto"))
    model = build_model_from_checkpoint(checkpoint).to(device)
    batch_size = args.batch_size or int(planner_cfg.get("batch_size", 32))
    loader = make_dataloader(pool_dataset, batch_size=batch_size, shuffle=False, num_workers=args.num_workers)
    window_metrics = collect_window_metrics(
        model,
        loader,
        pool_dataset,
        device=device,
        collision_threshold_m=dataset_config.collision_distance_m,
    )
    per_clip_metrics, _ = aggregate_window_metrics(window_metrics)
    pool = read_csv(args.pool)
    clusters = read_csv(args.clusters)
    pool_scores, ranked_pool = build_ranked_pool(
        pool,
        clusters,
        per_clip_metrics,
        weights=cfg.get("ranking", {}).get("weights"),
    )
    save_ranking_outputs(pool_scores, ranked_pool, args.out_dir)
    logger.info("Wrote ranking outputs under %s", args.out_dir)


if __name__ == "__main__":
    main()
