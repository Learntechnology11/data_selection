# 第二次改进：可靠性质量覆盖（Reliability-Quality Coverage, RQC）

本文档描述本周第二次改进的完整算法。它对应代码中的 `v2_rmc`，这里将其重新命名为更贴合方法含义的 **可靠性质量覆盖**（Reliability-Quality Coverage, RQC）。

第一阶段改进主要解决“先去掉明显坏样本，再做核心集选择”的问题。第二阶段进一步解决一个更关键的问题：

> 核心集不应该只覆盖几何空间，也不应该只偏向高梯度或高不确定样本，而应该优先覆盖“可靠、可学习、对训练有质量贡献”的样本质量分布。

因此，RQC 的目标不是把去噪、K-Center、梯度、长尾权重机械叠加，而是把它们统一成一个问题：

> 在每个类别/簇/场景块内部，用可靠性作为质量质量密度（quality mass），选择少量代表样本，使这些可靠质量在表示-梯度联合空间中的平均覆盖距离和最差尾部覆盖距离同时变小。

---

## 1. 问题定义

给定训练池：

$$
D=\{(x_i, y_i, c_i)\}_{i=1}^{N}
$$

其中：

- $x_i$：样本。当前实验中是 Fashion-MNIST 图像；迁移到自动驾驶后是一个 10s 多模态 clip。
- $y_i$：训练标签。当前是图像类别；迁移后可以是检测、分割、轨迹、规划等多任务标签。
- $c_i$：样本所属的类别、簇或场景块。当前 Fashion-MNIST 中直接使用 10 个类别；迁移到 nuScenes 后可由城市/天气/昼夜/道路拓扑/行为/风险 token/聚类结果共同形成。

目标是在预算：

$$
M=\lfloor rN \rfloor,\quad r\in\{0.1,0.3,0.5\}
$$

下选择核心集：

$$
C_r \subset D,\quad |C_r|=M
$$

并生成全局排序：

$$
\Pi=(i_1,i_2,\ldots)
$$

使得不同预算可以直接截断：

$$
C_{10}\subset C_{30}\subset C_{50}
$$

---

## 2. 输入信号

RQC 需要每个样本的四类信号。

### 2.1 表示特征

当前图像实验中，表示特征来自代理 CNN 的倒数第二层：

$$
z_i = h_\phi(x_i)
$$

迁移到自动驾驶多模态数据时，可替换为：

$$
z_i=\mathrm{Norm}[
W_c e_i^{cam};
W_l e_i^{lidar};
W_r e_i^{radar};
W_b e_i^{bev};
W_m e_i^{map};
W_\tau e_i^{traj};
W_s s_i]
$$

其中各项分别对应 camera、LiDAR、radar、BEV、map、trajectory 和 scenario token 表示。

### 2.2 代理模型预测概率

使用交叉拟合代理模型得到样本的 out-of-fold 预测：

$$
p_i = f_{\phi}^{-fold(i)}(x_i)
$$

交叉拟合的目的是避免用同一个模型既训练又评价同一批样本，降低可靠性估计中的乐观偏差。

### 2.3 Fisher-normalized 梯度

对分类头或任务头梯度做投影。当前图像分类中：

$$
\nabla_W \ell_i = (p_i-\mathrm{onehot}(y_i))h_i^\top
$$

将其展平并随机投影：

$$
\hat g_i = R\,\mathrm{vec}(\nabla_W \ell_i)
$$

经验 Fisher：

$$
\hat I=\frac{1}{N}\sum_{i=1}^{N}\hat g_i\hat g_i^\top
$$

Fisher-normalized gradient：

$$
g_i^F=(\hat I+\lambda I)^{-1/2}\hat g_i
$$

工程实现中使用 top-rank Fisher 子空间：

$$
\hat I \approx U_q\Sigma_q U_q^\top
$$

于是：

$$
g_i^F \approx U_q(\Sigma_q+\lambda I)^{-1/2}U_q^\top(\hat g_i-\bar g)
$$

### 2.4 可靠性分数

每个样本得到一个软可靠性：

$$
\rho_i\in[0,1]
$$

以及一个保守 hard reject 标记：

$$
r_i^{reject}\in\{0,1\}
$$

---

## 3. 可靠性估计

RQC 中的可靠性不是简单的 loss 取反，而是结合模型预测、特征空间位置和邻域一致性。

### 3.1 类内稳健距离

对每个类别/簇 $c$，在特征空间中计算稳健中心：

$$
\mu_c=\mathrm{median}\{z_i:c_i=c\}
$$

维度尺度使用 MAD：

$$
\sigma_c=1.4826\cdot\mathrm{median}\{|z_i-\mu_c|:c_i=c\}
$$

样本类内稳健距离：

$$
d_i^{robust}
=\sqrt{
\frac{1}{d}
\sum_{k=1}^{d}
\left(\frac{z_{ik}-\mu_{c_i,k}}{\max(\sigma_{c_i,k},\epsilon)}\right)^2
}
$$

再做类内标准化：

$$
d_i^z=
\frac{
d_i^{robust}-\mathrm{median}_{j:c_j=c_i}(d_j^{robust})
}{
\mathrm{MAD}_{j:c_j=c_i}(d_j^{robust})+\epsilon
}
$$

### 3.2 邻域标签一致性

在标准化特征空间中找 $K$ 个近邻：

$$
\mathcal N_K(i)=KNN(z_i)
$$

邻域一致性：

$$
a_i^{knn}
=
\frac{1}{K}
\sum_{j\in\mathcal N_K(i)}
\mathbf 1[c_j=c_i]
$$

如果一个样本在本类中很远，同时邻域主要属于其他类，它更可能是错标、异常或低质量样本。

### 3.3 预测冲突与不确定性

模型对当前标签的概率：

$$
p_i^{label}=p_i[y_i]
$$

最强其他类别概率：

$$
p_i^{other}=\max_{k\ne y_i}p_i[k]
$$

标签冲突：

$$
\delta_i^{conflict}=\max(p_i^{other}-p_i^{label},0)
$$

预测不确定性：

$$
u_i=1-\max_k p_i[k]
$$

### 3.4 风险函数与可靠性

将多个风险信号合成为样本风险：

$$
q_i =
\gamma_1\delta_i^{conflict}
+\gamma_2\sigma(d_i^z-\tau_d)
+\gamma_3(1-a_i^{knn})
+\gamma_4u_i
$$

当前实现默认：

$$
\gamma_1=1.8,\quad
\gamma_2=0.8,\quad
\gamma_3=1.0,\quad
\gamma_4=0.4
$$

可靠性定义为：

$$
\rho_i=\mathrm{clip}(\exp(-q_i),0.01,1.0)
$$

### 3.5 保守 hard reject

RQC 不会把所有低可靠样本都直接删除，而是只剔除多证据支持的高风险样本：

$$
Reject(i)=
\Big[
\hat y_i\ne y_i
\land
\max_k p_i[k]\ge \tau_p
\land
(d_i^z\ge\tau_z \lor a_i^{knn}\le\tau_a)
\Big]
\lor
[d_i^z\ge\tau_{hard}]
\lor
[\rho_i\le\tau_\rho]
$$

当前实现默认：

$$
\tau_p=0.80,\quad
\tau_z=2.0,\quad
\tau_a=0.45,\quad
\tau_{hard}=4.5,\quad
\tau_\rho=0.12
$$

这样区分了：

- hard but learnable：保留，只降低质量质量权重。
- noisy or broken：从候选池中保守剔除。

---

## 4. 联合选择几何

RQC 仍然保留 DriveCore 的核心思想：表示分布和训练动力学都要被覆盖。

先对表示和 Fisher gradient 分别标准化、PCA 降维：

$$
\tilde z_i = PCA_z(Standardize(z_i))
$$

$$
\tilde g_i^F = PCA_g(Standardize(g_i^F))
$$

构造联合几何：

$$
\psi_i=
\mathrm{Norm}
\left[
\sqrt{\lambda_z}\tilde z_i;
\sqrt{\lambda_g}\tilde g_i^F
\right]
$$

当前代码默认：

$$
d_z=24,\quad d_g=24,\quad \lambda_z=1,\quad \lambda_g=1
$$

迁移到自动驾驶多模态时，可以扩展为：

$$
\psi_i=
\mathrm{Norm}
\left[
\sqrt{\lambda_z}\tilde z_i;
\sqrt{\lambda_g}\tilde g_i^F;
\sqrt{\lambda_s}\tilde s_i
\right]
$$

其中 $\tilde s_i$ 是安全场景 token 或风险语义 embedding。

---

## 5. 可靠质量质量（Reliability-Quality Mass）

RQC 的关键改动是：不再把所有样本看成同等需要覆盖，而是给每个样本一个质量质量：

$$
m_i=
\begin{cases}
\rho_i + \kappa\cdot \mathbf 1[\neg Reject(i)], & \text{use reliability}\\
1, & \text{ablation: no reliability}
\end{cases}
$$

其中 $\kappa$ 是 clean mass floor。它的作用是避免可靠性模型过强时把普通干净样本权重压得太低。

当前选择阶段默认：

$$
\kappa=0.20
$$

训练权重重算时使用预算自适应 floor：

$$
\kappa(r)=\min(1.0,0.20+1.60r)
$$

所以小预算更偏向高质量高可靠样本，大预算会逐渐补回普通干净分布。

---

## 6. 簇内可靠质量覆盖目标

对每个类别/簇 $c$：

$$
D_c=\{i:c_i=c\}
$$

候选集为：

$$
P_c=\{i:c_i=c,\neg Reject(i)\}
$$

如果某个簇中所有样本都被 reject，则保留该簇中可靠性最高的一个样本作为 fallback，避免长尾簇完全消失。

给定簇内已选集合 $S_c$，样本到核心集的最近覆盖距离为：

$$
d_i(S_c)=\min_{j\in S_c}\|\psi_i-\psi_j\|_2^2
$$

簇内归一化质量：

$$
\bar m_i=\frac{m_i}{\sum_{j\in D_c}m_j}
$$

### 6.1 平均可靠质量覆盖

$$
J_c^{mean}(S_c)
=
\sum_{i\in D_c}\bar m_i d_i(S_c)
$$

这一项要求核心集覆盖大部分可靠、可学习样本的主体分布。

### 6.2 最差尾部覆盖（CVaR）

只优化均值容易漏掉簇内局部形态、少数子簇或边界区域。RQC 引入质量加权的 worst-tail 覆盖：

$$
J_c^{tail}(S_c)
=
\max_{0\le q_i\le \bar m_i,\ \sum_i q_i=\alpha}
\frac{1}{\alpha}
\sum_{i\in D_c}q_i d_i(S_c)
$$

其中 $\alpha$ 是尾部比例，当前默认：

$$
\alpha=0.10
$$

工程实现等价于：按当前覆盖距离 $d_i(S_c)$ 从大到小排序，取质量累计最高的 10% 最差覆盖样本，计算其加权平均距离。

### 6.3 RQC 簇内目标

$$
J_c(S_c)
=
(1-\eta)J_c^{mean}(S_c)
+\eta J_c^{tail}(S_c)
$$

当前默认：

$$
\eta=0.35
$$

解释：

- $\eta=0$：只做可靠质量均值覆盖，容易忽视局部边界。
- $\eta$ 太大：过度追逐边缘样本，可能重新引入噪声。
- $\eta=0.35$：在主体可靠分布和局部困难区域之间折中。

---

## 7. 贪心选择

RQC 使用贪心边际收益近似求解。

候选 $j\in P_c\setminus S_c$ 的原始收益：

$$
\Delta_c(j\mid S_c)
=
J_c(S_c)-J_c(S_c\cup\{j\})
$$

为了避免低可靠异常点仅因几何位置偏远而被过早选入，候选收益再乘以候选质量调制项：

$$
\widehat\Delta_c(j\mid S_c)
=
\sqrt{\max(m_j,\epsilon)}
\cdot
\Delta_c(j\mid S_c)
$$

其中使用平方根而不是线性乘法，是为了保留一部分 hard-but-learnable 样本的机会，不让可靠性成为绝对门槛。

### 7.1 初始化

每个簇先从候选池中选一个 seed。候选 seed 先按单点平均覆盖距离取 shortlist：

$$
Shortlist_c=\mathrm{TopSmall}_{32}
\left(
\sum_{i\in D_c}\bar m_i\|\psi_i-\psi_j\|^2
\right)
$$

然后选择质量校正后的目标最小者：

$$
j_c^{seed}
=
\arg\min_{j\in Shortlist_c}
\frac{J_c(\{j\})}{\max(m_j,0.10)}
$$

### 7.2 Lazy greedy

朴素贪心每一步都重算所有候选收益，代价较高。当前实现使用 lazy greedy：

1. 先计算每个候选的近似收益上界并放入最大堆。
2. 每一步弹出堆顶候选。
3. 对该候选计算精确收益。
4. 如果精确收益仍不低于下一个候选上界，则接受。
5. 否则把更新后的收益放回堆中。

这样在候选池较大时可以显著减少重复计算。

---

## 8. 不均衡簇的动态预算分配

真实数据集中每个类/簇数量不同，可靠样本密度也不同。RQC 不使用固定 class-balanced 配额，而是基于可靠质量自动分配预算。

簇质量占比：

$$
\pi_c=
\frac{\sum_{i\in D_c}m_i}{\sum_{i=1}^{N}m_i}
$$

簇级调度权重：

$$
w_c^{sched}=\pi_c^{\beta}
$$

当前默认：

$$
\beta=1.0
$$

每个簇内部先生成局部排序：

$$
\Pi_c=(i_{c,1},i_{c,2},\ldots)
$$

全局合并时，每一步选择加权边际收益最大的簇：

$$
c^\*=
\arg\max_c
w_c^{sched}\cdot
\widehat\Delta_c(i_{c,k_c+1}\mid S_c)
$$

然后从该簇弹出下一个样本。这样自然得到不均衡分配：

- 大簇会获得更多预算，但只有在仍有高边际覆盖收益时才继续增加。
- 长尾簇不会被平均分配过多无效样本。
- 少数但可靠质量高、局部覆盖差的簇仍然会获得额外预算。

---

## 9. 训练权重

RQC 不建议无权训练。选出核心集后，给样本分配代表质量权重。

对每个被选样本 $j\in C$，计算同簇 Voronoi 责任区域：

$$
V_j=
\{i:c_i=c_j,\ 
j=\arg\min_{k\in C, c_k=c_i}\|\psi_i-\psi_k\|_2^2
\}
$$

代表质量：

$$
a_j^{raw}=\sum_{i\in V_j}m_i
$$

然后做均值为 1 的有界归一化：

$$
a_j=
\mathrm{clip\_mean\_one}
(a_j^{raw},a_{min},a_{max})
$$

当前实现：

$$
a_{min}=0.25,\quad a_{max}=4.0
$$

训练目标：

$$
\mathcal L_C(\theta)
=
\frac{1}{|C|}
\sum_{j\in C}
a_j\mathcal L(f_\theta(x_j),y_j)
$$

---

## 10. 完整算法流程

```text
Algorithm: Reliability-Quality Coverage (RQC)

Input:
    Dataset D = {(x_i, y_i, c_i)}
    Budget M
    Proxy / teacher model
    Hyperparameters eta, tail_fraction, clean_mass_floor, cluster_alpha

Output:
    Global ranking Pi
    Coreset C_r by truncation
    Training weights a_i

1. Train cross-fitted proxy models.

2. For every sample i:
       extract representation z_i
       obtain out-of-fold probability p_i
       compute loss and prediction conflict

3. Build projected task-head gradient:
       g_hat_i = RandomProjection(vec((p_i - onehot(y_i)) h_i^T))

4. Estimate empirical Fisher and normalize:
       g_i^F = (I_hat + lambda I)^(-1/2) g_hat_i

5. Estimate reliability:
       compute robust class distance d_i^z
       compute KNN agreement a_i^knn
       compute conflict and uncertainty
       rho_i = exp(-risk_i)
       reject_i = conservative multi-evidence rejection rule

6. Build joint geometry:
       psi_i = Norm([sqrt(lambda_z) z_tilde_i;
                     sqrt(lambda_g) g_i^F_tilde])

7. Build reliability-quality mass:
       m_i = rho_i + clean_mass_floor * 1[not reject_i]

8. For every cluster c:
       D_c = samples in cluster c
       P_c = non-rejected candidates in cluster c
       if P_c is empty:
           keep the most reliable fallback sample

       Initialize local order with a quality-adjusted medoid seed.

       while local candidates remain:
           compute current distance d_i(S_c)
           compute mean coverage objective
           compute tail CVaR coverage objective
           select candidate with largest reliability-modulated
           objective reduction

       Return local ranking Pi_c and local marginal gains.

9. Merge local rankings:
       compute cluster mass pi_c
       repeatedly select the cluster with largest
       pi_c^cluster_alpha * next_local_gain
       append its next sample to global ranking Pi

10. Compute representative training weights:
       assign every original sample to nearest selected sample
       within the same cluster
       sum reliability-quality mass
       clip and normalize weights to mean one

Return:
       Pi, C_10, C_30, C_50, {a_i}
```

---

## 11. 当前 Fashion-MNIST 适配方式

当前项目中 RQC 在 Fashion-MNIST 上的适配如下：

| 自动驾驶 DriveCore 概念 | Fashion-MNIST 当前替代 |
|---|---|
| 10s clip | 单张图像 |
| 多模态表示 $z_i$ | CNN embedding |
| 任务头梯度 | 分类头梯度 |
| Fisher-normalized gradient | 分类头 projected gradient 的 Fisher whitening |
| 场景簇/strata | 10 个图像类别 |
| 安全 token / 长尾语义 | long-tail 类别与噪声场景 |
| 传感器坏点 / 标注冲突 | label flip、Gaussian corruption、occlusion |
| temporal NMS | 当前图像实验未启用；迁移到 nuScenes 后加入 log/time NMS |

Fashion-MNIST 不是最终目标，但它提供了一个可控验证场：

- 类别数量明确，可模拟“簇已知”。
- 可构造 long-tail 训练池。
- 可注入 label noise 和图像 corruption。
- 可以观察核心集在低预算下是否过度偏难样本或异常点。
- 可以验证 RQC 是否比单纯去噪或 K-Center 更稳定。

---

## 12. 迁移到 nuScenes / 自动驾驶多模态数据

迁移时不需要改变 RQC 的核心选择器，只需替换输入信号。

### 12.1 样本单位

从单图像替换为 10s clip：

$$
x_i=(I_i,P_i,R_i,B_i,M_i,\tau_i)
$$

其中包括 camera、LiDAR、radar、BEV、map 和 trajectory context。

### 12.2 簇/块定义

Fashion-MNIST 中：

$$
c_i=y_i\in\{0,\ldots,9\}
$$

nuScenes 中建议：

$$
c_i=(city, weather, time, road\ type, map\ topology, ego\ behavior, risk\ tag)
$$

再在每个粗 strata 内对 $\tilde z_i$ 聚类，得到 block id。

### 12.3 可靠性替换

当前图像可靠性来自：

$$
prediction\ conflict + robust\ distance + KNN\ agreement + uncertainty
$$

自动驾驶中可以扩展为：

$$
q_i =
\gamma_1 TeacherConflict_i
+\gamma_2 OOD(z_i)
+\gamma_3 SensorBad_i
+\gamma_4 LabelConflict_i
+\gamma_5 TemporalBroken_i
+\gamma_6 MapInconsistency_i
$$

可靠性仍然保持：

$$
\rho_i=\exp(-q_i)
$$

hard reject 仍然要求多证据，而不是单一高 loss：

$$
Reject(i)=1
\quad\text{only if multiple bad-data evidences agree}
$$

### 12.4 候选集中的时序约束

当前 Fashion-MNIST 无时间维。迁移后应在候选池中加入 temporal NMS：

$$
Conflict(i,j)=
\mathbf 1[log_i=log_j]
\mathbf 1[|t_i-t_j|<\Delta t]
\mathbf 1[sim(\psi_i,\psi_j)>\tau_\psi]
$$

如果冲突，则同一局部窗口内只保留可靠质量收益更高的 clip。

### 12.5 安全 token 约束

RQC 可以与 DriveCore 的安全 token 约束叠加，但建议把安全覆盖作为约束，而不是普通加分项：

$$
\sum_{i\in C}
\mathbf 1[a\in A_i]
\ge b_a,\quad \forall a\in A_{safe}
$$

实现方式是在每个 block 选择前先保留安全 token 的最低候选配额，或者在全局 merge 后做一次 safety repair。

---

## 13. 代码对应关系

核心实现文件：

- `fashion_mnist_coreset/reliability_quality_coverage.py`
  - 独立、可迁移的 RQC 选择器。
  - 不依赖 Fashion-MNIST 数据加载。
  - 主要函数：
    - `estimate_reliability`
    - `projected_gradient_embedding`
    - `fisher_normalize`
    - `build_joint_geometry`
    - `select_reliability_quality_coverage`
    - `compute_representative_weights`

- `fashion_mnist_coreset/research_selectors.py`
  - 当前实验版 V0/V1/V2 选择器。
  - `select_v2_reliability_mass` 是本算法在周实验中的实现。

- `fashion_mnist_coreset/proxy_signals.py`
  - 代理模型训练、cross-fit 概率、embedding、gradient、Fisher 和可靠性估计。

- `fashion_mnist_coreset/run_weekly_research.py`
  - 完整实验入口。
  - 包含核心集构建、训练、验证集 early stopping、测试集评价、可视化和结果汇总。

---

## 14. 主要输出与分析指标

RQC 相关实验会输出：

### 14.1 核心集 JSON

每个预算对应：

```text
selected_v2_rmc_10.json
selected_v2_rmc_30.json
selected_v2_rmc_50.json
```

包含：

- selected sample indices
- training weights
- diagnostics
- allocation trajectory

### 14.2 分布与覆盖分析

选择分析指标包括：

$$
selected\_noise\_rate
$$

$$
selected\_mean\_reliability
$$

$$
class\_l1\_to\_full
=
\|p_{selected}(c)-p_{full}(c)\|_1
$$

$$
coverage\_mean
=
\frac{1}{N}\sum_i d_i(C)
$$

$$
coverage\_p95
=
Quantile_{0.95}(d_i(C))
$$

可靠质量覆盖指标：

$$
RQ\_Mean
=
\sum_i
\frac{\rho_i}{\sum_j\rho_j}
d_i(C)
$$

$$
RQ\_CVaR10
=
CVaR_{10\%}^{\rho}
(d_i(C))
$$

### 14.3 训练评价

每个核心集训练后输出：

- validation loss / accuracy history
- best epoch
- test accuracy
- balanced accuracy
- macro F1
- per-class accuracy
- confusion matrix

---

## 15. 当前 pilot 观察

在 long-tail mixed-noise Fashion-MNIST pilot 设置下，RQC 相比 random、只去噪和 Fisher-Geodesic K-Center 更稳定：

| 方法 | 10% 测试准确率 | 50% 测试准确率 |
|---|---:|---:|
| Random | 75.75% ± 1.18% | 81.22% ± 0.56% |
| V0 Denoise | 69.43% ± 0.30% | 81.78% ± 1.49% |
| V1 Fisher-Geodesic | 72.05% ± 3.14% | 81.52% ± 1.60% |
| RQC / V2 | **77.96% ± 0.92%** | **82.81% ± 1.07%** |
| Full Data | 84.03% ± 0.47% | 84.03% ± 0.47% |

这个结果说明：

1. 单纯去噪不够。低预算下如果只剔除坏样本再做原始选择，容易损失覆盖性。
2. 单纯 K-Center 不够。它会追逐几何边界，低预算下容易把低可靠异常边缘点当成“覆盖价值”。
3. RQC 的优势在于把“可靠性”和“覆盖”合成一个质量覆盖目标：既不让噪声主导边界覆盖，也不牺牲主体分布。

---

## 16. 可消融项

为了证明 RQC 不是大杂烩，建议保留以下消融：

1. `v2_no_reliability`

   $m_i=1$，只看覆盖，验证可靠质量密度是否必要。

2. `v2_no_cvar`

   $\eta=0$，只优化平均覆盖，验证 worst-tail 覆盖是否必要。

3. `v1_no_fisher`

   去掉 Fisher-normalized gradient，验证训练动力学几何是否必要。

4. `v1_gc`

   只做 Fisher-Geodesic K-Center，验证 RQC 是否解决边缘异常点问题。

---

## 17. 与 DriveCore 主线的关系

RQC 是 DriveCore 中“可靠性门控与噪声控制 + 覆盖式核心集构建”的一次深化。

DriveCore 主目标：

$$
10s\ Clip
+Multimodal\ Representation\ Matching
+Fisher\ Normalized\ Gradient\ Matching
+Safety\ Coverage
+Temporal\ NonRedundancy
$$

RQC 当前解决的是其中两部分之间的耦合：

$$
Reliability\ Gate
+Representation/Gradient\ Coverage
\Rightarrow
Reliability\ Quality\ Coverage
$$

它的迁移价值在于：真实自动驾驶数据中存在大量非均衡场景、异常片段、传感器坏点、同步问题和标注冲突。如果核心集构建只追逐几何边缘或高 loss，很容易把坏数据选进去。RQC 将可靠样本视为需要覆盖的质量密度，能在不完全丢弃困难样本的前提下，降低异常点对核心集的干扰。

