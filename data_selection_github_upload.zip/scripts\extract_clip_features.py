from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.features.clip_features import FeatureConfig, extract_and_save_features
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract metadata, ego-motion, and agent-density features for nuScenes clips."
    )
    parser.add_argument("--config", type=str, default=None, help="Optional YAML config path.")
    parser.add_argument("--dataroot", type=str, default=None)
    parser.add_argument("--version", type=str, default=None)
    parser.add_argument("--clips", type=str, required=False, help="Input clips CSV.")
    parser.add_argument("--out-dir", type=str, default="outputs/features")
    parser.add_argument("--tfidf-max-features", type=int, default=None)
    parser.add_argument("--no-location", action="store_true")
    parser.add_argument("--no-description-tfidf", action="store_true")
    parser.add_argument("--no-ego-motion", action="store_true")
    parser.add_argument("--no-agent-density", action="store_true")
    parser.add_argument("--fill-nan", choices=["median", "zero"], default=None)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    dataset_cfg = cfg.get("dataset", {})
    feature_cfg = cfg.get("features", {})

    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version")
    if not dataroot or not version:
        raise SystemExit("--dataroot and --version are required unless provided by --config")
    if not args.clips:
        raise SystemExit("--clips is required")

    config = FeatureConfig(
        dataroot=dataroot,
        version=version,
        use_location=bool(feature_cfg.get("use_location", True)) and not args.no_location,
        use_description_tfidf=bool(feature_cfg.get("use_description_tfidf", True))
        and not args.no_description_tfidf,
        tfidf_max_features=args.tfidf_max_features
        if args.tfidf_max_features is not None
        else int(feature_cfg.get("tfidf_max_features", 256)),
        use_ego_motion=bool(feature_cfg.get("use_ego_motion", True)) and not args.no_ego_motion,
        use_agent_density=bool(feature_cfg.get("use_agent_density", True))
        and not args.no_agent_density,
        fill_nan=args.fill_nan or feature_cfg.get("fill_nan", "median"),
        verbose=not args.quiet,
    )
    features, columns, paths = extract_and_save_features(args.clips, args.out_dir, config)
    logger.info("Wrote feature parquet: %s", paths["parquet"])
    logger.info("Wrote feature matrix: %s", paths["npy"])
    logger.info("Wrote %d clips with %d numeric feature columns", len(features), len(columns))
    logger.info(
        "Feature groups: raw_numeric=%d, metadata_extra=%d",
        len([column for column in columns if not column.startswith(("location_", "description_tfidf_"))]),
        len([column for column in columns if column.startswith(("location_", "description_tfidf_"))]),
    )


if __name__ == "__main__":
    main()
