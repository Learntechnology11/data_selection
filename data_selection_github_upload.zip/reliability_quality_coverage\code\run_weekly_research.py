"""Run the V0/V1/V2 DriveCore weekly research study."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path
import sys
from typing import Any, Dict, List, Mapping, Sequence

import numpy as np
import torch
from torch.utils.data import Subset
from torchvision import datasets, transforms

ROOT = Path(__file__).resolve().parent
REPO_ROOT = ROOT.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from fashion_mnist_coreset.algorithms import DatasetArrays, drivecore_coreset
from fashion_mnist_coreset.data_protocols import (
    ArrayFashionDataset,
    ResearchPool,
    build_research_pool,
    stratified_train_val_indices,
)
from fashion_mnist_coreset.models import train_validate_test
from fashion_mnist_coreset.plots import plot_confusion_matrix, plot_training_history, save_json
from fashion_mnist_coreset.proxy_signals import ProxySignals, build_proxy_signals
from fashion_mnist_coreset.research_selectors import (
    ResearchSelection,
    build_joint_geometry,
    compute_voronoi_weights,
    select_feature_kcenter,
    select_v0_denoise,
    select_v1_fisher_geodesic,
    select_v2_reliability_mass,
)
from fashion_mnist_coreset.weekly_plots import (
    plot_allocation_trajectory,
    plot_class_budget,
    plot_coverage_cdf,
    plot_failure_grid,
    plot_joint_embedding,
    plot_noise_retention,
    plot_reliability_distance,
)


DEFAULT_METHODS = [
    "random",
    "class_balanced",
    "drivecore_original",
    "feature_kcenter",
    "v0_denoise",
    "v1_gc",
    "v2_rmc",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", default=str(ROOT / "data"))
    parser.add_argument("--output-dir", default=str(ROOT / "outputs" / "weekly_research"))
    parser.add_argument("--download", action="store_true")
    parser.add_argument(
        "--scenarios",
        nargs="+",
        default=["balanced_clean", "long_tail_clean", "long_tail_mixed_noise"],
        choices=["balanced_clean", "long_tail_clean", "long_tail_mixed_noise"],
    )
    parser.add_argument("--methods", nargs="+", default=DEFAULT_METHODS)
    parser.add_argument("--budgets", nargs="+", type=float, default=[0.1, 0.3, 0.5])
    parser.add_argument("--seeds", nargs="+", type=int, default=[42, 43, 44])
    parser.add_argument("--max-train", type=int, default=60000)
    parser.add_argument("--val-size", type=int, default=10000)
    parser.add_argument("--imbalance-factor", type=float, default=0.2)
    parser.add_argument("--noise-rate", type=float, default=0.15)
    parser.add_argument("--proxy-epochs", type=int, default=8)
    parser.add_argument("--proxy-folds", type=int, default=2)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--skip-training", action="store_true")
    parser.add_argument("--force-proxy", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_root = Path(args.output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    train_base, test_dataset = _load_datasets(Path(args.data_root), args.download)
    all_rows: List[Dict[str, Any]] = []
    all_selection_rows: List[Dict[str, Any]] = []

    max_train = min(int(args.max_train), len(train_base))
    labels_prefix = train_base.targets.numpy()[:max_train]
    val_size = min(int(args.val_size), max(100, max_train // 5))

    for scenario in args.scenarios:
        for seed in args.seeds:
            _seed(seed)
            seed_dir = output_root / scenario / f"seed_{seed}"
            pool_source, val_indices = stratified_train_val_indices(labels_prefix, val_size, seed)
            pool = build_research_pool(
                train_base.data.numpy()[:max_train],
                labels_prefix,
                pool_source,
                scenario=scenario,
                imbalance_factor=args.imbalance_factor,
                noise_rate=args.noise_rate,
                seed=seed,
            )
            pool_dataset = ArrayFashionDataset(pool.images, pool.observed_labels)
            val_dataset = Subset(train_base, val_indices.tolist())
            device = _device(args.device)
            signals = build_proxy_signals(
                pool_dataset,
                pool.observed_labels,
                pool.noise_mask,
                seed_dir / "proxy",
                epochs=args.proxy_epochs,
                batch_size=args.batch_size,
                folds=args.proxy_folds,
                seed=seed,
                device=device,
                force=args.force_proxy,
            )
            geometry = build_joint_geometry(signals)
            max_budget = max(_budget_count(value, len(pool.observed_labels)) for value in args.budgets)
            selections = _build_selections(pool, signals, geometry, max_budget, args.methods, seed)
            scenario_rows, selection_rows = _run_seed(
                pool,
                pool_dataset,
                val_dataset,
                test_dataset,
                signals,
                geometry,
                selections,
                scenario,
                seed,
                seed_dir,
                args,
                device,
            )
            all_rows.extend(scenario_rows)
            all_selection_rows.extend(selection_rows)

    _write_csv(all_rows, output_root / "evaluation_all_runs.csv")
    _write_csv(all_selection_rows, output_root / "selection_analysis_all_runs.csv")
    aggregate = _aggregate_rows(all_rows)
    selection_aggregate = _aggregate_rows(all_selection_rows)
    _write_csv(aggregate, output_root / "evaluation_aggregate.csv")
    _write_csv(selection_aggregate, output_root / "selection_analysis_aggregate.csv")
    save_json({"rows": aggregate}, output_root / "evaluation_aggregate.json")
    _write_markdown_report(aggregate, selection_aggregate, output_root / "WEEKLY_REPORT.md")
    plot_noise_retention(all_selection_rows, output_root / "noise_retention_all_runs.png")
    print(f"Wrote weekly research study to {output_root}")


def _build_selections(
    pool: ResearchPool,
    signals: ProxySignals,
    geometry: np.ndarray,
    max_budget: int,
    methods: Sequence[str],
    seed: int,
) -> Dict[str, ResearchSelection]:
    selections: Dict[str, ResearchSelection] = {}
    n = len(pool.observed_labels)
    if "random" in methods:
        rng = np.random.default_rng(seed)
        ranking = rng.permutation(n)[:max_budget].astype(int).tolist()
        selections["random"] = _simple_selection("random", ranking, pool, signals)
    if "class_balanced" in methods:
        ranking = _class_balanced_ranking(pool.observed_labels, max_budget, seed)
        selections["class_balanced"] = _simple_selection("class_balanced", ranking, pool, signals)
    if "drivecore_original" in methods:
        data = DatasetArrays(pool.images, pool.observed_labels, np.arange(n))
        result = drivecore_coreset(data, signals.embeddings, max_budget, seed)
        selections["drivecore_original"] = _simple_selection(
            "drivecore_original",
            result.selected_indices,
            pool,
            signals,
            result.weights,
        )
    if "feature_kcenter" in methods:
        selections["feature_kcenter"] = select_feature_kcenter(pool, signals, max_budget)
    if "v0_denoise" in methods:
        selections["v0_denoise"] = select_v0_denoise(pool, signals, max_budget, seed=seed)
    if "v1_gc" in methods:
        selections["v1_gc"] = select_v1_fisher_geodesic(pool, signals, max_budget)
    if "v1_no_fisher" in methods:
        selections["v1_no_fisher"] = select_v1_fisher_geodesic(pool, signals, max_budget, lambda_g=0.0)
    if "v2_rmc" in methods:
        selections["v2_rmc"] = select_v2_reliability_mass(pool, signals, max_budget)
    if "v2_no_reliability" in methods:
        selections["v2_no_reliability"] = select_v2_reliability_mass(
            pool,
            signals,
            max_budget,
            use_reliability=False,
        )
    if "v2_no_cvar" in methods:
        selections["v2_no_cvar"] = select_v2_reliability_mass(
            pool,
            signals,
            max_budget,
            eta=0.0,
        )
    return selections


def _run_seed(
    pool: ResearchPool,
    pool_dataset: ArrayFashionDataset,
    val_dataset,
    test_dataset,
    signals: ProxySignals,
    geometry: np.ndarray,
    selections: Mapping[str, ResearchSelection],
    scenario: str,
    seed: int,
    seed_dir: Path,
    args: argparse.Namespace,
    device: str,
) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    evaluation_rows: List[Dict[str, Any]] = []
    selection_rows: List[Dict[str, Any]] = []
    selected_for_budget_plot: Dict[str, Sequence[int]] = {}
    coverage_curves: Dict[str, Sequence[float]] = {}

    _save_pool_summary(pool, signals, scenario, seed, seed_dir)
    full_row = {
        "scenario": scenario,
        "seed": seed,
        "run": "full_data",
        "method": "full_data",
        "budget": 100,
        "num_selected": len(pool.observed_labels),
    }
    if not args.skip_training:
        metrics = _train_run(
            pool_dataset,
            val_dataset,
            test_dataset,
            list(range(len(pool.observed_labels))),
            [],
            seed_dir / "runs" / "full_data",
            args,
            seed,
            device,
        )
        full_row.update(metrics)
    evaluation_rows.append(full_row)

    for raw_budget in sorted(args.budgets):
        budget = _budget_count(raw_budget, len(pool.observed_labels))
        budget_name = int(round(raw_budget * 100)) if raw_budget <= 1.0 else int(raw_budget)
        for method, full_selection in selections.items():
            selected = full_selection.ranking[:budget]
            if method == "v2_rmc":
                budget_ratio = len(selected) / max(len(pool.observed_labels), 1)
                clean_floor = min(1.0, 0.20 + 1.60 * budget_ratio)
                demand_weight = signals.reliability + clean_floor * (~signals.reject_mask).astype(np.float64)
            else:
                demand_weight = (~signals.reject_mask).astype(np.float64)
            weights = compute_voronoi_weights(geometry, pool.observed_labels, selected, demand_weight)
            run_name = f"{method}_{budget_name}"
            run_dir = seed_dir / "runs" / run_name
            subset_path = _save_subset(pool, signals, selected, weights, full_selection, budget_name, seed_dir / "subsets")
            distances = _nearest_distances(geometry, selected)
            row = {
                "scenario": scenario,
                "seed": seed,
                "run": run_name,
                "method": method,
                "budget": budget_name,
                "num_selected": len(selected),
                "subset_path": str(subset_path),
            }
            if not args.skip_training:
                metrics = _train_run(
                    pool_dataset,
                    val_dataset,
                    test_dataset,
                    selected,
                    weights,
                    run_dir,
                    args,
                    seed,
                    device,
                )
                row.update(metrics)
            evaluation_rows.append(row)

            selection_row = _selection_metrics(
                pool,
                signals,
                geometry,
                selected,
                weights,
                distances,
                scenario,
                seed,
                method,
                budget_name,
            )
            selection_rows.append(selection_row)
            if raw_budget == max(args.budgets):
                selected_for_budget_plot[method] = selected
                coverage_curves[method] = distances
                plot_joint_embedding(
                    geometry,
                    pool.observed_labels,
                    selected,
                    signals.reject_mask,
                    pool.noise_mask,
                    seed_dir / "plots" / f"joint_embedding_{method}_{budget_name}.png",
                    f"{scenario} {method} {budget_name}%",
                )
                plot_allocation_trajectory(
                    full_selection.trajectory[:budget],
                    seed_dir / "plots" / f"allocation_{method}_{budget_name}.png",
                    f"Dynamic class allocation: {method}",
                )
                plot_reliability_distance(
                    signals.reliability,
                    distances,
                    selected,
                    pool.noise_mask,
                    seed_dir / "plots" / f"reliability_distance_{method}_{budget_name}.png",
                    f"Reliability and coverage: {method}",
                )

    if selected_for_budget_plot:
        plot_class_budget(
            pool.observed_labels,
            ~signals.reject_mask,
            selected_for_budget_plot,
            seed_dir / "plots" / "class_budget_comparison.png",
        )
        plot_coverage_cdf(
            coverage_curves,
            seed_dir / "plots" / "coverage_cdf.png",
            f"Coverage CDF: {scenario}, seed {seed}",
        )
    if "v1_gc" in selected_for_budget_plot and "v2_rmc" in selected_for_budget_plot:
        v1_only = [
            idx
            for idx in selected_for_budget_plot["v1_gc"]
            if idx not in set(selected_for_budget_plot["v2_rmc"])
        ]
        v1_only.sort(key=lambda idx: signals.reliability[idx])
        plot_failure_grid(
            pool.images,
            pool.observed_labels,
            signals.reliability,
            v1_only,
            seed_dir / "plots" / "v1_edge_cases_avoided_by_v2.png",
            "V1 edge samples delayed or avoided by V2",
        )
    _write_csv(evaluation_rows, seed_dir / "evaluation.csv")
    _write_csv(selection_rows, seed_dir / "selection_analysis.csv")
    return evaluation_rows, selection_rows


def _train_run(
    pool_dataset: ArrayFashionDataset,
    val_dataset,
    test_dataset,
    selected: Sequence[int],
    weights: Sequence[float],
    run_dir: Path,
    args: argparse.Namespace,
    seed: int,
    device: str,
) -> Dict[str, Any]:
    metrics = train_validate_test(
        pool_dataset,
        [],
        test_dataset,
        selected,
        weights,
        epochs=args.epochs,
        patience=args.patience,
        min_delta=1e-4,
        batch_size=args.batch_size,
        seed=seed,
        device=device,
        run_dir=run_dir,
        val_dataset=val_dataset,
    )
    confusion = metrics.pop("confusion_matrix")
    per_class = metrics.pop("per_class_accuracy")
    save_json(confusion, run_dir / "confusion_matrix.json")
    save_json(per_class, run_dir / "per_class_accuracy.json")
    plot_confusion_matrix(confusion, run_dir / "confusion_matrix.png", run_dir.name)
    plot_training_history(Path(metrics["history_path"]), run_dir / "history.png", run_dir.name)
    metrics.update({f"test_acc_class_{cls}": per_class[str(cls)] for cls in range(10)})
    return metrics


def _selection_metrics(
    pool: ResearchPool,
    signals: ProxySignals,
    geometry: np.ndarray,
    selected: Sequence[int],
    weights: Sequence[float],
    distances: np.ndarray,
    scenario: str,
    seed: int,
    method: str,
    budget: int,
) -> Dict[str, Any]:
    selected_arr = np.asarray(selected, dtype=np.int64)
    selected_labels = pool.observed_labels[selected_arr]
    full_dist = np.bincount(pool.observed_labels, minlength=10) / max(len(pool.observed_labels), 1)
    selected_dist = np.bincount(selected_labels, minlength=10) / max(len(selected_labels), 1)
    weight_arr = np.asarray(weights, dtype=np.float64)
    if len(weight_arr) != len(selected_arr):
        weight_arr = np.ones(len(selected_arr), dtype=np.float64)
    weight_arr = weight_arr / max(weight_arr.sum(), 1e-12)
    representation_residual = np.linalg.norm(
        geometry.mean(axis=0) - np.sum(weight_arr[:, None] * geometry[selected_arr], axis=0)
    )
    gradient_residual = np.linalg.norm(
        signals.fisher_gradient.mean(axis=0)
        - np.sum(weight_arr[:, None] * signals.fisher_gradient[selected_arr], axis=0)
    )
    clean_distances = distances[~signals.reject_mask]
    reliability_mass = signals.reliability / max(float(signals.reliability.sum()), 1e-12)
    reliability_weighted_mean = float(np.dot(reliability_mass, distances))
    reliability_cvar = _weighted_cvar(distances, reliability_mass, 0.10)
    return {
        "scenario": scenario,
        "seed": seed,
        "method": method,
        "budget": budget,
        "num_selected": len(selected_arr),
        "selected_noise_rate": float(pool.noise_mask[selected_arr].mean()) if len(selected_arr) else 0.0,
        "selected_mean_reliability": float(signals.reliability[selected_arr].mean()) if len(selected_arr) else 0.0,
        "class_l1_to_full": float(np.abs(full_dist - selected_dist).sum()),
        "coverage_mean": float(distances.mean()),
        "coverage_p90": float(np.quantile(distances, 0.90)),
        "coverage_p95": float(np.quantile(distances, 0.95)),
        "coverage_max": float(distances.max()),
        "clean_coverage_mean": float(clean_distances.mean()) if len(clean_distances) else 0.0,
        "clean_coverage_p95": float(np.quantile(clean_distances, 0.95)) if len(clean_distances) else 0.0,
        "clean_coverage_max": float(clean_distances.max()) if len(clean_distances) else 0.0,
        "reliability_weighted_coverage_mean": reliability_weighted_mean,
        "reliability_weighted_coverage_cvar10": reliability_cvar,
        "representation_mean_residual": float(representation_residual),
        "fisher_gradient_mean_residual": float(gradient_residual),
        "selected_rejected_rate": float(signals.reject_mask[selected_arr].mean()) if len(selected_arr) else 0.0,
        **{f"selected_class_{cls}": int(np.sum(selected_labels == cls)) for cls in range(10)},
    }


def _weighted_cvar(values: np.ndarray, weights: np.ndarray, tail_fraction: float) -> float:
    order = np.argsort(values)[::-1]
    target = float(tail_fraction)
    accumulated = 0.0
    total = 0.0
    for idx in order:
        remaining = target - accumulated
        if remaining <= 1e-12:
            break
        take = min(float(weights[idx]), remaining)
        total += take * float(values[idx])
        accumulated += take
    return total / max(accumulated, 1e-12)


def _nearest_distances(geometry: np.ndarray, selected: Sequence[int], chunk: int = 512) -> np.ndarray:
    selected_points = geometry[list(selected)]
    distances = []
    for start in range(0, len(geometry), chunk):
        block = geometry[start : start + chunk]
        d2 = (
            np.sum(block * block, axis=1, keepdims=True)
            + np.sum(selected_points * selected_points, axis=1, keepdims=True).T
            - 2.0 * (block @ selected_points.T)
        )
        distances.extend(np.sqrt(np.maximum(d2.min(axis=1), 0.0)).tolist())
    return np.asarray(distances, dtype=np.float64)


def _simple_selection(
    method: str,
    ranking: Sequence[int],
    pool: ResearchPool,
    signals: ProxySignals,
    weights: Sequence[float] | None = None,
) -> ResearchSelection:
    ranking_list = [int(idx) for idx in ranking]
    trajectory = [
        {
            "step": step,
            "method": method,
            "class": int(pool.observed_labels[idx]),
            "sample_index": idx,
            "marginal_gain": 0.0,
            "class_selected_count": 0,
        }
        for step, idx in enumerate(ranking_list, start=1)
    ]
    return ResearchSelection(
        method,
        ranking_list,
        list(weights or [1.0] * len(ranking_list)),
        {
            "class_counts": dict(Counter(int(pool.observed_labels[idx]) for idx in ranking_list)),
            "mean_reliability": float(signals.reliability[ranking_list].mean()) if ranking_list else 0.0,
        },
        trajectory,
    )


def _class_balanced_ranking(labels: np.ndarray, budget: int, seed: int) -> List[int]:
    rng = np.random.default_rng(seed)
    queues = {}
    for cls in range(10):
        indices = np.flatnonzero(labels == cls)
        queues[cls] = rng.permutation(indices).astype(int).tolist()
    positions = {cls: 0 for cls in range(10)}
    ranking: List[int] = []
    while len(ranking) < budget:
        changed = False
        for cls in range(10):
            pos = positions[cls]
            if pos >= len(queues[cls]):
                continue
            ranking.append(int(queues[cls][pos]))
            positions[cls] += 1
            changed = True
            if len(ranking) >= budget:
                break
        if not changed:
            break
    return ranking


def _save_subset(
    pool: ResearchPool,
    signals: ProxySignals,
    selected: Sequence[int],
    weights: Sequence[float],
    full_selection: ResearchSelection,
    budget: int,
    output_dir: Path,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"selected_{full_selection.method}_{budget}.json"
    rows = []
    for rank, idx in enumerate(selected, start=1):
        rows.append(
            {
                "rank": rank,
                "pool_index": int(idx),
                "source_index": int(pool.source_indices[idx]),
                "observed_label": int(pool.observed_labels[idx]),
                "clean_label": int(pool.clean_labels[idx]),
                "true_noise": bool(pool.noise_mask[idx]),
                "noise_type": str(pool.noise_type[idx]),
                "reliability": float(signals.reliability[idx]),
                "weight": float(weights[rank - 1]) if rank - 1 < len(weights) else 1.0,
            }
        )
    with path.open("w", encoding="utf-8") as f:
        json.dump(
            {
                "method": full_selection.method,
                "budget": budget,
                "samples": rows,
                "diagnostics": full_selection.diagnostics,
            },
            f,
            indent=2,
        )
    return path


def _save_pool_summary(pool: ResearchPool, signals: ProxySignals, scenario: str, seed: int, seed_dir: Path) -> None:
    save_json(
        {
            "scenario": scenario,
            "seed": seed,
            "num_samples": len(pool.observed_labels),
            "class_counts": pool.class_counts,
            "noise_rate": float(pool.noise_mask.mean()),
            "noise_type_counts": dict(Counter(str(value) for value in pool.noise_type)),
            "proxy_diagnostics": signals.diagnostics,
        },
        seed_dir / "pool_summary.json",
    )


def _aggregate_rows(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Mapping[str, Any]]] = {}
    for row in rows:
        key = (row.get("scenario"), row.get("method"), row.get("budget"))
        groups.setdefault(key, []).append(row)
    result = []
    for (scenario, method, budget), group in sorted(groups.items(), key=lambda item: str(item[0])):
        aggregated: Dict[str, Any] = {
            "scenario": scenario,
            "method": method,
            "budget": budget,
            "num_runs": len(group),
        }
        numeric_keys = sorted({key for row in group for key, value in row.items() if _is_number(value)})
        for key in numeric_keys:
            if key in {"seed", "budget"}:
                continue
            values = [float(row[key]) for row in group if _is_number(row.get(key))]
            if values:
                aggregated[f"{key}_mean"] = float(np.mean(values))
                aggregated[f"{key}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
        result.append(aggregated)
    return result


def _write_markdown_report(
    evaluation: Sequence[Mapping[str, Any]],
    selection: Sequence[Mapping[str, Any]],
    path: Path,
) -> None:
    lines = [
        "# Weekly DriveCore Research Report",
        "",
        "## Method progression",
        "",
        "- V0: conservative intra-class denoising followed by the previous selector.",
        "- V1: Fisher-geodesic maximum-radius covering with dynamic class budgets.",
        "- V2: reliability-mass mean/CVaR covering with dynamic class budgets.",
        "",
        "## Evaluation aggregate",
        "",
        _markdown_table(evaluation, ["scenario", "method", "budget", "test_accuracy_mean", "test_accuracy_std", "test_macro_f1_mean", "test_macro_f1_std"]),
        "",
        "## Selection aggregate",
        "",
        _markdown_table(
            selection,
            [
                "scenario",
                "method",
                "budget",
                "selected_noise_rate_mean",
                "clean_coverage_max_mean",
                "reliability_weighted_coverage_mean_mean",
                "reliability_weighted_coverage_cvar10_mean",
                "fisher_gradient_mean_residual_mean",
            ],
        ),
        "",
        "The report is generated from the current run. Interpret only configurations with completed convergence training.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _markdown_table(rows: Sequence[Mapping[str, Any]], fields: Sequence[str]) -> str:
    lines = ["|" + "|".join(fields) + "|", "|" + "|".join(["---"] * len(fields)) + "|"]
    for row in rows:
        lines.append("|" + "|".join(_format_value(row.get(field, "")) for field in fields) + "|")
    return "\n".join(lines)


def _load_datasets(data_root: Path, download: bool):
    transform = transforms.ToTensor()
    train = datasets.FashionMNIST(str(data_root), train=True, download=download, transform=transform)
    test = datasets.FashionMNIST(str(data_root), train=False, download=download, transform=transform)
    return train, test


def _budget_count(value: float, n: int) -> int:
    return int(np.floor(value * n)) if value <= 1.0 else int(value)


def _write_csv(rows: Sequence[Mapping[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    preferred = ["scenario", "seed", "run", "method", "budget", "num_selected"]
    fields = preferred + [field for field in fields if field not in preferred]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float, np.integer, np.floating)) and np.isfinite(float(value))


def _format_value(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def _device(requested: str) -> str:
    if requested == "cuda":
        return "cuda"
    if requested == "auto" and torch.cuda.is_available():
        return "cuda"
    return "cpu"


def _seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


if __name__ == "__main__":
    main()
