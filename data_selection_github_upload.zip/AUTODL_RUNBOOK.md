# AutoDL 运行手册：MOSAIC-on-nuScenes mini

本文档用于把本地项目打包上传到 AutoDL，解压后跑通 nuScenes mini 的训练、选择、绘图和结果分析。

## 1. 本地打包

在 Windows PowerShell 中执行：

```powershell
cd C:\Users\Lenovo\Desktop\data_selection

$zip = "$env:USERPROFILE\Desktop\data_selection_project.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }

Compress-Archive `
  -Path src,scripts,configs,"原始论文",*.md,requirements.txt,requirements-autodl.txt `
  -DestinationPath $zip `
  -Force

Get-FileHash $zip -Algorithm SHA256
```

压缩包会生成在：

```text
C:\Users\Lenovo\Desktop\data_selection_project.zip
```

建议不要把 `outputs/`、`.git/`、nuScenes 数据集一起压进项目包。代码包保持小，数据集在 AutoDL 数据盘单独下载或上传。

## 2. 上传到 AutoDL

如果使用 AutoDL 页面上的 JupyterLab，直接把 `data_selection_project.zip` 上传到：

```text
/root/autodl-tmp/
```

如果使用 SSH/SCP，在 Windows PowerShell 中执行：

```powershell
scp -P <AutoDL端口> C:\Users\Lenovo\Desktop\data_selection_project.zip root@<AutoDL主机>:/root/autodl-tmp/
```

`<AutoDL主机>` 和 `<AutoDL端口>` 在 AutoDL 实例页面复制。

## 3. 解压项目

进入 AutoDL 终端：

```bash
cd /root/autodl-tmp
mkdir -p data_selection
unzip -o data_selection_project.zip -d data_selection
cd data_selection
```

检查文件：

```bash
ls
ls scripts
ls configs
```

## 4. 准备 Python 环境

推荐选择 AutoDL 的 PyTorch + CUDA 镜像。先确认 GPU 和 torch：

```bash
nvidia-smi
python -c "import torch, torchvision; print(torch.__version__, torchvision.__version__, torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu')"
```

如果 torch 已经可用，不建议重新安装 torch/torchvision，避免破坏 CUDA 环境。安装项目其他依赖：

```bash
pip install -r requirements-autodl.txt
```

如需完整依赖，也可以使用：

```bash
pip install -r requirements.txt
```

但这可能触发 torch 重装。AutoDL 上更推荐 `requirements-autodl.txt`。

## 5. 准备 nuScenes mini 数据

建议放在 AutoDL 数据盘：

```text
/root/autodl-tmp/nuscenes
```

解压后目录通常应包含：

```text
/root/autodl-tmp/nuscenes/v1.0-mini
/root/autodl-tmp/nuscenes/samples
/root/autodl-tmp/nuscenes/sweeps
/root/autodl-tmp/nuscenes/maps
```

快速检查：

```bash
ls /root/autodl-tmp/nuscenes
ls /root/autodl-tmp/nuscenes/v1.0-mini
```

如果你从 nuScenes 官网下载，mini 通常需要 metadata、samples、sweeps、maps 这些包能被 `nuscenes-devkit` 正常读到。

## 6. 一键跑 mini 全流程

默认脚本按“较大最大 epoch + 早停”运行：`BASE_EPOCHS=100`、`PILOT_EPOCHS=40`、
`FULL_EPOCHS=80`。训练使用 AdamW；如果验证集 loss 连续 `20% * max_epochs`
个 epoch 没有明显改善，会自动早停。

如果要先清空旧结果再跑本轮实验，加入 `CLEAN_OUTPUTS=1`：

```bash
cd /root/autodl-tmp/data_selection

CLEAN_OUTPUTS=1 \
BASE_EPOCHS=50 \
PILOT_EPOCHS=10 \
FULL_EPOCHS=20 \
METHODS="random full mosaic" \
SELECTION_BUDGET_RATIOS="0.30 0.50" \
SEEDS="0" \
bash scripts/autodl_run_mini.sh /root/autodl-tmp/nuscenes v1.0-mini
```

如果只想快速检查代码链路，可以临时降低最大 epoch：

```bash
BASE_EPOCHS=10 \
PILOT_EPOCHS=3 \
FULL_EPOCHS=5 \
SEEDS="0" \
bash scripts/autodl_run_mini.sh /root/autodl-tmp/nuscenes v1.0-mini
```

这会依次执行：

```text
build clips -> split -> clip features -> kmeans++ clustering
-> camera feature cache -> trajectory vocab
-> base HydraMDP-nuScenes training
-> pool ranking
-> pilot fine-tuning
-> fit scaling laws
-> MOSAIC / baselines full experiments
-> plot and summarize results
```

输出重点看：

```text
outputs/eval/base_train/metrics.json
outputs/ranking/cluster_ranked_pool.csv
outputs/pilot/pilot_results.csv
outputs/scaling/scaling_params.json
outputs/results/main_results.csv
outputs/results/metric_breakdown.csv
outputs/results/cluster_distribution.csv
outputs/analysis/summary.md
outputs/analysis/utility_vs_budget.png
outputs/analysis/utility_heatmap.png
outputs/analysis/method_rank_heatmap.png
outputs/analysis/mosaic_gain_vs_random.png
outputs/analysis/pilot_scaling_observed.png
outputs/analysis/ranking_importance_by_cluster.png
outputs/analysis/training_val_loss_curves.png
outputs/analysis/training_best_val_loss.png
```

## 7. 手动分阶段运行

如果你希望每一阶段都单独改进，不用一键脚本。按 `README_REPRO.md` 的阶段 1-11 命令运行即可。

mini 数据集 pool 很小，不建议直接用大预算。可以先查看 pool 数量：

```bash
python -c "import pandas as pd; print(len(pd.read_csv('outputs/splits/pool.csv')))"
```

然后用百分比预算，例如 30% 和 50%：

```bash
python scripts/run_selection_experiments.py \
  --config configs/mosaic_nuscenes_mini.yaml \
  --budget-ratios 0.30 0.50 \
  --methods random full mosaic \
  --seeds 0 \
  --dataroot /root/autodl-tmp/nuscenes \
  --version v1.0-mini \
  --epochs 80 \
  --out-dir outputs/results
```

绘图和分析：

```bash
python scripts/plot_results.py \
  --results outputs/results/main_results.csv \
  --metric-breakdown outputs/results/metric_breakdown.csv \
  --cluster-distribution outputs/results/cluster_distribution.csv \
  --out-dir outputs/analysis
```

## 8. 把结果下载回本地

在 AutoDL 终端打包结果：

```bash
cd /root/autodl-tmp/data_selection
zip -r outputs_mini_results.zip outputs/results outputs/analysis outputs/scaling outputs/pilot outputs/ranking outputs/eval
```

在 Windows PowerShell 下载：

```powershell
scp -P <AutoDL端口> root@<AutoDL主机>:/root/autodl-tmp/data_selection/outputs_mini_results.zip C:\Users\Lenovo\Desktop\
```

## 9. 建议的第一轮设置

快速确认流程能跑通：

```text
GPU: RTX 4090 24GB 或同级
BASE_EPOCHS=10
PILOT_EPOCHS=3
FULL_EPOCHS=5
SEEDS=0
```

正式 mini 收敛测试：

```text
BASE_EPOCHS=100
PILOT_EPOCHS=40
FULL_EPOCHS=80
SEEDS="0 2025 424242"
```

mini 只适合验证代码链路，不适合证明论文级结论。正式比较需要切换到 `configs/mosaic_nuscenes_trainval.yaml` 和 full/trainval 数据。
