"""Research data protocols for long-tail and noisy Fashion-MNIST."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence

import numpy as np
import torch
from torch.utils.data import Dataset


@dataclass
class ResearchPool:
    """Train-pool arrays with clean and observed labels."""

    images: np.ndarray
    clean_labels: np.ndarray
    observed_labels: np.ndarray
    source_indices: np.ndarray
    noise_mask: np.ndarray
    noise_type: np.ndarray
    class_counts: Dict[int, int]


class ArrayFashionDataset(Dataset):
    """Tensor dataset backed by uint8 Fashion-MNIST arrays."""

    def __init__(self, images: np.ndarray, labels: np.ndarray) -> None:
        self.images = np.asarray(images, dtype=np.uint8)
        self.labels = np.asarray(labels, dtype=np.int64)

    def __len__(self) -> int:
        return int(len(self.labels))

    def __getitem__(self, index: int):
        image = torch.from_numpy(self.images[index].astype(np.float32) / 255.0).unsqueeze(0)
        label = torch.tensor(int(self.labels[index]), dtype=torch.long)
        return image, label


def build_research_pool(
    images: np.ndarray,
    labels: np.ndarray,
    source_indices: Sequence[int],
    *,
    scenario: str,
    imbalance_factor: float,
    noise_rate: float,
    seed: int,
) -> ResearchPool:
    """Create balanced, long-tail, or long-tail-plus-noise train pools."""

    source_indices_arr = np.asarray(source_indices, dtype=np.int64)
    pool_images = np.asarray(images[source_indices_arr], dtype=np.uint8)
    pool_labels = np.asarray(labels[source_indices_arr], dtype=np.int64)
    rng = np.random.default_rng(seed)

    if scenario not in {"balanced_clean", "long_tail_clean", "long_tail_mixed_noise"}:
        raise ValueError(f"Unsupported scenario: {scenario}")
    if scenario.startswith("long_tail"):
        keep = _long_tail_indices(pool_labels, imbalance_factor, rng)
        pool_images = pool_images[keep]
        pool_labels = pool_labels[keep]
        source_indices_arr = source_indices_arr[keep]

    clean_labels = pool_labels.copy()
    observed_labels = clean_labels.copy()
    noise_mask = np.zeros(len(clean_labels), dtype=bool)
    noise_type = np.full(len(clean_labels), "clean", dtype="<U20")
    if scenario == "long_tail_mixed_noise" and noise_rate > 0.0:
        _inject_mixed_noise(pool_images, clean_labels, observed_labels, noise_mask, noise_type, noise_rate, rng)

    counts = {cls: int(np.sum(observed_labels == cls)) for cls in range(10)}
    return ResearchPool(
        images=pool_images,
        clean_labels=clean_labels,
        observed_labels=observed_labels,
        source_indices=source_indices_arr,
        noise_mask=noise_mask,
        noise_type=noise_type,
        class_counts=counts,
    )


def stratified_train_val_indices(labels: np.ndarray, val_size: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    """Split the original training set into a clean train pool and validation set."""

    rng = np.random.default_rng(seed)
    labels = np.asarray(labels, dtype=np.int64)
    val_indices: List[int] = []
    pool_indices: List[int] = []
    for cls in range(10):
        cls_indices = np.flatnonzero(labels == cls)
        cls_indices = rng.permutation(cls_indices)
        n_val = int(round(val_size * len(cls_indices) / max(len(labels), 1)))
        n_val = min(max(n_val, 1), len(cls_indices) - 1)
        val_indices.extend(int(idx) for idx in cls_indices[:n_val])
        pool_indices.extend(int(idx) for idx in cls_indices[n_val:])
    rng.shuffle(val_indices)
    rng.shuffle(pool_indices)
    return np.asarray(pool_indices, dtype=np.int64), np.asarray(val_indices, dtype=np.int64)


def _long_tail_indices(labels: np.ndarray, imbalance_factor: float, rng: np.random.Generator) -> np.ndarray:
    counts = [int(np.sum(labels == cls)) for cls in range(10)]
    n_max = max(counts)
    keep: List[int] = []
    for cls in range(10):
        cls_indices = np.flatnonzero(labels == cls)
        target = int(round(n_max * float(imbalance_factor) ** (cls / 9.0)))
        target = min(max(target, 2), len(cls_indices))
        chosen = rng.choice(cls_indices, size=target, replace=False)
        keep.extend(int(idx) for idx in chosen)
    rng.shuffle(keep)
    return np.asarray(keep, dtype=np.int64)


def _inject_mixed_noise(
    images: np.ndarray,
    clean_labels: np.ndarray,
    observed_labels: np.ndarray,
    noise_mask: np.ndarray,
    noise_type: np.ndarray,
    noise_rate: float,
    rng: np.random.Generator,
) -> None:
    n_noise = min(int(round(noise_rate * len(clean_labels))), len(clean_labels))
    selected = rng.choice(len(clean_labels), size=n_noise, replace=False)
    n_label = n_noise // 2
    label_indices = selected[:n_label]
    corruption_indices = selected[n_label:]

    for idx in label_indices:
        choices = [cls for cls in range(10) if cls != int(clean_labels[idx])]
        observed_labels[idx] = int(rng.choice(choices))
        noise_mask[idx] = True
        noise_type[idx] = "label_flip"

    for pos, idx in enumerate(corruption_indices):
        image = images[idx].astype(np.float32)
        if pos % 2 == 0:
            noise = rng.normal(0.0, 70.0, size=image.shape)
            images[idx] = np.clip(image + noise, 0.0, 255.0).astype(np.uint8)
            noise_type[idx] = "gaussian"
        else:
            side = int(rng.integers(8, 15))
            y0 = int(rng.integers(0, 28 - side + 1))
            x0 = int(rng.integers(0, 28 - side + 1))
            image[y0 : y0 + side, x0 : x0 + side] = 0.0
            images[idx] = image.astype(np.uint8)
            noise_type[idx] = "occlusion"
        noise_mask[idx] = True


__all__ = [
    "ArrayFashionDataset",
    "ResearchPool",
    "build_research_pool",
    "stratified_train_val_indices",
]
