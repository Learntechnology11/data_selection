from __future__ import annotations

import math
from typing import Iterable

import numpy as np
import pandas as pd


METRIC_COLUMNS = [
    "ade",
    "fde",
    "heading_error",
    "collision_proxy",
    "offroad_proxy",
    "jerk",
    "uncertainty_entropy",
]


def angle_of_segment(points: np.ndarray) -> float:
    if len(points) >= 2:
        delta = points[-1] - points[-2]
    else:
        delta = points[-1]
    if float(np.linalg.norm(delta)) < 1e-6:
        return 0.0
    return float(math.atan2(float(delta[1]), float(delta[0])))


def angle_difference(a: float, b: float) -> float:
    return abs((a - b + math.pi) % (2.0 * math.pi) - math.pi)


def compute_jerk(points: np.ndarray) -> float:
    if len(points) < 4:
        return 0.0
    jerk = np.diff(points, n=3, axis=0)
    return float(np.linalg.norm(jerk, axis=1).mean())


def compute_collision_proxy(
    pred: np.ndarray,
    future_agent_centers: Iterable[np.ndarray] | None,
    threshold_m: float = 2.0,
) -> float:
    if future_agent_centers is None:
        return float("nan")
    risks: list[float] = []
    for pred_xy, centers in zip(pred, future_agent_centers):
        if centers is None or len(centers) == 0:
            risks.append(0.0)
            continue
        distances = np.linalg.norm(np.asarray(centers) - pred_xy[None, :], axis=1)
        risks.append(float(distances.min() < threshold_m))
    if not risks:
        return float("nan")
    return float(np.mean(risks))


def compute_sample_metrics(
    pred: np.ndarray,
    target: np.ndarray,
    future_agent_centers: Iterable[np.ndarray] | None = None,
    collision_threshold_m: float = 2.0,
) -> dict[str, float]:
    pred = np.asarray(pred, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    if pred.shape != target.shape:
        raise ValueError(f"pred shape {pred.shape} does not match target shape {target.shape}")
    if pred.ndim != 2 or pred.shape[1] != 2:
        raise ValueError(f"Expected trajectory shape (T, 2), got {pred.shape}")

    distances = np.linalg.norm(pred - target, axis=1)
    pred_heading = angle_of_segment(pred)
    target_heading = angle_of_segment(target)
    return {
        "ade": float(distances.mean()),
        "fde": float(distances[-1]),
        "heading_error": float(angle_difference(pred_heading, target_heading)),
        "collision_proxy": compute_collision_proxy(
            pred, future_agent_centers, threshold_m=collision_threshold_m
        ),
        "offroad_proxy": float("nan"),
        "jerk": compute_jerk(pred),
    }


def aggregate_window_metrics(window_metrics: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, float]]:
    if window_metrics.empty:
        raise ValueError("window_metrics is empty")
    aggregations = {column: "mean" for column in METRIC_COLUMNS if column in window_metrics.columns}
    aggregations["anchor_sample_token"] = "count"
    per_clip = (
        window_metrics.groupby("clip_id", as_index=False)
        .agg(aggregations)
        .rename(columns={"anchor_sample_token": "num_windows"})
    )
    aggregate: dict[str, float] = {
        column: float(per_clip[column].mean(skipna=True))
        for column in METRIC_COLUMNS
        if column in per_clip.columns
    }
    aggregate["num_clips"] = float(len(per_clip))
    aggregate["num_windows"] = float(len(window_metrics))
    return per_clip, aggregate
