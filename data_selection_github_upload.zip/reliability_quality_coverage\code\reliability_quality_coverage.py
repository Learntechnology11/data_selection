"""Standalone Reliability-Quality Coverage selector.

This module is intentionally independent of Fashion-MNIST specific data
loading.  It can be reused with image features, multimodal driving clip
features, or any dataset where each item has:

* a cluster / class / stratum label,
* a representation-gradient geometry,
* a soft reliability estimate,
* an optional hard reject mask.
"""

from __future__ import annotations

import heapq
import math
from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence

import numpy as np
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors


@dataclass
class RQCSelection:
    """Ranked coreset selection and diagnostics."""

    method: str
    ranking: List[int]
    weights: List[float]
    diagnostics: Dict[str, Any]
    trajectory: List[Dict[str, Any]]

    def truncate(self, count: int) -> "RQCSelection":
        """Return a nested prefix with mean-one bounded weights."""

        count = min(int(count), len(self.ranking))
        prefix_weights = self.weights[:count]
        if prefix_weights:
            arr = np.asarray(prefix_weights, dtype=np.float64)
            prefix_weights = (arr / max(float(arr.mean()), 1e-12)).tolist()
        return RQCSelection(
            method=self.method,
            ranking=self.ranking[:count],
            weights=prefix_weights,
            diagnostics={**self.diagnostics, "truncated_to": count},
            trajectory=self.trajectory[:count],
        )


def estimate_reliability(
    embeddings: np.ndarray,
    probabilities: np.ndarray,
    labels: np.ndarray,
    *,
    true_noise_mask: Optional[np.ndarray] = None,
    neighbors: int = 15,
    conflict_weight: float = 1.8,
    distance_weight: float = 0.8,
    neighborhood_weight: float = 1.0,
    uncertainty_weight: float = 0.4,
    high_confidence: float = 0.80,
    distance_gate: float = 2.0,
    neighbor_gate: float = 0.45,
    hard_distance_gate: float = 4.5,
    reliability_gate: float = 0.12,
) -> Dict[str, Any]:
    """Estimate soft reliability and conservative hard rejection.

    This is a generic version of the Fashion-MNIST proxy reliability module.
    Labels are assumed to index the probability columns.
    """

    labels = np.asarray(labels, dtype=np.int64)
    probabilities = np.asarray(probabilities, dtype=np.float64)
    if len(labels) != len(probabilities):
        raise ValueError("labels and probabilities must have the same length")
    if probabilities.ndim != 2:
        raise ValueError("probabilities must be a [num_samples, num_classes] array")
    if np.any(labels < 0) or np.any(labels >= probabilities.shape[1]):
        raise ValueError("labels must index probability columns")

    normalized = _standardize(np.asarray(embeddings, dtype=np.float64))
    distance_z = np.zeros(len(labels), dtype=np.float64)
    for cls in np.unique(labels):
        idx = np.flatnonzero(labels == cls)
        if not len(idx):
            continue
        points = normalized[idx]
        center = np.median(points, axis=0)
        scale = np.median(np.abs(points - center[None, :]), axis=0) * 1.4826
        scale = np.maximum(scale, 0.1)
        distances = np.sqrt(np.mean(((points - center[None, :]) / scale[None, :]) ** 2, axis=1))
        median = float(np.median(distances))
        mad = float(np.median(np.abs(distances - median)) * 1.4826)
        distance_z[idx] = (distances - median) / max(mad, 1e-6)

    neighbor_agreement = np.ones(len(labels), dtype=np.float64)
    if len(labels) > 1:
        k = min(max(3, int(neighbors)), len(labels) - 1)
        nn = NearestNeighbors(n_neighbors=min(k + 1, len(labels)), metric="euclidean")
        nn.fit(normalized)
        neighbor_idx = nn.kneighbors(return_distance=False)
        for idx in range(len(labels)):
            neighbors_i = neighbor_idx[idx]
            neighbors_i = neighbors_i[neighbors_i != idx][:k]
            if len(neighbors_i):
                neighbor_agreement[idx] = float(np.mean(labels[neighbors_i] == labels[idx]))

    p_label = probabilities[np.arange(len(labels)), labels]
    probs_without_label = probabilities.copy()
    probs_without_label[np.arange(len(labels)), labels] = -1.0
    max_other = probs_without_label.max(axis=1)
    predicted = probabilities.argmax(axis=1)

    conflict = np.maximum(max_other - p_label, 0.0)
    distance_risk = 1.0 / (1.0 + np.exp(-(distance_z - 1.5)))
    neighborhood_risk = 1.0 - neighbor_agreement
    uncertainty = 1.0 - probabilities.max(axis=1)
    risk = (
        float(conflict_weight) * conflict
        + float(distance_weight) * distance_risk
        + float(neighborhood_weight) * neighborhood_risk
        + float(uncertainty_weight) * uncertainty
    )
    reliability = np.clip(np.exp(-risk), 0.01, 1.0)

    high_conflict = (predicted != labels) & (probabilities.max(axis=1) >= float(high_confidence))
    corroborated = (distance_z >= float(distance_gate)) | (neighbor_agreement <= float(neighbor_gate))
    reject = (
        (high_conflict & corroborated)
        | (distance_z >= float(hard_distance_gate))
        | (reliability <= float(reliability_gate))
    )

    diagnostics: Dict[str, Any] = {
        "num_rejected": int(reject.sum()),
        "reject_rate": float(reject.mean()) if len(reject) else 0.0,
        "mean_reliability": float(reliability.mean()) if len(reliability) else 0.0,
    }
    if true_noise_mask is not None:
        true_noise = np.asarray(true_noise_mask, dtype=bool)
        tp = int(np.sum(reject & true_noise))
        fp = int(np.sum(reject & ~true_noise))
        fn = int(np.sum(~reject & true_noise))
        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        diagnostics.update(
            {
                "noise_detection_precision": float(precision),
                "noise_detection_recall": float(recall),
                "noise_detection_f1": float(2.0 * precision * recall / max(precision + recall, 1e-12)),
                "true_noise_rate": float(true_noise.mean()),
            }
        )

    return {
        "reliability": reliability,
        "reject_mask": reject,
        "class_distance_z": distance_z,
        "neighbor_agreement": neighbor_agreement,
        "diagnostics": diagnostics,
    }


def projected_gradient_embedding(
    embeddings: np.ndarray,
    probabilities: np.ndarray,
    labels: np.ndarray,
    *,
    out_dim: int,
    seed: int,
) -> np.ndarray:
    """Project classification-head gradients to a compact embedding."""

    labels = np.asarray(labels, dtype=np.int64)
    probabilities = np.asarray(probabilities, dtype=np.float64)
    embeddings = np.asarray(embeddings, dtype=np.float64)
    num_classes = probabilities.shape[1]
    onehot = np.eye(num_classes, dtype=np.float64)[labels]
    residual = probabilities - onehot
    raw = np.einsum("nc,nd->ncd", residual, embeddings).reshape(len(labels), -1)
    rng = np.random.default_rng(int(seed) + 104729)
    projection = rng.normal(0.0, 1.0 / np.sqrt(max(out_dim, 1)), size=(raw.shape[1], int(out_dim)))
    return raw @ projection


def fisher_normalize(gradient: np.ndarray, *, rank: int = 64, reg: float = 1e-3) -> np.ndarray:
    """Normalize projected gradients in the top empirical-Fisher subspace."""

    gradient = np.asarray(gradient, dtype=np.float64)
    centered = gradient - gradient.mean(axis=0, keepdims=True)
    if len(centered) <= 1:
        return centered
    cov = centered.T @ centered / max(len(centered), 1)
    values, vectors = np.linalg.eigh(cov)
    order = np.argsort(values)[::-1][: max(1, min(int(rank), len(values)))]
    values_q = np.maximum(values[order], 0.0)
    vectors_q = vectors[:, order]
    return centered @ vectors_q / np.sqrt(values_q[None, :] + float(reg))


def build_joint_geometry(
    representation: np.ndarray,
    fisher_gradient: Optional[np.ndarray] = None,
    *,
    representation_dim: int = 24,
    gradient_dim: int = 24,
    lambda_z: float = 1.0,
    lambda_g: float = 1.0,
) -> np.ndarray:
    """Build normalized representation-gradient geometry for RQC."""

    parts: List[np.ndarray] = []
    if lambda_z > 0:
        parts.append(math.sqrt(float(lambda_z)) * _pca_standardize(representation, representation_dim))
    if lambda_g > 0:
        if fisher_gradient is None:
            raise ValueError("fisher_gradient is required when lambda_g > 0")
        parts.append(math.sqrt(float(lambda_g)) * _pca_standardize(fisher_gradient, gradient_dim))
    if not parts:
        raise ValueError("At least one of lambda_z or lambda_g must be positive")
    geometry = np.concatenate(parts, axis=1)
    return geometry / np.maximum(np.linalg.norm(geometry, axis=1, keepdims=True), 1e-12)


def build_equal_energy_joint_geometry(
    representation: np.ndarray,
    fisher_gradient: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Build the rank-RQC default geometry without explicit block weights.

    Each block keeps the PCA components needed to explain 90% variance, capped
    at 32 components, then divides the block by sqrt(retained_dim). This avoids
    exposing lambda_z/lambda_g as research knobs while keeping representation
    and gradient coverage on comparable energy scales.
    """

    parts: List[np.ndarray] = []
    z = _pca_equal_energy(representation)
    if z.shape[1]:
        parts.append(z)
    if fisher_gradient is not None:
        g = _pca_equal_energy(fisher_gradient)
        if g.shape[1]:
            parts.append(g)
    if not parts:
        raise ValueError("At least one geometry block must be non-empty")
    geometry = np.concatenate(parts, axis=1)
    return geometry / np.maximum(np.linalg.norm(geometry, axis=1, keepdims=True), 1e-12)


def select_reliability_quality_coverage(
    geometry: np.ndarray,
    cluster_labels: np.ndarray,
    max_budget: int,
    *,
    reliability: Optional[np.ndarray] = None,
    reject_mask: Optional[np.ndarray] = None,
    eta: float = 0.50,
    tail_fraction: float = 0.10,
    cluster_alpha: float = 1.0,
    use_reliability: bool = True,
    clean_mass_floor: float = 0.0,
    method_name: str = "rqc",
) -> RQCSelection:
    """Select a nested ranking with reliability-quality coverage.

    The objective within each cluster is a reliability-mass weighted mixture of
    mean nearest-center distance and worst-tail nearest-center distance.
    """

    geometry = np.asarray(geometry, dtype=np.float64)
    labels = np.asarray(cluster_labels)
    n = len(labels)
    if len(geometry) != n:
        raise ValueError("geometry and cluster_labels must have the same length")
    budget = min(max(int(max_budget), 0), n)
    if budget == 0:
        return RQCSelection(method_name, [], [], {"budget": 0}, [])

    if reliability is None:
        reliability_arr = np.ones(n, dtype=np.float64)
    else:
        reliability_arr = np.asarray(reliability, dtype=np.float64)
    if len(reliability_arr) != n:
        raise ValueError("reliability and cluster_labels must have the same length")

    if reject_mask is None:
        reject_arr = np.zeros(n, dtype=bool)
    else:
        reject_arr = np.asarray(reject_mask, dtype=bool)
    if len(reject_arr) != n:
        raise ValueError("reject_mask and cluster_labels must have the same length")

    if use_reliability:
        quality_mass = np.maximum(reliability_arr, 1e-6)
        quality_mass = quality_mass + float(clean_mass_floor) * (~reject_arr).astype(np.float64)
    else:
        quality_mass = np.ones(n, dtype=np.float64)
    total_mass = max(float(quality_mass.sum()), 1e-12)

    local_orders: Dict[Any, List[int]] = {}
    local_gains: Dict[Any, List[float]] = {}
    local_objectives: Dict[str, List[float]] = {}

    for cluster in np.unique(labels):
        demand = np.flatnonzero(labels == cluster)
        if not len(demand):
            continue
        candidates = demand[~reject_arr[demand]]
        if not len(candidates):
            fallback = np.argsort(quality_mass[demand])[::-1][:1]
            candidates = demand[fallback]
        order, gains, objectives = _mass_cvar_order(
            geometry[demand],
            geometry[candidates],
            candidates,
            quality_mass[demand],
            quality_mass[candidates],
            max_steps=min(len(candidates), budget),
            eta=eta,
            tail_fraction=tail_fraction,
        )
        cluster_mass = float(quality_mass[demand].sum() / total_mass)
        cluster_weight = cluster_mass ** float(cluster_alpha)
        local_orders[_scalar(cluster)] = order
        local_gains[_scalar(cluster)] = [float(cluster_weight * gain) for gain in gains]
        local_objectives[str(_scalar(cluster))] = objectives

    ranking, trajectory = _merge_dynamic_orders(local_orders, local_gains, labels, budget, method=method_name)
    weights = compute_representative_weights(geometry, labels, ranking, demand_weight=quality_mass)
    counts = Counter(_scalar(labels[idx]) for idx in ranking)
    diagnostics = {
        "method": method_name,
        "budget": int(budget),
        "num_selected": int(len(ranking)),
        "eta": float(eta),
        "tail_fraction": float(tail_fraction),
        "cluster_alpha": float(cluster_alpha),
        "clean_mass_floor": float(clean_mass_floor),
        "num_rejected_candidates": int(reject_arr.sum()),
        "selected_rejected_count": int(np.sum(reject_arr[np.asarray(ranking, dtype=np.int64)])) if ranking else 0,
        "cluster_counts": {str(key): int(value) for key, value in counts.items()},
        "final_cluster_objectives": {
            str(cluster): float(values[min(len(values) - 1, max(counts.get(cluster, 0) - 1, 0))])
            if values
            else 0.0
            for cluster, values in local_objectives.items()
        },
        "objective": "(1-eta) reliability-quality mean distance + eta reliability-quality CVaR tail distance",
    }
    return RQCSelection(method_name, ranking, weights, diagnostics, trajectory)


def compute_representative_weights(
    geometry: np.ndarray,
    cluster_labels: np.ndarray,
    ranking: Sequence[int],
    *,
    demand_weight: Optional[np.ndarray] = None,
    lower: float = 0.25,
    upper: float = 4.0,
) -> List[float]:
    """Assign bounded representative-mass training weights to selected samples."""

    selected = list(ranking)
    if not selected:
        return []
    labels = np.asarray(cluster_labels)
    geometry = np.asarray(geometry, dtype=np.float64)
    if demand_weight is None:
        demand_weight_arr = np.ones(len(labels), dtype=np.float64)
    else:
        demand_weight_arr = np.asarray(demand_weight, dtype=np.float64)
    result = np.zeros(len(selected), dtype=np.float64)
    position = {sample: pos for pos, sample in enumerate(selected)}

    for cluster in np.unique(labels):
        demand = np.flatnonzero(labels == cluster)
        selected_cluster = [idx for idx in selected if labels[idx] == cluster]
        if not len(demand) or not selected_cluster:
            continue
        d2 = _pairwise_squared(geometry[demand], geometry[selected_cluster])
        nearest = np.argmin(d2, axis=1)
        for row, nearest_pos in enumerate(nearest):
            result[position[selected_cluster[int(nearest_pos)]]] += float(demand_weight_arr[demand[row]])

    if result.mean() <= 1e-12:
        return [1.0] * len(selected)
    return _bounded_mean_one(result, lower=float(lower), upper=float(upper)).tolist()


def nearest_coverage_distances(geometry: np.ndarray, ranking: Sequence[int]) -> np.ndarray:
    """Return squared distance from every item to its nearest selected item."""

    selected = list(ranking)
    if not selected:
        return np.full(len(geometry), np.inf, dtype=np.float64)
    d2 = _pairwise_squared(np.asarray(geometry, dtype=np.float64), np.asarray(geometry, dtype=np.float64)[selected])
    return d2.min(axis=1)


def _mass_cvar_order(
    demand_points: np.ndarray,
    candidate_points: np.ndarray,
    candidate_global: np.ndarray,
    reliability: np.ndarray,
    candidate_reliability: np.ndarray,
    *,
    max_steps: int,
    eta: float,
    tail_fraction: float,
) -> tuple[List[int], List[float], List[float]]:
    if len(candidate_global) == 0 or int(max_steps) <= 0:
        return [], [], []
    d2 = _pairwise_squared(demand_points, candidate_points)
    mass = np.maximum(np.asarray(reliability, dtype=np.float64), 1e-6)
    mass = mass / mass.sum()
    candidate_quality = np.maximum(np.asarray(candidate_reliability, dtype=np.float64), 1e-6)
    mean_after_one = mass @ d2
    shortlist = np.argsort(mean_after_one)[: min(32, len(candidate_global))]
    seed_scores = []
    for col in shortlist:
        base_objective = _mass_cvar_objective(d2[:, col], mass, eta, tail_fraction)
        seed_scores.append(base_objective / max(float(candidate_quality[col]), 0.10))
    seed_col = int(shortlist[int(np.argmin(seed_scores))])

    selected_cols = {seed_col}
    order = [int(candidate_global[seed_col])]
    current = d2[:, seed_col].copy()
    current_objective = _mass_cvar_objective(current, mass, eta, tail_fraction)
    gains = [current_objective]
    objectives = [current_objective]

    gain_vector = _mass_cvar_gain_vector(current, d2, mass, eta, tail_fraction)
    gain_vector = gain_vector * np.sqrt(np.maximum(candidate_quality, 0.01))
    heap = [(-float(gain_vector[col]), col) for col in range(len(candidate_global)) if col not in selected_cols]
    heapq.heapify(heap)

    while len(order) < min(int(max_steps), len(candidate_global)) and heap:
        while heap:
            _, col = heapq.heappop(heap)
            if col in selected_cols:
                continue
            exact_gain = _mass_cvar_gain_scalar(current, d2[:, col], mass, eta, tail_fraction)
            exact_gain *= math.sqrt(max(float(candidate_quality[col]), 0.01))
            next_bound = -heap[0][0] if heap else -float("inf")
            if exact_gain + 1e-12 >= next_bound:
                break
            heapq.heappush(heap, (-float(exact_gain), col))
        else:
            break
        selected_cols.add(col)
        new_current = np.minimum(current, d2[:, col])
        new_objective = _mass_cvar_objective(new_current, mass, eta, tail_fraction)
        gains.append(max(current_objective - new_objective, 0.0))
        objectives.append(new_objective)
        current = new_current
        current_objective = new_objective
        order.append(int(candidate_global[col]))
    return order, gains, objectives


def _merge_dynamic_orders(
    local_orders: Mapping[Any, Sequence[int]],
    local_gains: Mapping[Any, Sequence[float]],
    labels: np.ndarray,
    budget: int,
    *,
    method: str,
) -> tuple[List[int], List[Dict[str, Any]]]:
    positions = {cluster: 0 for cluster in local_orders}
    ranking: List[int] = []
    trajectory: List[Dict[str, Any]] = []

    seed_clusters = [cluster for cluster, order in local_orders.items() if order]
    seed_clusters.sort(key=lambda cluster: local_gains[cluster][0] if local_gains.get(cluster) else 0.0, reverse=True)
    for cluster in seed_clusters:
        if len(ranking) >= budget:
            break
        sample = int(local_orders[cluster][0])
        positions[cluster] = 1
        ranking.append(sample)
        trajectory.append(
            {
                "step": len(ranking),
                "method": method,
                "cluster": str(_scalar(labels[sample])),
                "sample_index": sample,
                "marginal_gain": float(local_gains[cluster][0] if local_gains.get(cluster) else 0.0),
                "cluster_selected_count": 1,
            }
        )

    cluster_counts = Counter(_scalar(labels[idx]) for idx in ranking)
    while len(ranking) < budget:
        best_cluster = None
        best_gain = -float("inf")
        for cluster, order in local_orders.items():
            pos = positions[cluster]
            if pos >= len(order):
                continue
            gain = float(local_gains[cluster][pos]) if pos < len(local_gains[cluster]) else 0.0
            if gain > best_gain:
                best_gain = gain
                best_cluster = cluster
        if best_cluster is None:
            break
        pos = positions[best_cluster]
        sample = int(local_orders[best_cluster][pos])
        positions[best_cluster] += 1
        ranking.append(sample)
        cluster_value = _scalar(labels[sample])
        cluster_counts[cluster_value] += 1
        trajectory.append(
            {
                "step": len(ranking),
                "method": method,
                "cluster": str(cluster_value),
                "sample_index": sample,
                "marginal_gain": float(best_gain),
                "cluster_selected_count": int(cluster_counts[cluster_value]),
            }
        )
    return ranking, trajectory


def _mass_cvar_gain_vector(
    current: np.ndarray,
    candidate_d2: np.ndarray,
    mass: np.ndarray,
    eta: float,
    tail_fraction: float,
) -> np.ndarray:
    improvement = np.maximum(current[:, None] - candidate_d2, 0.0)
    mean_gain = mass @ improvement
    tail_weight = _tail_weights(current, mass, tail_fraction)
    tail_gain = tail_weight @ improvement
    return (1.0 - float(eta)) * mean_gain + float(eta) * tail_gain


def _mass_cvar_gain_scalar(
    current: np.ndarray,
    candidate_d2: np.ndarray,
    mass: np.ndarray,
    eta: float,
    tail_fraction: float,
) -> float:
    improvement = np.maximum(current - candidate_d2, 0.0)
    mean_gain = float(np.dot(mass, improvement))
    tail_gain = float(np.dot(_tail_weights(current, mass, tail_fraction), improvement))
    return (1.0 - float(eta)) * mean_gain + float(eta) * tail_gain


def _mass_cvar_objective(values: np.ndarray, mass: np.ndarray, eta: float, tail_fraction: float) -> float:
    mean = float(np.dot(mass, values))
    tail = float(np.dot(_tail_weights(values, mass, tail_fraction), values))
    return (1.0 - float(eta)) * mean + float(eta) * tail


def _tail_weights(values: np.ndarray, mass: np.ndarray, tail_fraction: float) -> np.ndarray:
    order = np.argsort(values)[::-1]
    target = min(max(float(tail_fraction), 1e-3), 1.0)
    weights = np.zeros_like(mass, dtype=np.float64)
    accumulated = 0.0
    for idx in order:
        remaining = target - accumulated
        if remaining <= 1e-12:
            break
        take = min(float(mass[idx]), remaining)
        weights[idx] = take
        accumulated += take
    return weights / max(accumulated, 1e-12)


def _pairwise_squared(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    a2 = np.sum(a * a, axis=1, keepdims=True)
    b2 = np.sum(b * b, axis=1, keepdims=True).T
    return np.maximum(a2 + b2 - 2.0 * (a @ b.T), 0.0)


def _pca_standardize(values: np.ndarray, dim: int) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    standardized = _standardize(values)
    if standardized.shape[0] <= 1:
        return np.zeros((standardized.shape[0], max(1, min(int(dim), standardized.shape[1]))), dtype=np.float64)
    n_components = max(1, min(int(dim), standardized.shape[1], standardized.shape[0] - 1))
    return PCA(n_components=n_components, random_state=0).fit_transform(standardized)


def _pca_equal_energy(values: np.ndarray, variance_target: float = 0.90, max_components: int = 32) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    if values.ndim == 1:
        values = values.reshape(-1, 1)
    if values.shape[0] == 0 or values.shape[1] == 0:
        return np.zeros((values.shape[0], 0), dtype=np.float64)
    standardized = _standardize(values)
    if standardized.shape[0] <= 1:
        keep = max(1, min(int(max_components), standardized.shape[1]))
        return np.zeros((standardized.shape[0], keep), dtype=np.float64)
    n_components = max(1, min(int(max_components), standardized.shape[1], standardized.shape[0] - 1))
    pca = PCA(n_components=n_components, random_state=0)
    scores = pca.fit_transform(standardized)
    ratios = np.nan_to_num(pca.explained_variance_ratio_, nan=0.0, posinf=0.0, neginf=0.0)
    if ratios.size and float(ratios.sum()) > 0.0:
        keep = int(np.searchsorted(np.cumsum(ratios), float(variance_target), side="left") + 1)
        keep = max(1, min(keep, n_components))
    else:
        keep = n_components
    scores = _standardize(scores[:, :keep])
    return scores / math.sqrt(float(max(keep, 1)))


def _standardize(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    return (values - values.mean(axis=0, keepdims=True)) / np.maximum(values.std(axis=0, keepdims=True), 1e-6)


def _bounded_mean_one(values: np.ndarray, lower: float, upper: float) -> np.ndarray:
    values = np.maximum(np.asarray(values, dtype=np.float64), 1e-12)
    lo = 0.0
    hi = 1.0 / max(float(values.min()), 1e-12)
    for _ in range(80):
        scale = (lo + hi) / 2.0
        mean = float(np.clip(values * scale, lower, upper).mean())
        if mean < 1.0:
            lo = scale
        else:
            hi = scale
    return np.clip(values * ((lo + hi) / 2.0), lower, upper)


def _scalar(value: Any) -> Any:
    if hasattr(value, "item"):
        return value.item()
    return value


__all__ = [
    "RQCSelection",
    "build_equal_energy_joint_geometry",
    "build_joint_geometry",
    "compute_representative_weights",
    "estimate_reliability",
    "fisher_normalize",
    "nearest_coverage_distances",
    "projected_gradient_embedding",
    "select_reliability_quality_coverage",
]
