# Reliability-Quality Coverage Code Package

This package contains the second improvement of the weekly coreset study:
Reliability-Quality Coverage (RQC).

## What To Use First

- `code/reliability_quality_coverage.py`
  - Standalone migration-friendly implementation.
  - Use this file when moving the algorithm to nuScenes or another multimodal
    driving dataset.

- `code/nuscenes_rqc.py`
  - nuScenes / autonomous-driving adapter.
  - Reads clip manifests, clip features, scenario clusters, planner metrics,
    and optional cached camera features.
  - Uses cluster-wise percentile-rank reliability, rank-normalized planner
    difficulty, bad-data-only hard rejection, and equal-energy PCA geometry.
  - Writes RQC ranking, selected clip CSVs, diagnostics, and optional combined
    train manifests.

- `docs/NUSCENES_RQC_ADAPTATION.md`
  - Chinese algorithm formulas, autonomous-driving signal definitions, and
    nuScenes command guide.

- `docs/RELIABILITY_QUALITY_COVERAGE.md`
  - Full Chinese algorithm description, equations, pseudocode, and migration
    notes.

- `code/research_selectors.py`
  - Experiment-integrated implementation used by the current Fashion-MNIST
    weekly runner. The corresponding method is `select_v2_reliability_mass`.

- `code/proxy_signals.py`
  - Fashion-MNIST proxy-signal implementation: cross-fitted probabilities,
    embeddings, projected gradients, Fisher normalization, reliability
    estimation.

- `code/run_weekly_research.py`
  - End-to-end Fashion-MNIST experiment runner.

## Minimal API

```python
from reliability_quality_coverage import (
    build_equal_energy_joint_geometry,
    select_reliability_quality_coverage,
)

geometry = build_equal_energy_joint_geometry(representation, fisher_gradient)
selection = select_reliability_quality_coverage(
    geometry,
    cluster_labels,
    max_budget,
    reliability=reliability,
    reject_mask=reject_mask,
)

ranking = selection.ranking
weights = selection.weights
```

## nuScenes Migration Checklist

1. Build 10s clip-level samples.
2. Extract multimodal representation for each clip.
3. Extract planner metrics such as ADE, FDE, collision, offroad, and jerk.
4. Estimate reliability with cluster-wise percentile ranks, not hand-written
   linear risk weights.
5. Build cluster labels from scenario strata or strata plus clustering.
6. Hard-reject only invalid metrics, severe sensor missingness, or broken
   timestamp/log metadata.
7. Run `code/nuscenes_rqc.py` with budget ratios such as `0.30 0.50`.

## Package Contents

```text
code/
  nuscenes_rqc.py
  reliability_quality_coverage.py
  algorithms.py
  plots.py
  proxy_signals.py
  research_selectors.py
  data_protocols.py
  models.py
  weekly_plots.py
  run_weekly_research.py
  run_weekly_research.ps1
  __init__.py
docs/
  RELIABILITY_QUALITY_COVERAGE.md
  WEEKLY_BRIEF_ZH.md
  WEEKLY_RESEARCH.md
tests/
  test_research_selectors.py
examples/
  minimal_rqc_numpy.py
```
