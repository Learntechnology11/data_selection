from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.selection.scaling import fit_scaling_laws, save_scaling_outputs
from src.utils.io import read_csv
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fit MOSAIC saturating exponential scaling laws.")
    parser.add_argument("--pilot-results", required=True)
    parser.add_argument("--out-dir", default="outputs/scaling")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    pilot_results = read_csv(args.pilot_results)
    params = fit_scaling_laws(pilot_results)
    save_scaling_outputs(params, args.out_dir, pilot_results)
    logger.info("Wrote scaling params for %d clusters under %s", len(params), args.out_dir)


if __name__ == "__main__":
    main()
