from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from tqdm import tqdm

from src.data.nuscenes_clips import load_nuscenes
from src.utils.io import ensure_parent, parse_json_list, read_csv, write_json


DEFAULT_CAMERAS = [
    "CAM_FRONT",
    "CAM_FRONT_LEFT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_BACK_RIGHT",
]


@dataclass(frozen=True)
class CameraFeatureConfig:
    dataroot: str
    version: str
    cameras: tuple[str, ...] = tuple(DEFAULT_CAMERAS)
    backbone: str = "resnet18"
    image_size: int = 224
    batch_size: int = 32
    device: str = "auto"
    pretrained: bool = False
    aggregate: str = "concat"
    verbose: bool = True


def unique_sample_tokens_from_clips(clips: pd.DataFrame) -> list[str]:
    tokens: list[str] = []
    seen: set[str] = set()
    for _, row in clips.iterrows():
        for token in parse_json_list(row["sample_tokens"]):
            if token not in seen:
                seen.add(token)
                tokens.append(token)
    return tokens


def build_image_encoder(backbone: str, pretrained: bool) -> tuple[Any, int]:
    import torch
    from torch import nn
    from torchvision import models

    normalized = backbone.lower()
    if normalized == "resnet18":
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
    elif normalized == "resnet34":
        weights = models.ResNet34_Weights.DEFAULT if pretrained else None
        model = models.resnet34(weights=weights)
    elif normalized == "resnet50":
        weights = models.ResNet50_Weights.DEFAULT if pretrained else None
        model = models.resnet50(weights=weights)
    else:
        raise ValueError(f"Unsupported camera backbone: {backbone}")
    feature_dim = int(model.fc.in_features)
    model.fc = nn.Identity()
    return model, feature_dim


def image_transform(image_size: int) -> Any:
    from torchvision import transforms

    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    )


def camera_image_paths(nusc: Any, dataroot: str | Path, sample_token: str, cameras: tuple[str, ...]) -> list[Path | None]:
    sample = nusc.get("sample", sample_token)
    paths: list[Path | None] = []
    for camera in cameras:
        sample_data_token = sample.get("data", {}).get(camera)
        if not sample_data_token:
            paths.append(None)
            continue
        sample_data = nusc.get("sample_data", sample_data_token)
        paths.append(Path(dataroot) / sample_data["filename"])
    return paths


def load_camera_tensor(path: Path | None, transform: Any, image_size: int) -> Any:
    import torch
    from PIL import Image

    if path is None or not path.exists():
        return torch.zeros(3, image_size, image_size, dtype=torch.float32)
    with Image.open(path) as img:
        return transform(img.convert("RGB"))


def select_torch_device(device: str) -> Any:
    import torch

    requested = (device or "auto").lower()
    if requested == "auto":
        try:
            import torch_npu  # noqa: F401
        except ImportError:
            pass
        if hasattr(torch, "npu") and torch.npu.is_available():
            return torch.device("npu:0")
        if torch.cuda.is_available():
            return torch.device("cuda:0")
        return torch.device("cpu")
    return torch.device(device)


def cache_camera_features(
    clips_path: str | Path,
    out_path: str | Path,
    config: CameraFeatureConfig,
) -> dict[str, Any]:
    import torch

    clips = read_csv(clips_path)
    if "sample_tokens" not in clips.columns:
        raise ValueError("clips manifest must contain sample_tokens")
    sample_tokens = unique_sample_tokens_from_clips(clips)
    if not sample_tokens:
        raise ValueError("No sample tokens found in clips manifest")

    nusc = load_nuscenes(config.dataroot, config.version, verbose=config.verbose)
    model, per_camera_dim = build_image_encoder(config.backbone, config.pretrained)
    device = select_torch_device(config.device)
    model = model.to(device).eval()
    transform = image_transform(config.image_size)
    output_dim = per_camera_dim * len(config.cameras) if config.aggregate == "concat" else per_camera_dim

    feature_rows: list[np.ndarray] = []
    with torch.no_grad():
        for sample_token in tqdm(sample_tokens, desc="camera features"):
            paths = camera_image_paths(nusc, config.dataroot, sample_token, config.cameras)
            images = torch.stack(
                [
                    load_camera_tensor(path, transform, config.image_size)
                    for path in paths
                ],
                dim=0,
            ).to(device)
            feats = model(images).detach().float().cpu().numpy()
            if config.aggregate == "concat":
                row = feats.reshape(-1)
            elif config.aggregate == "mean":
                row = feats.mean(axis=0)
            else:
                raise ValueError("aggregate must be 'concat' or 'mean'")
            feature_rows.append(row.astype(np.float32))

    features = np.stack(feature_rows, axis=0).astype(np.float32)
    output = ensure_parent(out_path)
    np.savez_compressed(
        output,
        sample_tokens=np.asarray(sample_tokens),
        features=features,
    )
    metadata = {
        "version": config.version,
        "num_samples": len(sample_tokens),
        "cameras": list(config.cameras),
        "backbone": config.backbone,
        "image_size": config.image_size,
        "pretrained": config.pretrained,
        "aggregate": config.aggregate,
        "per_camera_dim": per_camera_dim,
        "feature_dim": output_dim,
        "path": str(output),
    }
    write_json(metadata, output.with_suffix(".json"))
    return metadata


def load_cached_camera_features(path: str | Path) -> tuple[dict[str, np.ndarray], int]:
    data = np.load(path, allow_pickle=True)
    tokens = [str(token) for token in data["sample_tokens"].tolist()]
    features = data["features"].astype(np.float32)
    mapping = {token: features[idx] for idx, token in enumerate(tokens)}
    return mapping, int(features.shape[1])
