from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.features.camera_features import DEFAULT_CAMERAS, CameraFeatureConfig
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Cache nuScenes multi-camera features for HydraMDP-style planners."
    )
    parser.add_argument("--config", default=None)
    parser.add_argument("--clips", required=True, help="Clip manifest CSV.")
    parser.add_argument("--dataroot", default=None)
    parser.add_argument("--version", default=None)
    parser.add_argument("--out", default="outputs/features/camera_features_resnet18.npz")
    parser.add_argument("--cameras", nargs="+", default=None)
    parser.add_argument("--backbone", default=None, choices=["resnet18", "resnet34", "resnet50"])
    parser.add_argument("--image-size", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--pretrained", action="store_true")
    parser.add_argument("--aggregate", choices=["concat", "mean"], default=None)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    dataset_cfg = cfg.get("dataset", {})
    camera_cfg = cfg.get("camera_features", {})
    planner_cfg = cfg.get("planner", {})
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version", "v1.0-mini")
    if not dataroot:
        raise SystemExit("--dataroot is required unless dataset.dataroot is set in --config")

    try:
        from src.features.camera_features import cache_camera_features
    except ImportError as exc:
        raise SystemExit(
            "camera feature caching requires torch, torchvision, pillow, and nuscenes-devkit."
        ) from exc

    config = CameraFeatureConfig(
        dataroot=dataroot,
        version=version,
        cameras=tuple(args.cameras or camera_cfg.get("cameras", DEFAULT_CAMERAS)),
        backbone=args.backbone or camera_cfg.get("backbone", "resnet18"),
        image_size=args.image_size
        if args.image_size is not None
        else int(camera_cfg.get("image_size", 224)),
        batch_size=args.batch_size
        if args.batch_size is not None
        else int(camera_cfg.get("batch_size", planner_cfg.get("batch_size", 32))),
        device=args.device or camera_cfg.get("device", planner_cfg.get("device", "auto")),
        pretrained=bool(args.pretrained or camera_cfg.get("pretrained", False)),
        aggregate=args.aggregate or camera_cfg.get("aggregate", "concat"),
        verbose=not args.quiet,
    )
    metadata = cache_camera_features(args.clips, args.out, config)
    logger.info("Wrote camera feature cache: %s", metadata["path"])
    logger.info("Cached %d sample tokens, feature_dim=%d", metadata["num_samples"], metadata["feature_dim"])


if __name__ == "__main__":
    main()
