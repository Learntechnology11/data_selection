"""Focused tests for the V1/V2 research selectors."""

from __future__ import annotations

import numpy as np

from fashion_mnist_coreset.data_protocols import ResearchPool
from fashion_mnist_coreset.proxy_signals import ProxySignals
from fashion_mnist_coreset.research_selectors import (
    build_joint_geometry,
    compute_voronoi_weights,
    select_v1_fisher_geodesic,
    select_v2_reliability_mass,
)


def test_research_selectors_support_unequal_classes_and_bounded_weights() -> None:
    rng = np.random.default_rng(7)
    labels = np.asarray([0] * 24 + [1] * 15 + [2] * 9 + [3] * 6 + [4] * 4, dtype=np.int64)
    n = len(labels)
    images = rng.integers(0, 256, size=(n, 28, 28), dtype=np.uint8)
    embeddings = rng.normal(size=(n, 16)) + labels[:, None] * 0.2
    probabilities = np.full((n, 10), 0.02, dtype=np.float64)
    probabilities[np.arange(n), labels] = 0.82
    probabilities = probabilities / probabilities.sum(axis=1, keepdims=True)
    fisher = rng.normal(size=(n, 12))
    reliability = np.linspace(0.2, 1.0, n)
    reject = np.zeros(n, dtype=bool)
    reject[[2, 30]] = True
    pool = ResearchPool(
        images=images,
        clean_labels=labels.copy(),
        observed_labels=labels.copy(),
        source_indices=np.arange(n),
        noise_mask=reject.copy(),
        noise_type=np.where(reject, "label_flip", "clean"),
        class_counts={cls: int(np.sum(labels == cls)) for cls in range(10)},
    )
    signals = ProxySignals(
        embeddings=embeddings,
        probabilities=probabilities,
        losses=-np.log(probabilities[np.arange(n), labels]),
        predicted_labels=labels.copy(),
        gradient_embedding=fisher.copy(),
        fisher_gradient=fisher,
        reliability=reliability,
        reject_mask=reject,
        class_distance_z=np.zeros(n),
        neighbor_agreement=np.ones(n),
        diagnostics={},
    )

    v1 = select_v1_fisher_geodesic(pool, signals, max_budget=20)
    v2 = select_v2_reliability_mass(pool, signals, max_budget=20)
    assert len(v1.ranking) == 20
    assert len(v2.ranking) == 20
    assert not any(reject[idx] for idx in v1.ranking)
    assert not any(reject[idx] for idx in v2.ranking)
    assert len(set(labels[v2.ranking])) >= 5

    geometry = build_joint_geometry(signals, representation_dim=8, gradient_dim=8)
    weights = compute_voronoi_weights(
        geometry,
        labels,
        v2.ranking[:10],
        reliability + 0.2 * (~reject),
    )
    assert len(weights) == 10
    assert np.isclose(np.mean(weights), 1.0)
    assert min(weights) >= 0.25 - 1e-9
    assert max(weights) <= 4.0 + 1e-9

