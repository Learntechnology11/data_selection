# MOSAIC-on-nuScenes 最小复现说明

本仓库按 `05_Codex_Prompts.md` 的阶段路线推进。当前已实现阶段 1-11 的主流程代码：

```text
nuScenes -> 10s clips -> base_train/pool/val -> clip features -> pool clustering -> HydraMDP-nuScenes planner train/eval -> ranking -> pilot scaling -> MOSAIC/baseline selection -> full experiments
```

## 环境

推荐使用已有 NPU/训练环境，或安装：

```bash
pip install -r requirements.txt
```

`nuscenes-devkit` 必须能读取真实 nuScenes 数据目录。
训练 planner 还需要 `torch` 和 `torchvision`；在 `00_1_NPU_env.md` 描述的服务器环境中已有 `torch`、`torch-npu` 和 `torchvision`。

AutoDL 上传、解压、mini 全流程训练和结果绘图可参考 `AUTODL_RUNBOOK.md`。

如需清空旧实验产物但保留代码和 nuScenes 数据：

```bash
python scripts/clean_outputs.py --yes
```

## nuScenes mini 阶段 1-5 命令

1. 构建 10 秒 clip manifest：

```bash
python scripts/build_nuscenes_clips.py \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --out outputs/clips/nuscenes_mini_clips.csv
```

输出字段：

```text
clip_id, scene_token, log_token, location, description,
start_sample_token, end_sample_token, sample_tokens, num_samples,
split, is_train_pool_candidate
```

2. 划分 base_train / pool / val：

```bash
python scripts/create_splits.py \
  --clips outputs/clips/nuscenes_mini_clips.csv \
  --mode mini_random \
  --base-ratio 0.2 \
  --pool-ratio 0.6 \
  --seed 42 \
  --out-dir outputs/splits
```

输出：

```text
outputs/splits/base_train.csv
outputs/splits/pool.csv
outputs/splits/val.csv
```

三者会检查 `clip_id` 无交集，且 mini_random 模式合计数量等于原 clips 数量。

3. 抽取 clip-level features：

```bash
python scripts/extract_clip_features.py \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --clips outputs/clips/nuscenes_mini_clips.csv \
  --out-dir outputs/features
```

输出：

```text
outputs/features/clip_features.parquet
outputs/features/clip_features.npy
outputs/features/clip_feature_columns.json
outputs/features/clip_feature_ids.json
```

特征包括：

```text
location one-hot, description TF-IDF,
mean/max speed, mean/max acceleration, mean/max yaw_rate,
total_displacement,
mean_num_agents, mean_num_vehicles, mean_num_pedestrians,
max_num_agents, min_distance_to_agent, mean_distance_to_nearest_agent
```

保存前会填充数值 NaN，并检查最终 numeric feature matrix 没有 NaN。

4. 对 D_pool 聚类：

```bash
python scripts/cluster_pool.py \
  --pool outputs/splits/pool.csv \
  --features outputs/features/clip_features.parquet \
  --method kmeans++ \
  --num-clusters 4 \
  --out-dir outputs/clusters
```

也可以使用 location 聚类：

```bash
python scripts/cluster_pool.py \
  --pool outputs/splits/pool.csv \
  --features outputs/features/clip_features.parquet \
  --method location \
  --out-dir outputs/clusters
```

输出：

```text
outputs/clusters/cluster_assignments.csv
outputs/clusters/cluster_summary.csv
```

`cluster_assignments.csv` 字段：

```text
clip_id, cluster_id, cluster_method
```

`cluster_summary.csv` 字段：

```text
cluster_id, num_clips, top_locations, top_description_keywords,
mean_speed, mean_num_agents
```

## 使用 YAML 配置

上述脚本也支持 `--config configs/mosaic_nuscenes_mini.yaml`。命令行参数优先级高于 YAML。

示例：

```bash
python scripts/build_nuscenes_clips.py \
  --config configs/mosaic_nuscenes_mini.yaml \
  --dataroot /path/to/nuscenes
```

## 阶段 6：HydraMDP-nuScenes 多模态 planner

阶段 6 被拆成三个可独立执行的子阶段，方便替换视觉 encoder、轨迹词表或 planner 架构。

6.1 缓存 6 路 camera features：

```bash
python scripts/cache_camera_features.py \
  --config configs/mosaic_nuscenes_mini.yaml \
  --clips outputs/clips/nuscenes_mini_clips.csv \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --out outputs/features/camera_features_resnet18_mini.npz
```

输出：

```text
outputs/features/camera_features_resnet18_mini.npz
outputs/features/camera_features_resnet18_mini.json
```

默认 backbone 是 `torchvision.resnet18`，不下载预训练权重。后续可替换为 `resnet50` 或自定义 VoVNet 特征缓存脚本。

6.2 构建 trajectory vocabulary：

```bash
python scripts/build_trajectory_vocab.py \
  --config configs/mosaic_nuscenes_mini.yaml \
  --clips outputs/splits/base_train.csv \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --num-modes 64 \
  --out outputs/vocab/trajectory_vocab_mini_64.npy
```

输出：

```text
outputs/vocab/trajectory_vocab_mini_64.npy
outputs/vocab/trajectory_vocab_mini_64.json
```

6.3 训练 base planner：

默认使用 `HydraMDP-nuScenes`：

```text
ego history + cached 6-camera features + nearby-agent tokens
-> transformer environment encoder
-> trajectory-vocabulary query decoder
-> candidate trajectories + imitation logits + metric score heads
loss = SmoothL1 trajectory loss + vocabulary CE + weak rule-metric distillation
```

训练默认使用 `AdamW`，`--epochs` 表示最大 epoch 上限；验证集 loss 连续 `20% * max_epochs`
个 epoch 无明显改善时早停，并且至少训练 `30% * max_epochs`，因此实际训练会停在验证集收敛附近。

```bash
python scripts/train_planner.py \
  --train outputs/splits/base_train.csv \
  --val outputs/splits/val.csv \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --config configs/mosaic_nuscenes_mini.yaml \
  --exp-name base_train
```

输出：

```text
outputs/checkpoints/base_train.pt
outputs/eval/base_train/metrics.json
outputs/eval/base_train/per_clip_metrics.csv
outputs/eval/base_train/per_window_metrics.csv
```

单独评估 checkpoint：

```bash
python scripts/evaluate_planner.py \
  --checkpoint outputs/checkpoints/base_train.pt \
  --eval outputs/splits/val.csv \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --config configs/mosaic_nuscenes_mini.yaml \
  --out-dir outputs/eval/base_train
```

HydraMDP-nuScenes 输入输出：

```text
输入: past ego states = local x, local y, yaw_delta, speed
输入: cached 6-camera visual features
输出: future local x/y trajectory offsets
输出: optional trajectory vocabulary logits
loss: SmoothL1Loss by default
metrics: ADE, FDE, heading_error, collision_proxy, offroad_proxy(NaN), jerk, utility
```

如果只想跑最小 sanity baseline，可临时覆盖为 MLP：

```bash
python scripts/train_planner.py \
  --train outputs/splits/base_train.csv \
  --val outputs/splits/val.csv \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --config configs/mosaic_nuscenes_mini.yaml \
  --model-type mlp \
  --exp-name base_train_mlp
```

## 下一阶段

## 阶段 7：Pool ranking

```bash
python scripts/rank_pool.py \
  --checkpoint outputs/checkpoints/base_train.pt \
  --pool outputs/splits/pool.csv \
  --clusters outputs/clusters/cluster_assignments.csv \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --config configs/mosaic_nuscenes_mini.yaml \
  --out-dir outputs/ranking
```

输出：

```text
outputs/ranking/pool_importance_scores.csv
outputs/ranking/cluster_ranked_pool.csv
```

## 阶段 8：Pilot experiments + scaling laws

```bash
python scripts/run_pilot_experiments.py \
  --base-train outputs/splits/base_train.csv \
  --val outputs/splits/val.csv \
  --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
  --pilot-budgets 5 10 20 \
  --mode finetune \
  --config configs/mosaic_nuscenes_mini.yaml \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini \
  --base-checkpoint outputs/checkpoints/base_train.pt \
  --base-metrics outputs/eval/base_train/metrics.json \
  --out outputs/pilot/pilot_results.csv
```

```bash
python scripts/fit_scaling_laws.py \
  --pilot-results outputs/pilot/pilot_results.csv \
  --out-dir outputs/scaling
```

输出：

```text
outputs/pilot/pilot_results.csv
outputs/scaling/scaling_params.json
outputs/scaling/scaling_fit_plot_cluster_{cluster_id}.png
```

## 阶段 9：MOSAIC selection

```bash
python scripts/select_mosaic.py \
  --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
  --scaling-params outputs/scaling/scaling_params.json \
  --budget 20 \
  --out-dir outputs/selections
```

输出：

```text
outputs/selections/mosaic_budget_20.csv
outputs/selections/mosaic_trace_budget_20.csv
```

## 阶段 10：Baselines

```bash
python scripts/select_baselines.py \
  --method random \
  --pool outputs/splits/pool.csv \
  --budget 20 \
  --seed 42 \
  --out-dir outputs/selections
```

```bash
python scripts/select_baselines.py \
  --method ranking_only \
  --pool outputs/splits/pool.csv \
  --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
  --budget 20 \
  --seed 42 \
  --out-dir outputs/selections
```

`coreset` 需要 `--features outputs/features/clip_features.parquet`，`cluster_only` 和 `uncertainty` 需要 `--ranked-pool`。

## 阶段 11：Full experiments

总控脚本只串联前面阶段的已有产物，不隐藏核心逻辑：

```bash
python scripts/run_selection_experiments.py \
  --config configs/mosaic_nuscenes_mini.yaml \
  --budget-ratios 0.30 0.50 \
  --methods random full mosaic \
  --seeds 0 2025 424242 \
  --dataroot /path/to/nuscenes \
  --version v1.0-mini
```

输出：

```text
outputs/results/main_results.csv
outputs/results/metric_breakdown.csv
outputs/results/cluster_distribution.csv
```
