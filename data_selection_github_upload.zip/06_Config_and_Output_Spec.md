# 配置文件与输出规范

## 1. `configs/mosaic_nuscenes_mini.yaml` 模板

```yaml
project:
  name: mosaic_nuscenes_mini
  seed: 42
  output_dir: outputs

dataset:
  name: nuscenes
  version: v1.0-mini
  dataroot: /path/to/nuscenes
  clip_duration_sec: 10.0
  min_num_samples_per_clip: 4

split:
  mode: mini_random
  base_ratio: 0.2
  pool_ratio: 0.6
  val_ratio: 0.2
  seed: 42

features:
  use_location: true
  use_description_tfidf: true
  tfidf_max_features: 256
  use_ego_motion: true
  use_agent_density: true
  use_map_proxy: false
  fill_nan: median

clustering:
  method: kmeans
  num_clusters: 4
  random_state: 42

planner:
  model_type: mlp
  past_horizon_sec: 2.0
  future_horizon_sec: 3.0
  batch_size: 32
  num_epochs: 100
  learning_rate: 0.001
  weight_decay: 0.0001
  hidden_dim: 128
  num_layers: 2
  dropout: 0.1
  device: auto

training:
  base_epochs: 100
  finetune_epochs: 40
  optimizer: adamw
  early_stopping:
    enabled: true
    patience_ratio: 0.20
    min_epochs_ratio: 0.30
    min_delta: 0.0001
  loss: smooth_l1

metrics:
  compute_ade: true
  compute_fde: true
  compute_heading_error: true
  compute_collision_proxy: true
  compute_offroad_proxy: false
  compute_jerk: true

utility:
  base_score: 100.0
  normalization: robust
  clip_min: 0.0
  clip_max: 5.0
  weights:
    ade: 30
    fde: 30
    heading_error: 10
    collision_proxy: 15
    offroad_proxy: 10
    jerk: 5

ranking:
  weights:
    ade: 0.35
    fde: 0.35
    heading_error: 0.10
    collision_proxy: 0.10
    offroad_proxy: 0.10

pilot:
  budgets: [5, 10, 20]
  mode: finetune
  seeds: [0]

selection:
  budgets: [20, 40, 80]
  methods:
    - random
    - coreset
    - ranking_only
    - mosaic
  seeds: [0, 2025, 424242]
  mosaic_step: 1
```

## 2. `configs/mosaic_nuscenes_trainval.yaml` 模板

```yaml
project:
  name: mosaic_nuscenes_trainval
  seed: 42
  output_dir: outputs

dataset:
  name: nuscenes
  version: v1.0-trainval
  dataroot: /path/to/nuscenes
  clip_duration_sec: 10.0
  min_num_samples_per_clip: 4

split:
  mode: official_trainval
  base_ratio_within_train: 0.1
  seed: 42

features:
  use_location: true
  use_description_tfidf: true
  tfidf_max_features: 1024
  use_ego_motion: true
  use_agent_density: true
  use_map_proxy: true
  fill_nan: median

clustering:
  method: kmeans
  num_clusters: 8
  random_state: 42

planner:
  model_type: mlp
  past_horizon_sec: 2.0
  future_horizon_sec: 3.0
  batch_size: 64
  num_epochs: 100
  learning_rate: 0.001
  weight_decay: 0.0001
  hidden_dim: 256
  num_layers: 3
  dropout: 0.1
  device: auto

training:
  base_epochs: 100
  finetune_epochs: 40
  optimizer: adamw
  early_stopping:
    enabled: true
    patience_ratio: 0.20
    min_epochs_ratio: 0.30
    min_delta: 0.0001
  loss: smooth_l1

metrics:
  compute_ade: true
  compute_fde: true
  compute_heading_error: true
  compute_collision_proxy: true
  compute_offroad_proxy: true
  compute_jerk: true

utility:
  base_score: 100.0
  normalization: robust
  clip_min: 0.0
  clip_max: 5.0
  weights:
    ade: 30
    fde: 30
    heading_error: 10
    collision_proxy: 15
    offroad_proxy: 10
    jerk: 5

ranking:
  weights:
    ade: 0.35
    fde: 0.35
    heading_error: 0.10
    collision_proxy: 0.10
    offroad_proxy: 0.10

pilot:
  budgets: [50, 100, 200]
  mode: finetune
  seeds: [0]

selection:
  budgets: [100, 200, 400, 800]
  methods:
    - random
    - coreset
    - ranking_only
    - cluster_only
    - mosaic
  seeds: [0, 2025, 424242]
  mosaic_step: 1
```

## 3. 输出文件规范

### 3.1 clips

路径：

```text
outputs/clips/nuscenes_{version}_clips.csv
```

字段：

```text
clip_id
scene_token
log_token
location
description
start_sample_token
end_sample_token
sample_tokens
num_samples
split
is_train_pool_candidate
```

`sample_tokens` 建议存 JSON string。

### 3.2 splits

路径：

```text
outputs/splits/base_train.csv
outputs/splits/pool.csv
outputs/splits/val.csv
```

字段至少包含：

```text
clip_id
scene_token
location
description
sample_tokens
```

### 3.3 features

路径：

```text
outputs/features/clip_features.parquet
outputs/features/clip_features.npy
outputs/features/clip_feature_columns.json
```

`clip_features.parquet` 字段：

```text
clip_id
location
mean_speed
max_speed
mean_acceleration
max_acceleration
mean_yaw_rate
max_yaw_rate
total_displacement
mean_num_agents
mean_num_vehicles
mean_num_pedestrians
min_distance_to_agent
... tfidf / one-hot columns
```

### 3.4 clusters

路径：

```text
outputs/clusters/cluster_assignments.csv
outputs/clusters/cluster_summary.csv
```

`cluster_assignments.csv`：

```text
clip_id
cluster_id
cluster_method
```

`cluster_summary.csv`：

```text
cluster_id
num_clips
top_locations
top_description_keywords
mean_speed
mean_num_agents
```

### 3.5 base evaluation

路径：

```text
outputs/eval/base_train/metrics.json
outputs/eval/base_train/per_clip_metrics.csv
```

`metrics.json`：

```json
{
  "utility": 83.2,
  "ade": 1.2,
  "fde": 2.8,
  "heading_error": 0.15,
  "collision_proxy": 0.02,
  "offroad_proxy": null,
  "jerk": 0.5
}
```

### 3.6 ranking

路径：

```text
outputs/ranking/pool_importance_scores.csv
outputs/ranking/cluster_ranked_pool.csv
```

字段：

```text
clip_id
cluster_id
ade
fde
heading_error
collision_proxy
offroad_proxy
jerk
importance_score
rank_within_cluster
```

### 3.7 pilot

路径：

```text
outputs/pilot/pilot_results.csv
```

字段：

```text
cluster_id
n
seed
selected_clip_ids
utility
delta_utility
ade
fde
heading_error
collision_proxy
offroad_proxy
checkpoint_path
```

### 3.8 scaling

路径：

```text
outputs/scaling/scaling_params.json
```

格式：

```json
{
  "0": {
    "a": 4.2,
    "tau": 18.5,
    "fit_success": true,
    "observed_ns": [5, 10, 20],
    "observed_delta_utility": [1.1, 2.4, 3.0]
  },
  "1": {
    "a": 2.0,
    "tau": 10.0,
    "fit_success": false,
    "fallback_reason": "curve_fit_failed"
  }
}
```

### 3.9 selection

路径：

```text
outputs/selections/mosaic_budget_{B}.csv
outputs/selections/mosaic_trace_budget_{B}.csv
```

`mosaic_budget_{B}.csv`：

```text
clip_id
cluster_id
rank_within_cluster
importance_score
selection_order
method
budget
```

`mosaic_trace_budget_{B}.csv`：

```text
step_id
selected_cluster_id
selected_clip_id
cluster_count_before
cluster_count_after
estimated_marginal_gain
```

### 3.10 final results

路径：

```text
outputs/results/main_results.csv
```

字段：

```text
dataset_version
method
budget
seed
utility
ade
fde
heading_error
collision_proxy
offroad_proxy
jerk
```

## 4. Sanity checks

Codex 必须实现这些检查：

```text
1. clip_id 唯一。
2. base_train、pool、val 无重叠。
3. pool 中每个 clip 都有 feature。
4. pool 中每个 clip 都有 cluster_id。
5. ranked_pool 中每个 pool clip 都有 importance_score。
6. 每个 cluster 内 rank_within_cluster 连续。
7. pilot results 覆盖所有 cluster。
8. scaling_params 覆盖所有 cluster。
9. selected clips 全部来自 pool。
10. selected clips 数量等于 budget。
11. final results 每个 method-budget-seed 都有一行。
```
