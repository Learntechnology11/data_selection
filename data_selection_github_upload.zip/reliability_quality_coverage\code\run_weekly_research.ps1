param(
    [string]$Python = "D:\anaconda\envs\torch_gpu\python.exe",
    [switch]$Download,
    [switch]$SkipTraining,
    [int]$Epochs = 50,
    [int]$Patience = 8,
    [int]$ProxyEpochs = 8,
    [int]$MaxTrain = 60000
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$argsList = @(
    "fashion_mnist_coreset\run_weekly_research.py",
    "--scenarios", "balanced_clean", "long_tail_clean", "long_tail_mixed_noise",
    "--budgets", "0.1", "0.3", "0.5",
    "--seeds", "42", "43", "44",
    "--epochs", "$Epochs",
    "--patience", "$Patience",
    "--proxy-epochs", "$ProxyEpochs",
    "--max-train", "$MaxTrain"
)

if ($Download) {
    $argsList += "--download"
}

if ($SkipTraining) {
    $argsList += "--skip-training"
}

& $Python -B @argsList

