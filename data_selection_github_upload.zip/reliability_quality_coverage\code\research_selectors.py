"""V0/V1/V2 selectors for the weekly DriveCore research study."""

from __future__ import annotations

import heapq
import math
from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Sequence

import numpy as np
from sklearn.decomposition import PCA

from fashion_mnist_coreset.algorithms import DatasetArrays, drivecore_coreset
from fashion_mnist_coreset.data_protocols import ResearchPool
from fashion_mnist_coreset.proxy_signals import ProxySignals


@dataclass
class ResearchSelection:
    """One ranked selection result at the maximum requested budget."""

    method: str
    ranking: List[int]
    weights: List[float]
    diagnostics: Dict[str, Any]
    trajectory: List[Dict[str, Any]]

    def truncate(self, count: int) -> "ResearchSelection":
        count = min(int(count), len(self.ranking))
        weights = self.weights[:count]
        if weights:
            arr = np.asarray(weights, dtype=np.float64)
            weights = (arr / max(float(arr.mean()), 1e-12)).tolist()
        return ResearchSelection(
            method=self.method,
            ranking=self.ranking[:count],
            weights=weights,
            diagnostics={**self.diagnostics, "truncated_to": count},
            trajectory=self.trajectory[:count],
        )


def build_joint_geometry(
    signals: ProxySignals,
    *,
    representation_dim: int = 24,
    gradient_dim: int = 24,
    lambda_z: float = 1.0,
    lambda_g: float = 1.0,
) -> np.ndarray:
    """Construct the Fisher-geodesic joint representation-gradient geometry."""

    z = _pca_standardize(signals.embeddings, representation_dim)
    g = _pca_standardize(signals.fisher_gradient, gradient_dim)
    parts = []
    if lambda_z > 0:
        parts.append(math.sqrt(lambda_z) * z)
    if lambda_g > 0:
        parts.append(math.sqrt(lambda_g) * g)
    geometry = np.concatenate(parts, axis=1)
    return geometry / np.maximum(np.linalg.norm(geometry, axis=1, keepdims=True), 1e-12)


def select_v0_denoise(
    pool: ResearchPool,
    signals: ProxySignals,
    max_budget: int,
    *,
    seed: int,
) -> ResearchSelection:
    """V0: conservative hard denoising followed by the previous DriveCore."""

    clean = np.flatnonzero(~signals.reject_mask)
    if len(clean) < max_budget:
        clean = np.argsort(signals.reliability)[::-1][:max_budget]
    data = DatasetArrays(
        images=pool.images[clean],
        labels=pool.observed_labels[clean],
        indices=clean.astype(int),
    )
    result = drivecore_coreset(
        data,
        signals.embeddings[clean],
        budget=min(max_budget, len(clean)),
        seed=seed,
    )
    selected = [int(idx) for idx in result.selected_indices]
    weights = list(result.weights)
    trajectory = [
        {
            "step": step,
            "sample_index": idx,
            "class": int(pool.observed_labels[idx]),
            "reliability": float(signals.reliability[idx]),
        }
        for step, idx in enumerate(selected, start=1)
    ]
    diagnostics = {
        "num_candidates": int(len(clean)),
        "num_rejected": int(signals.reject_mask.sum()),
        "class_counts": dict(Counter(int(pool.observed_labels[idx]) for idx in selected)),
        "selector": "previous DriveCore after conservative hard denoising",
    }
    return ResearchSelection("v0_denoise", selected, weights, diagnostics, trajectory)


def select_v1_fisher_geodesic(
    pool: ResearchPool,
    signals: ProxySignals,
    max_budget: int,
    *,
    class_alpha: float = 0.5,
    lambda_g: float = 1.0,
) -> ResearchSelection:
    """V1: hard-clean Fisher-geodesic K-center with dynamic class budgets."""

    geometry = build_joint_geometry(signals, lambda_g=lambda_g)
    local_orders: Dict[int, List[int]] = {}
    local_gains: Dict[int, List[float]] = {}
    local_radii: Dict[int, List[float]] = {}
    clean_mask = ~signals.reject_mask
    clean_total = max(int(clean_mask.sum()), 1)

    for cls in range(10):
        indices = np.flatnonzero((pool.observed_labels == cls) & clean_mask)
        if not len(indices):
            continue
        order, gains, radii = _kcenter_order(geometry[indices], indices)
        class_weight = (len(indices) / clean_total) ** float(class_alpha)
        local_orders[cls] = order
        local_gains[cls] = [float(class_weight * gain) for gain in gains]
        local_radii[cls] = radii

    method = "v1_gc" if lambda_g > 0 else "v1_no_fisher"
    ranking, trajectory = _merge_dynamic_orders(
        local_orders,
        local_gains,
        pool.observed_labels,
        max_budget,
        method=method,
    )
    weights = _voronoi_weights(
        geometry,
        pool.observed_labels,
        ranking,
        demand_weight=(~signals.reject_mask).astype(np.float64),
    )
    diagnostics = {
        "joint_geometry_dim": int(geometry.shape[1]),
        "num_rejected": int(signals.reject_mask.sum()),
        "class_counts": dict(Counter(int(pool.observed_labels[idx]) for idx in ranking)),
        "final_class_radii": {
            str(cls): float(local_radii.get(cls, [0.0])[min(len(local_radii.get(cls, [0.0])) - 1, max(sum(pool.observed_labels[idx] == cls for idx in ranking) - 1, 0))])
            if local_radii.get(cls)
            else 0.0
            for cls in range(10)
        },
        "objective": "weighted sum of classwise maximum Fisher-geodesic covering radii",
    }
    return ResearchSelection(method, ranking, weights, diagnostics, trajectory)


def select_v2_reliability_mass(
    pool: ResearchPool,
    signals: ProxySignals,
    max_budget: int,
    *,
    eta: float = 0.35,
    tail_fraction: float = 0.10,
    class_alpha: float = 1.0,
    use_reliability: bool = True,
    clean_mass_floor: float = 0.20,
) -> ResearchSelection:
    """V2: reliability-mass mean/CVaR covering with dynamic class budgets."""

    geometry = build_joint_geometry(signals)
    if use_reliability:
        reliability = np.asarray(signals.reliability, dtype=np.float64).copy()
        reliability += float(clean_mass_floor) * (~signals.reject_mask).astype(np.float64)
    else:
        reliability = np.ones(len(pool.observed_labels), dtype=np.float64)
    total_mass = max(float(reliability.sum()), 1e-12)
    local_orders: Dict[int, List[int]] = {}
    local_gains: Dict[int, List[float]] = {}
    local_objectives: Dict[int, List[float]] = {}

    for cls in range(10):
        demand = np.flatnonzero(pool.observed_labels == cls)
        if not len(demand):
            continue
        candidates = demand[~signals.reject_mask[demand]]
        if not len(candidates):
            candidates = demand[np.argsort(reliability[demand])[::-1][:1]]
        order, gains, objectives = _mass_cvar_order(
            geometry[demand],
            geometry[candidates],
            demand,
            candidates,
            reliability[demand],
            reliability[candidates],
            max_steps=min(len(candidates), max_budget),
            eta=eta,
            tail_fraction=tail_fraction,
        )
        class_mass = float(reliability[demand].sum() / total_mass)
        class_weight = class_mass ** float(class_alpha)
        local_orders[cls] = order
        local_gains[cls] = [float(class_weight * gain) for gain in gains]
        local_objectives[cls] = objectives

    if not use_reliability:
        method = "v2_no_reliability"
    elif eta <= 0:
        method = "v2_no_cvar"
    else:
        method = "v2_rmc"
    ranking, trajectory = _merge_dynamic_orders(
        local_orders,
        local_gains,
        pool.observed_labels,
        max_budget,
        method=method,
    )
    weights = _voronoi_weights(
        geometry,
        pool.observed_labels,
        ranking,
        demand_weight=reliability,
    )
    diagnostics = {
        "joint_geometry_dim": int(geometry.shape[1]),
        "eta": float(eta),
        "tail_fraction": float(tail_fraction),
        "clean_mass_floor": float(clean_mass_floor),
        "num_hard_rejected_candidates": int(signals.reject_mask.sum()),
        "class_counts": dict(Counter(int(pool.observed_labels[idx]) for idx in ranking)),
        "final_class_objectives": {
            str(cls): float(local_objectives.get(cls, [0.0])[min(len(local_objectives.get(cls, [0.0])) - 1, max(sum(pool.observed_labels[idx] == cls for idx in ranking) - 1, 0))])
            if local_objectives.get(cls)
            else 0.0
            for cls in range(10)
        },
        "objective": "(1-eta) reliability-mass mean distance + eta weighted CVaR tail distance",
    }
    return ResearchSelection(method, ranking, weights, diagnostics, trajectory)


def select_feature_kcenter(
    pool: ResearchPool,
    signals: ProxySignals,
    max_budget: int,
) -> ResearchSelection:
    """Feature-only K-center baseline with dynamic class allocation."""

    geometry = _pca_standardize(signals.embeddings, 32)
    local_orders: Dict[int, List[int]] = {}
    local_gains: Dict[int, List[float]] = {}
    for cls in range(10):
        indices = np.flatnonzero(pool.observed_labels == cls)
        if not len(indices):
            continue
        order, gains, _ = _kcenter_order(geometry[indices], indices)
        local_orders[cls] = order
        local_gains[cls] = gains
    ranking, trajectory = _merge_dynamic_orders(
        local_orders,
        local_gains,
        pool.observed_labels,
        max_budget,
        method="feature_kcenter",
    )
    weights = _voronoi_weights(
        geometry,
        pool.observed_labels,
        ranking,
        demand_weight=np.ones(len(pool.observed_labels), dtype=np.float64),
    )
    return ResearchSelection(
        "feature_kcenter",
        ranking,
        weights,
        {"class_counts": dict(Counter(int(pool.observed_labels[idx]) for idx in ranking))},
        trajectory,
    )


def compute_voronoi_weights(
    geometry: np.ndarray,
    labels: np.ndarray,
    ranking: Sequence[int],
    demand_weight: np.ndarray,
) -> List[float]:
    """Recompute representative mass weights for a ranking prefix."""

    return _voronoi_weights(
        geometry,
        labels,
        ranking,
        demand_weight=np.asarray(demand_weight, dtype=np.float64),
    )


def _kcenter_order(points: np.ndarray, global_indices: np.ndarray) -> tuple[List[int], List[float], List[float]]:
    n = len(points)
    if n == 0:
        return [], [], []
    distance = _pairwise_squared(points, points)
    center = points.mean(axis=0)
    seed = int(np.argmin(np.sum((points - center[None, :]) ** 2, axis=1)))
    selected = [seed]
    min_d2 = distance[:, seed].copy()
    radius = float(np.sqrt(np.max(min_d2)))
    order = [int(global_indices[seed])]
    gains = [radius]
    radii = [radius]
    min_d2[seed] = 0.0
    while len(selected) < n:
        candidate = int(np.argmax(min_d2))
        old_radius = float(np.sqrt(np.max(min_d2)))
        min_d2 = np.minimum(min_d2, distance[:, candidate])
        min_d2[candidate] = 0.0
        new_radius = float(np.sqrt(np.max(min_d2)))
        selected.append(candidate)
        order.append(int(global_indices[candidate]))
        gains.append(max(old_radius - new_radius, 0.0))
        radii.append(new_radius)
    return order, gains, radii


def _mass_cvar_order(
    demand_points: np.ndarray,
    candidate_points: np.ndarray,
    demand_global: np.ndarray,
    candidate_global: np.ndarray,
    reliability: np.ndarray,
    candidate_reliability: np.ndarray,
    *,
    max_steps: int,
    eta: float,
    tail_fraction: float,
) -> tuple[List[int], List[float], List[float]]:
    del demand_global
    d2 = _pairwise_squared(demand_points, candidate_points)
    mass = np.maximum(np.asarray(reliability, dtype=np.float64), 1e-6)
    mass = mass / mass.sum()
    mean_after_one = mass @ d2
    shortlist = np.argsort(mean_after_one)[: min(32, len(candidate_global))]
    seed_scores = []
    for col in shortlist:
        base_objective = _mass_cvar_objective(d2[:, col], mass, eta, tail_fraction)
        seed_scores.append(base_objective / max(float(candidate_reliability[col]), 0.10))
    seed_col = int(shortlist[int(np.argmin(seed_scores))])

    selected_cols = {seed_col}
    order = [int(candidate_global[seed_col])]
    current = d2[:, seed_col].copy()
    current_objective = _mass_cvar_objective(current, mass, eta, tail_fraction)
    gains = [current_objective]
    objectives = [current_objective]

    gain_vector = _mass_cvar_gain_vector(current, d2, mass, eta, tail_fraction)
    gain_vector = gain_vector * np.sqrt(np.maximum(candidate_reliability, 0.01))
    heap = [(-float(gain_vector[col]), col) for col in range(len(candidate_global)) if col not in selected_cols]
    heapq.heapify(heap)
    while len(order) < min(int(max_steps), len(candidate_global)) and heap:
        while heap:
            _, col = heapq.heappop(heap)
            if col in selected_cols:
                continue
            exact_gain = _mass_cvar_gain_scalar(current, d2[:, col], mass, eta, tail_fraction)
            exact_gain *= math.sqrt(max(float(candidate_reliability[col]), 0.01))
            next_bound = -heap[0][0] if heap else -float("inf")
            if exact_gain + 1e-12 >= next_bound:
                break
            heapq.heappush(heap, (-float(exact_gain), col))
        else:
            break
        selected_cols.add(col)
        new_current = np.minimum(current, d2[:, col])
        new_objective = _mass_cvar_objective(new_current, mass, eta, tail_fraction)
        gains.append(max(current_objective - new_objective, 0.0))
        objectives.append(new_objective)
        current = new_current
        current_objective = new_objective
        order.append(int(candidate_global[col]))
    return order, gains, objectives


def _merge_dynamic_orders(
    local_orders: Mapping[int, Sequence[int]],
    local_gains: Mapping[int, Sequence[float]],
    labels: np.ndarray,
    budget: int,
    *,
    method: str,
) -> tuple[List[int], List[Dict[str, Any]]]:
    positions = {cls: 0 for cls in local_orders}
    ranking: List[int] = []
    trajectory: List[Dict[str, Any]] = []

    # Give every non-empty class one seed before pure marginal-gain scheduling.
    seed_classes = [cls for cls, order in local_orders.items() if order]
    seed_classes.sort(key=lambda cls: local_gains[cls][0] if local_gains.get(cls) else 0.0, reverse=True)
    for cls in seed_classes:
        if len(ranking) >= budget:
            break
        sample = int(local_orders[cls][0])
        positions[cls] = 1
        ranking.append(sample)
        trajectory.append(
            {
                "step": len(ranking),
                "method": method,
                "class": int(labels[sample]),
                "sample_index": sample,
                "marginal_gain": float(local_gains[cls][0] if local_gains.get(cls) else 0.0),
                "class_selected_count": 1,
            }
        )

    class_counts = Counter(int(labels[idx]) for idx in ranking)
    while len(ranking) < budget:
        best_cls = None
        best_gain = -float("inf")
        for cls, order in local_orders.items():
            pos = positions[cls]
            if pos >= len(order):
                continue
            gain = float(local_gains[cls][pos]) if pos < len(local_gains[cls]) else 0.0
            if gain > best_gain:
                best_gain = gain
                best_cls = cls
        if best_cls is None:
            break
        pos = positions[best_cls]
        sample = int(local_orders[best_cls][pos])
        positions[best_cls] += 1
        ranking.append(sample)
        class_counts[int(labels[sample])] += 1
        trajectory.append(
            {
                "step": len(ranking),
                "method": method,
                "class": int(labels[sample]),
                "sample_index": sample,
                "marginal_gain": float(best_gain),
                "class_selected_count": int(class_counts[int(labels[sample])]),
            }
        )
    return ranking, trajectory


def _voronoi_weights(
    geometry: np.ndarray,
    labels: np.ndarray,
    ranking: Sequence[int],
    *,
    demand_weight: np.ndarray,
) -> List[float]:
    selected = list(ranking)
    if not selected:
        return []
    result = np.zeros(len(selected), dtype=np.float64)
    position = {sample: pos for pos, sample in enumerate(selected)}
    for cls in range(10):
        demand = np.flatnonzero(labels == cls)
        selected_cls = [idx for idx in selected if int(labels[idx]) == cls]
        if not len(demand) or not selected_cls:
            continue
        d2 = _pairwise_squared(geometry[demand], geometry[selected_cls])
        nearest = np.argmin(d2, axis=1)
        for row, nearest_pos in enumerate(nearest):
            result[position[selected_cls[int(nearest_pos)]]] += float(demand_weight[demand[row]])
    if result.mean() <= 1e-12:
        return [1.0] * len(selected)
    return _bounded_mean_one(result, lower=0.25, upper=4.0).tolist()


def _mass_cvar_gain_vector(
    current: np.ndarray,
    candidate_d2: np.ndarray,
    mass: np.ndarray,
    eta: float,
    tail_fraction: float,
) -> np.ndarray:
    improvement = np.maximum(current[:, None] - candidate_d2, 0.0)
    mean_gain = mass @ improvement
    tail_weight = _tail_weights(current, mass, tail_fraction)
    tail_gain = tail_weight @ improvement
    return (1.0 - eta) * mean_gain + eta * tail_gain


def _mass_cvar_gain_scalar(
    current: np.ndarray,
    candidate_d2: np.ndarray,
    mass: np.ndarray,
    eta: float,
    tail_fraction: float,
) -> float:
    improvement = np.maximum(current - candidate_d2, 0.0)
    mean_gain = float(np.dot(mass, improvement))
    tail_gain = float(np.dot(_tail_weights(current, mass, tail_fraction), improvement))
    return (1.0 - eta) * mean_gain + eta * tail_gain


def _mass_cvar_objective(values: np.ndarray, mass: np.ndarray, eta: float, tail_fraction: float) -> float:
    mean = float(np.dot(mass, values))
    tail = float(np.dot(_tail_weights(values, mass, tail_fraction), values))
    return (1.0 - eta) * mean + eta * tail


def _tail_weights(values: np.ndarray, mass: np.ndarray, tail_fraction: float) -> np.ndarray:
    order = np.argsort(values)[::-1]
    target = min(max(float(tail_fraction), 1e-3), 1.0)
    weights = np.zeros_like(mass, dtype=np.float64)
    accumulated = 0.0
    for idx in order:
        remaining = target - accumulated
        if remaining <= 1e-12:
            break
        take = min(float(mass[idx]), remaining)
        weights[idx] = take
        accumulated += take
    return weights / max(accumulated, 1e-12)


def _pairwise_squared(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)
    a2 = np.sum(a * a, axis=1, keepdims=True)
    b2 = np.sum(b * b, axis=1, keepdims=True).T
    return np.maximum(a2 + b2 - 2.0 * (a @ b.T), 0.0).astype(np.float32)


def _pca_standardize(values: np.ndarray, dim: int) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    standardized = (values - values.mean(axis=0, keepdims=True)) / np.maximum(values.std(axis=0, keepdims=True), 1e-6)
    n_components = max(1, min(int(dim), standardized.shape[1], standardized.shape[0] - 1))
    return PCA(n_components=n_components, random_state=0).fit_transform(standardized)


def _bounded_mean_one(values: np.ndarray, lower: float, upper: float) -> np.ndarray:
    values = np.maximum(np.asarray(values, dtype=np.float64), 1e-12)
    lo = 0.0
    hi = 1.0 / max(float(values.min()), 1e-12)
    for _ in range(80):
        scale = (lo + hi) / 2.0
        mean = float(np.clip(values * scale, lower, upper).mean())
        if mean < 1.0:
            lo = scale
        else:
            hi = scale
    return np.clip(values * ((lo + hi) / 2.0), lower, upper)


__all__ = [
    "ResearchSelection",
    "build_joint_geometry",
    "compute_voronoi_weights",
    "select_feature_kcenter",
    "select_v0_denoise",
    "select_v1_fisher_geodesic",
    "select_v2_reliability_mass",
]
