# Weekly Research: Reliable Training-Manifold Covering

## Research Story

The previous version answered:

> Which samples are sufficiently trustworthy to enter the candidate pool?

This week's work asks:

> How should a limited budget cover the trustworthy training-effective
> manifold?

The progression is:

```text
V0: conservative intra-class denoising
V1: Fisher-geodesic maximum-radius covering
V2: reliability-mass mean/CVaR covering
```

## V0: Conservative Intra-Class Denoising

A cross-fitted proxy CNN provides out-of-fold probabilities and losses. A
separate full-pool proxy provides a common embedding space.

A sample is hard-rejected only when multiple signals agree:

- high-confidence prediction conflicts with the observed label;
- class-conditional robust feature distance is high;
- local-neighborhood label agreement is low.

The continuous reliability value is preserved even when a sample is not
hard-rejected.

## V1: Fisher-Geodesic Covering

The joint geometry is:

```text
psi_i = [sqrt(lambda_z) z_i; sqrt(lambda_g) g_i^F]
```

where `z_i` is the proxy representation and `g_i^F` is the empirical-Fisher
normalized classification-head gradient.

Within every class, V1 minimizes the maximum nearest-selected distance. Each
class produces a local marginal radius-reduction sequence. A global scheduler
always gives the next sample to the class with the largest remaining weighted
radius reduction.

Therefore unequal class budgets are an output of the covering process, not a
fixed equal quota.

## V1 Limitation

Maximum-radius covering treats every surviving point as equally important. A
small number of residual edge/noise samples can control the objective and draw
budget away from the main data mass.

## V2: Reliability-Mass Covering

V2 uses the objective:

```text
J(C) =
  (1 - eta) * E_p[d(x, C)^2]
  + eta * CVaR_q^p[d(x, C)^2]
```

Reliability determines probability mass, while CVaR protects the worst-covered
credible tail. Candidate marginal gain is also reliability-modulated so an
unreliable point cannot become a representative merely because it is a
geometric shortcut.

Hard-but-clean samples receive a minimum mass floor. Training representative
weights are clipped to `[0.25, 4.0]` and gradually anneal toward the complete
clean distribution as the budget grows.

## Data Protocol

The research runner supports:

- `balanced_clean`
- `long_tail_clean`
- `long_tail_mixed_noise`

Mixed noise contains label flips, Gaussian corruption, and occlusion. Noise is
added only to the train pool. Validation and official test data remain clean.

## Final Pilot

The checked pilot used:

```text
max_train=6000
scenario=long_tail_mixed_noise
noise_rate=15%
seeds=42,43,44
budgets=10%,50%
proxy_epochs=5
train_epochs<=30
validation patience=6
```

Mean test accuracy:

| method | 10% | 50% |
|---|---:|---:|
| Random | 75.75% | 81.22% |
| V0 Denoise | 69.43% | 81.78% |
| V1 Fisher-Geodesic | 72.05% | 81.52% |
| V2 Reliability-Mass | **77.96%** | **82.81%** |
| Full data | - | 84.03% |

These are pilot results on a reduced train pool, not the final full-60k result.

## Commands

Three-seed pilot:

```powershell
D:\anaconda\envs\torch_gpu\python.exe -B fashion_mnist_coreset\run_weekly_research.py `
  --scenarios long_tail_mixed_noise `
  --methods random v0_denoise v1_gc v2_rmc `
  --budgets 0.1 0.5 `
  --seeds 42 43 44 `
  --max-train 6000 `
  --val-size 1000 `
  --noise-rate 0.15 `
  --proxy-epochs 5 `
  --epochs 30 `
  --patience 6 `
  --output-dir fashion_mnist_coreset\outputs\weekly_research_final_pilot
```

Full formal study:

```powershell
powershell -ExecutionPolicy Bypass -File fashion_mnist_coreset\run_weekly_research.ps1 `
  -Download -Epochs 50 -Patience 8 -ProxyEpochs 8 -MaxTrain 60000
```

