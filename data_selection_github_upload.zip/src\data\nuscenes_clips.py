from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from src.utils.io import json_dumps_list, write_csv


CLIP_COLUMNS = [
    "clip_id",
    "scene_token",
    "log_token",
    "location",
    "description",
    "start_sample_token",
    "end_sample_token",
    "sample_tokens",
    "num_samples",
    "split",
    "is_train_pool_candidate",
]


@dataclass(frozen=True)
class ClipBuildConfig:
    dataroot: str
    version: str
    clip_duration_sec: float = 10.0
    min_num_samples_per_clip: int = 4
    verbose: bool = True


def load_nuscenes(dataroot: str, version: str, verbose: bool = True) -> Any:
    try:
        from nuscenes.nuscenes import NuScenes
    except ImportError as exc:
        raise ImportError(
            "nuscenes-devkit is required. Install it with `pip install nuscenes-devkit`."
        ) from exc
    return NuScenes(version=version, dataroot=dataroot, verbose=verbose)


def infer_scene_splits(version: str) -> dict[str, str]:
    try:
        from nuscenes.utils.splits import create_splits_scenes
    except ImportError:
        return {}

    split_scenes = create_splits_scenes()
    version_lower = version.lower()
    if "mini" in version_lower:
        preferred_splits = ["mini_train", "mini_val"]
    elif "trainval" in version_lower:
        preferred_splits = ["train", "val"]
    elif "test" in version_lower:
        preferred_splits = ["test"]
    else:
        preferred_splits = list(split_scenes)

    mapping: dict[str, str] = {}
    for split_name in preferred_splits:
        for scene_name in split_scenes.get(split_name, []):
            mapping[scene_name] = split_name
    for split_name, scene_names in split_scenes.items():
        for scene_name in scene_names:
            mapping.setdefault(scene_name, split_name)
    return mapping


def get_scene_sample_tokens(nusc: Any, scene: dict[str, Any]) -> list[str]:
    tokens: list[str] = []
    token = scene.get("first_sample_token", "")
    while token:
        tokens.append(token)
        sample = nusc.get("sample", token)
        token = sample.get("next", "")
    return tokens


def _sample_times_sec(nusc: Any, tokens: list[str]) -> list[float]:
    if not tokens:
        return []
    first_timestamp = float(nusc.get("sample", tokens[0])["timestamp"])
    return [
        (float(nusc.get("sample", token)["timestamp"]) - first_timestamp) / 1_000_000.0
        for token in tokens
    ]


def _window_tokens(
    tokens: list[str],
    times_sec: list[float],
    clip_duration_sec: float,
) -> list[list[str]]:
    if not tokens:
        return []
    if clip_duration_sec <= 0:
        raise ValueError("clip_duration_sec must be positive")

    last_time = times_sec[-1]
    num_windows = max(1, int(math.ceil((last_time + 1e-9) / clip_duration_sec)))
    windows: list[list[str]] = []
    for window_idx in range(num_windows):
        start = window_idx * clip_duration_sec
        end = start + clip_duration_sec
        if window_idx == num_windows - 1:
            selected = [
                token
                for token, timestamp in zip(tokens, times_sec)
                if start <= timestamp <= end + 1e-6
            ]
        else:
            selected = [
                token
                for token, timestamp in zip(tokens, times_sec)
                if start <= timestamp < end
            ]
        if selected:
            windows.append(selected)
    return windows


def build_clip_manifest(nusc: Any, config: ClipBuildConfig) -> pd.DataFrame:
    scene_split = infer_scene_splits(config.version)
    rows: list[dict[str, Any]] = []

    for scene in nusc.scene:
        scene_name = scene["name"]
        sample_tokens = get_scene_sample_tokens(nusc, scene)
        times_sec = _sample_times_sec(nusc, sample_tokens)
        windows = _window_tokens(sample_tokens, times_sec, config.clip_duration_sec)
        log = nusc.get("log", scene["log_token"])
        split = scene_split.get(scene_name, "")
        is_train_pool_candidate = split not in {"val", "mini_val", "test"}

        clip_index = 0
        for tokens in windows:
            if len(tokens) < config.min_num_samples_per_clip:
                continue
            rows.append(
                {
                    "clip_id": f"{scene_name}_clip_{clip_index}",
                    "scene_token": scene["token"],
                    "log_token": scene["log_token"],
                    "location": log.get("location", "unknown"),
                    "description": scene.get("description", ""),
                    "start_sample_token": tokens[0],
                    "end_sample_token": tokens[-1],
                    "sample_tokens": json_dumps_list(tokens),
                    "num_samples": len(tokens),
                    "split": split,
                    "is_train_pool_candidate": bool(is_train_pool_candidate),
                }
            )
            clip_index += 1

    clips = pd.DataFrame(rows, columns=CLIP_COLUMNS)
    validate_clip_manifest(clips, config.min_num_samples_per_clip)
    return clips


def validate_clip_manifest(clips: pd.DataFrame, min_num_samples: int) -> None:
    if clips.empty:
        raise ValueError("No clips were built. Check dataroot, version, and clip settings.")
    if clips["clip_id"].duplicated().any():
        duplicates = clips.loc[clips["clip_id"].duplicated(), "clip_id"].tolist()
        raise ValueError(f"clip_id must be unique. Duplicates: {duplicates[:5]}")
    if clips["sample_tokens"].isna().any():
        raise ValueError("sample_tokens contains null values")
    if (clips["num_samples"] < min_num_samples).any():
        bad = clips.loc[clips["num_samples"] < min_num_samples, "clip_id"].tolist()
        raise ValueError(
            f"Every clip must have at least {min_num_samples} samples. Bad clips: {bad[:5]}"
        )


def build_and_save_clips(config: ClipBuildConfig, out_path: str | Path) -> pd.DataFrame:
    nusc = load_nuscenes(config.dataroot, config.version, config.verbose)
    clips = build_clip_manifest(nusc, config)
    write_csv(clips, out_path)
    return clips
