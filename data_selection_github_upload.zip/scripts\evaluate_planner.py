from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.nuscenes_clips import load_nuscenes
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate a trained ego planner checkpoint.")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--eval", required=True, help="Evaluation clip manifest CSV.")
    parser.add_argument("--dataroot", default=None)
    parser.add_argument("--version", default=None)
    parser.add_argument("--config", default=None)
    parser.add_argument("--out-dir", default="outputs/eval/base_train")
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--camera-features", default=None)
    parser.add_argument("--trajectory-vocab", default=None)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def dataset_config_from_sources(
    checkpoint: dict[str, Any],
    planner_cfg: dict[str, Any],
) -> PlannerDatasetConfig:
    from src.models.ego_planner_dataset import PlannerDatasetConfig

    checkpoint_cfg = checkpoint.get("dataset_config", {})
    return PlannerDatasetConfig(
        past_horizon_sec=float(
            planner_cfg.get("past_horizon_sec", checkpoint_cfg.get("past_horizon_sec", 2.0))
        ),
        future_horizon_sec=float(
            planner_cfg.get("future_horizon_sec", checkpoint_cfg.get("future_horizon_sec", 3.0))
        ),
        sample_interval_sec=float(
            planner_cfg.get("sample_interval_sec", checkpoint_cfg.get("sample_interval_sec", 0.5))
        ),
        collision_distance_m=float(
            planner_cfg.get("collision_distance_m", checkpoint_cfg.get("collision_distance_m", 2.0))
        ),
        max_windows_per_clip=planner_cfg.get(
            "max_windows_per_clip", checkpoint_cfg.get("max_windows_per_clip")
        ),
        camera_features_path=planner_cfg.get(
            "camera_features_path", checkpoint_cfg.get("camera_features_path")
        ),
        trajectory_vocab_path=planner_cfg.get(
            "trajectory_vocab_path", checkpoint_cfg.get("trajectory_vocab_path")
        ),
        max_agents=int(planner_cfg.get("max_agents", checkpoint_cfg.get("max_agents", 32))),
    )


def main() -> None:
    args = parse_args()
    try:
        import torch
    except ImportError as exc:
        raise SystemExit(
            "torch is required to evaluate the planner. Run this script in the NPU/torch "
            "environment described by 00_1_NPU_env.md, or install torch locally."
        ) from exc

    from src.models.ego_planner import build_model_from_checkpoint, select_device
    from src.models.ego_planner_dataset import EgoTrajectoryDataset
    from src.models.train_utils import evaluate_model_to_outputs, make_dataloader

    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    dataset_cfg = cfg.get("dataset", {})
    planner_cfg = cfg.get("planner", {})
    if args.camera_features:
        planner_cfg = {**planner_cfg, "camera_features_path": args.camera_features}
    if args.trajectory_vocab:
        planner_cfg = {**planner_cfg, "trajectory_vocab_path": args.trajectory_vocab}
    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version") or checkpoint.get(
        "dataset_version", "v1.0-mini"
    )
    if not dataroot:
        raise SystemExit("--dataroot is required unless dataset.dataroot is set in --config")

    device = select_device(args.device or planner_cfg.get("device", "auto"))
    dataset_config = dataset_config_from_sources(checkpoint, planner_cfg)
    nusc = load_nuscenes(dataroot, version, verbose=not args.quiet)
    eval_dataset = EgoTrajectoryDataset(
        args.eval,
        dataroot=dataroot,
        version=version,
        config=dataset_config,
        nusc=nusc,
        verbose=False,
    )
    model = build_model_from_checkpoint(checkpoint).to(device)
    batch_size = args.batch_size or int(planner_cfg.get("batch_size", 32))
    eval_loader = make_dataloader(
        eval_dataset, batch_size=batch_size, shuffle=False, num_workers=args.num_workers
    )
    metrics, _ = evaluate_model_to_outputs(
        model,
        eval_dataset,
        eval_loader,
        device,
        utility_cfg=cfg.get("utility", checkpoint.get("utility_config", {})),
        out_dir=args.out_dir,
        collision_threshold_m=dataset_config.collision_distance_m,
    )
    logger.info("Evaluated %d windows from %d clips", len(eval_dataset), int(metrics["num_clips"]))
    logger.info("Saved evaluation outputs under: %s", args.out_dir)


if __name__ == "__main__":
    main()
