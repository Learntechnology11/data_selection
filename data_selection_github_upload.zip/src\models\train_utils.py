from __future__ import annotations

from typing import Any

import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader

from src.evaluation.metrics import aggregate_window_metrics, compute_sample_metrics
from src.evaluation.utility import compute_utility_from_frame, sanitize_metrics_for_json
from src.utils.io import ensure_dir, write_csv, write_json


def make_dataloader(
    dataset: torch.utils.data.Dataset,
    batch_size: int,
    shuffle: bool,
    num_workers: int = 0,
) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )


def build_loss(loss_name: str) -> nn.Module:
    normalized = loss_name.lower()
    if normalized in {"smooth_l1", "smoothl1", "huber"}:
        return nn.SmoothL1Loss()
    if normalized in {"l1", "mae"}:
        return nn.L1Loss()
    if normalized in {"mse", "l2"}:
        return nn.MSELoss()
    raise ValueError(f"Unsupported loss: {loss_name}")


def move_batch_to_device(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    moved: dict[str, Any] = {}
    for key, value in batch.items():
        if torch.is_tensor(value):
            if key == "trajectory_class":
                moved[key] = value.to(device=device, dtype=torch.long)
            elif key == "record_index":
                moved[key] = value.to(device=device)
            else:
                moved[key] = value.to(device=device, dtype=torch.float32)
        else:
            moved[key] = value
    return moved


def forward_model(model: nn.Module, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
    outputs = model(batch)
    if torch.is_tensor(outputs):
        return {"trajectory": outputs}
    return outputs


def planner_loss(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, Any],
    regression_loss: nn.Module,
    classification_weight: float = 0.0,
    metric_score_weight: float = 0.0,
    collision_threshold_m: float = 2.0,
) -> torch.Tensor:
    loss = regression_loss(outputs["trajectory"], batch["targets"])
    if (
        classification_weight > 0
        and "trajectory_logits" in outputs
        and "trajectory_class" in batch
    ):
        ce = nn.functional.cross_entropy(outputs["trajectory_logits"], batch["trajectory_class"])
        loss = loss + classification_weight * ce
    if (
        metric_score_weight > 0
        and "metric_scores" in outputs
        and "candidate_trajectories" in outputs
    ):
        targets = rule_metric_targets(
            outputs["candidate_trajectories"].detach(),
            batch,
            collision_threshold_m=collision_threshold_m,
            metric_dim=int(outputs["metric_scores"].shape[-1]),
        )
        metric_loss = nn.functional.mse_loss(outputs["metric_scores"], targets)
        loss = loss + metric_score_weight * metric_loss
    return loss


def rule_metric_targets(
    candidate_trajectories: torch.Tensor,
    batch: dict[str, Any],
    *,
    collision_threshold_m: float,
    metric_dim: int,
) -> torch.Tensor:
    """Build weak rule-teacher costs for candidate trajectories.

    Heads are ordered as:
    0. collision proximity risk;
    1. early time-to-collision-style proximity risk;
    2. comfort risk from jerk.
    Extra heads, if requested, are filled with zeros.
    """

    bsz, num_modes, future_steps, _ = candidate_trajectories.shape
    device = candidate_trajectories.device
    dtype = candidate_trajectories.dtype
    out = torch.zeros(bsz, num_modes, int(metric_dim), device=device, dtype=dtype)
    if metric_dim <= 0:
        return out

    centers = batch.get("future_agent_centers")
    mask = batch.get("future_agent_mask")
    if centers is not None and mask is not None:
        centers = centers.to(device=device, dtype=dtype)
        mask = mask.to(device=device, dtype=dtype)
        distances = torch.linalg.norm(
            candidate_trajectories[:, :, :, None, :] - centers[:, None, :, :, :],
            dim=-1,
        )
        valid = mask[:, None, :, :] > 0.5
        large = torch.full_like(distances, 1e6)
        masked_distances = torch.where(valid, distances, large)
        min_per_step = masked_distances.amin(dim=-1)
        has_agents = valid.any(dim=-1)
        min_per_step = torch.where(has_agents, min_per_step, torch.full_like(min_per_step, 1e6))
        min_overall = min_per_step.amin(dim=-1)
        collision_risk = torch.sigmoid((float(collision_threshold_m) - min_overall) * 3.0)
        out[:, :, 0] = collision_risk
        if metric_dim > 1:
            time_weights = torch.linspace(
                1.0,
                0.35,
                steps=future_steps,
                device=device,
                dtype=dtype,
            ).view(1, 1, future_steps)
            proximity = torch.sigmoid((float(collision_threshold_m) - min_per_step) * 2.0)
            proximity = torch.where(has_agents, proximity, torch.zeros_like(proximity))
            denom = torch.clamp((has_agents.to(dtype) * time_weights).sum(dim=-1), min=1e-6)
            out[:, :, 1] = (proximity * time_weights).sum(dim=-1) / denom

    if metric_dim > 2:
        if future_steps >= 4:
            jerk = torch.diff(candidate_trajectories, n=3, dim=2)
            jerk_norm = torch.linalg.norm(jerk, dim=-1).mean(dim=-1)
            out[:, :, 2] = torch.sigmoid(jerk_norm - 1.0)
        else:
            out[:, :, 2] = 0.0
    return out.clamp(0.0, 1.0)


def train_one_epoch(
    model: nn.Module,
    dataloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    device: torch.device,
    classification_weight: float = 0.0,
    metric_score_weight: float = 0.0,
    collision_threshold_m: float = 2.0,
) -> float:
    model.train()
    total_loss = 0.0
    total_count = 0
    for batch in dataloader:
        batch_on_device = move_batch_to_device(batch, device)
        optimizer.zero_grad(set_to_none=True)
        outputs = forward_model(model, batch_on_device)
        loss = planner_loss(
            outputs,
            batch_on_device,
            loss_fn,
            classification_weight,
            metric_score_weight,
            collision_threshold_m,
        )
        loss.backward()
        optimizer.step()
        batch_size = int(batch_on_device["inputs"].shape[0])
        total_loss += float(loss.detach().cpu()) * batch_size
        total_count += batch_size
    return total_loss / max(total_count, 1)


@torch.no_grad()
def evaluate_loss(
    model: nn.Module,
    dataloader: DataLoader,
    loss_fn: nn.Module,
    device: torch.device,
    classification_weight: float = 0.0,
    metric_score_weight: float = 0.0,
    collision_threshold_m: float = 2.0,
) -> float:
    model.eval()
    total_loss = 0.0
    total_count = 0
    for batch in dataloader:
        batch_on_device = move_batch_to_device(batch, device)
        outputs = forward_model(model, batch_on_device)
        loss = planner_loss(
            outputs,
            batch_on_device,
            loss_fn,
            classification_weight,
            metric_score_weight,
            collision_threshold_m,
        )
        batch_size = int(batch_on_device["inputs"].shape[0])
        total_loss += float(loss.detach().cpu()) * batch_size
        total_count += batch_size
    return total_loss / max(total_count, 1)


@torch.no_grad()
def collect_window_metrics(
    model: nn.Module,
    dataloader: DataLoader,
    dataset: Any,
    device: torch.device,
    collision_threshold_m: float = 2.0,
) -> pd.DataFrame:
    model.eval()
    rows: list[dict[str, Any]] = []
    for batch in dataloader:
        batch_on_device = move_batch_to_device(batch, device)
        targets = batch["targets"].cpu().numpy()
        outputs = forward_model(model, batch_on_device)
        preds = outputs["trajectory"].detach().cpu().numpy()
        entropy_values = None
        if "trajectory_logits" in outputs:
            probs = torch.softmax(outputs["trajectory_logits"], dim=1)
            entropy = -(probs * torch.log(probs.clamp_min(1e-12))).sum(dim=1)
            entropy_values = entropy.detach().cpu().numpy()
        record_indices = batch["record_index"].cpu().numpy().tolist()
        clip_ids = list(batch["clip_id"])
        anchor_tokens = list(batch["anchor_sample_token"])
        for row_idx, record_index in enumerate(record_indices):
            record = dataset.records[int(record_index)]
            metrics = compute_sample_metrics(
                preds[row_idx],
                targets[row_idx],
                future_agent_centers=record.future_agent_centers,
                collision_threshold_m=collision_threshold_m,
            )
            metrics.update(
                {
                    "clip_id": clip_ids[row_idx],
                    "anchor_sample_token": anchor_tokens[row_idx],
                }
            )
            if entropy_values is not None:
                metrics["uncertainty_entropy"] = float(entropy_values[row_idx])
            rows.append(metrics)
    return pd.DataFrame(rows)


def evaluate_model_to_outputs(
    model: nn.Module,
    dataset: Any,
    dataloader: DataLoader,
    device: torch.device,
    utility_cfg: dict[str, Any],
    out_dir: str,
    collision_threshold_m: float = 2.0,
) -> tuple[dict[str, Any], pd.DataFrame]:
    window_metrics = collect_window_metrics(
        model,
        dataloader,
        dataset,
        device=device,
        collision_threshold_m=collision_threshold_m,
    )
    per_clip, aggregate = aggregate_window_metrics(window_metrics)
    utility, normalized = compute_utility_from_frame(per_clip, utility_cfg)
    metrics = {**aggregate, **normalized, "utility": utility}
    output_dir = ensure_dir(out_dir)
    write_csv(per_clip, output_dir / "per_clip_metrics.csv")
    write_csv(window_metrics, output_dir / "per_window_metrics.csv")
    write_json(sanitize_metrics_for_json(metrics), output_dir / "metrics.json")
    return metrics, per_clip
