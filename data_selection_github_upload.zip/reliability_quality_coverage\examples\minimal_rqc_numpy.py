"""Minimal Reliability-Quality Coverage example with precomputed arrays.

Run from the package root:

    python examples/minimal_rqc_numpy.py

For nuScenes, replace the random arrays below with clip-level multimodal
representations, Fisher-normalized task gradients, scenario/block labels,
reliability scores, and reject masks.
"""

from __future__ import annotations

from pathlib import Path
import sys

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT / "code"))

from reliability_quality_coverage import (  # noqa: E402
    build_equal_energy_joint_geometry,
    select_reliability_quality_coverage,
)


def main() -> None:
    rng = np.random.default_rng(7)
    num_samples = 500
    representation = rng.normal(size=(num_samples, 64))
    fisher_gradient = rng.normal(size=(num_samples, 32))

    # Unequal cluster sizes, similar to long-tail scenario blocks.
    cluster_labels = np.concatenate(
        [
            np.full(180, 0),
            np.full(120, 1),
            np.full(90, 2),
            np.full(60, 3),
            np.full(50, 4),
        ]
    )

    reliability = rng.beta(6.0, 2.0, size=num_samples)
    reject_mask = reliability < 0.18
    budget = int(0.20 * num_samples)

    geometry = build_equal_energy_joint_geometry(representation, fisher_gradient)
    selection = select_reliability_quality_coverage(
        geometry,
        cluster_labels,
        budget,
        reliability=reliability,
        reject_mask=reject_mask,
        tail_fraction=0.10,
    )

    print(f"selected={len(selection.ranking)}")
    print(f"first_10={selection.ranking[:10]}")
    print(f"mean_weight={np.mean(selection.weights):.4f}")
    print(f"cluster_counts={selection.diagnostics['cluster_counts']}")


if __name__ == "__main__":
    main()
