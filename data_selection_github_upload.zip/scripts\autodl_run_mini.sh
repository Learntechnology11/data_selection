#!/usr/bin/env bash
set -euo pipefail

DATAROOT="${1:-${NUSCENES_DATAROOT:-/root/autodl-tmp/nuscenes}}"
VERSION="${2:-${NUSCENES_VERSION:-v1.0-mini}}"
CONFIG="${CONFIG:-configs/mosaic_nuscenes_mini.yaml}"
CLEAN_OUTPUTS="${CLEAN_OUTPUTS:-0}"
SEEDS="${SEEDS:-0}"
PILOT_BUDGETS="${PILOT_BUDGETS:-5 10 20}"
BASE_EPOCHS="${BASE_EPOCHS:-100}"
PILOT_EPOCHS="${PILOT_EPOCHS:-40}"
FULL_EPOCHS="${FULL_EPOCHS:-80}"
NUM_CLUSTERS="${NUM_CLUSTERS:-4}"
METHODS="${METHODS:-random full mosaic}"
SELECTION_BUDGET_RATIOS="${SELECTION_BUDGET_RATIOS:-0.30 0.50}"

echo "[MOSAIC] dataroot=${DATAROOT}"
echo "[MOSAIC] version=${VERSION}"
echo "[MOSAIC] config=${CONFIG}"
echo "[MOSAIC] methods=${METHODS}"

if [[ "${CLEAN_OUTPUTS}" == "1" || "${CLEAN_OUTPUTS}" == "true" ]]; then
  python scripts/clean_outputs.py --yes
fi

python scripts/build_nuscenes_clips.py \
  --config "${CONFIG}" \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --out outputs/clips/nuscenes_mini_clips.csv

python scripts/create_splits.py \
  --clips outputs/clips/nuscenes_mini_clips.csv \
  --mode mini_random \
  --base-ratio 0.2 \
  --pool-ratio 0.6 \
  --seed 42 \
  --out-dir outputs/splits

python scripts/extract_clip_features.py \
  --config "${CONFIG}" \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --clips outputs/clips/nuscenes_mini_clips.csv \
  --out-dir outputs/features

python scripts/cluster_pool.py \
  --pool outputs/splits/pool.csv \
  --features outputs/features/clip_features.parquet \
  --method kmeans++ \
  --num-clusters "${NUM_CLUSTERS}" \
  --out-dir outputs/clusters

python scripts/cache_camera_features.py \
  --config "${CONFIG}" \
  --clips outputs/clips/nuscenes_mini_clips.csv \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --out outputs/features/camera_features_resnet18_mini.npz

python scripts/build_trajectory_vocab.py \
  --config "${CONFIG}" \
  --clips outputs/splits/base_train.csv \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --num-modes 64 \
  --out outputs/vocab/trajectory_vocab_mini_64.npy

python scripts/train_planner.py \
  --train outputs/splits/base_train.csv \
  --val outputs/splits/val.csv \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --config "${CONFIG}" \
  --exp-name base_train \
  --epochs "${BASE_EPOCHS}"

python scripts/rank_pool.py \
  --checkpoint outputs/checkpoints/base_train.pt \
  --pool outputs/splits/pool.csv \
  --clusters outputs/clusters/cluster_assignments.csv \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --config "${CONFIG}" \
  --out-dir outputs/ranking

python scripts/run_pilot_experiments.py \
  --base-train outputs/splits/base_train.csv \
  --val outputs/splits/val.csv \
  --ranked-pool outputs/ranking/cluster_ranked_pool.csv \
  --pilot-budgets ${PILOT_BUDGETS} \
  --mode finetune \
  --config "${CONFIG}" \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --base-checkpoint outputs/checkpoints/base_train.pt \
  --base-metrics outputs/eval/base_train/metrics.json \
  --seeds ${SEEDS} \
  --epochs "${PILOT_EPOCHS}" \
  --out outputs/pilot/pilot_results.csv

python scripts/fit_scaling_laws.py \
  --pilot-results outputs/pilot/pilot_results.csv \
  --out-dir outputs/scaling

SELECTION_BUDGETS="${SELECTION_BUDGETS:-}"
if [[ -n "${SELECTION_BUDGETS}" ]]; then
  BUDGET_ARGS=(--budgets ${SELECTION_BUDGETS})
  echo "[MOSAIC] selection budgets=${SELECTION_BUDGETS}"
else
  BUDGET_ARGS=(--budget-ratios ${SELECTION_BUDGET_RATIOS})
  echo "[MOSAIC] selection budget ratios=${SELECTION_BUDGET_RATIOS}"
fi

python scripts/run_selection_experiments.py \
  --config "${CONFIG}" \
  "${BUDGET_ARGS[@]}" \
  --methods ${METHODS} \
  --seeds ${SEEDS} \
  --dataroot "${DATAROOT}" \
  --version "${VERSION}" \
  --epochs "${FULL_EPOCHS}" \
  --out-dir outputs/results

python scripts/plot_results.py \
  --results outputs/results/main_results.csv \
  --metric-breakdown outputs/results/metric_breakdown.csv \
  --cluster-distribution outputs/results/cluster_distribution.csv \
  --out-dir outputs/analysis

echo "[MOSAIC] done. See outputs/results and outputs/analysis."
