# Rank-Based Reliability-Quality Coverage for nuScenes

本文档说明 `reliability_quality_coverage/code/nuscenes_rqc.py` 中当前的 nuScenes 版 RQC 算法。该版本将早期的手写线性风险权重、特征 outlier hard reject、`lambda_z/lambda_g` 和 clean mass floor 移除，改为更适合论文表述的 rank / quantile 形式。

核心原则是：

```text
只删坏数据，不删奇怪数据；
只调预算比例，不调一堆手工权重。
```

## 1. Clip 输入

nuScenes 中一个样本定义为一个 driving clip：

```text
x_i = fixed-length nuScenes driving clip
```

每个 clip 至少需要：

```text
clip_id
sample_tokens / num_samples
scene_token / log_token
clip-level numeric features
scenario cluster_id
optional cached camera features
optional planner metrics
```

推荐输入文件：

```text
outputs/splits/pool.csv
outputs/splits/base_train.csv
outputs/features/clip_features.parquet
outputs/clusters/cluster_assignments.csv
outputs/ranking/pool_importance_scores.csv
outputs/features/camera_features_resnet18_mini.npz    # optional
```

## 2. Reliability

Reliability 表示数据可信度，不等价于困难度。自动驾驶中的 rare scenario 本来可能就是 feature outlier，因此 feature outlier 不再用于 hard reject。

对每个 clip 计算五个风险信号：

```text
d_i^z : representation outlier score inside cluster
d_i^m : planner metric outlier score inside cluster
s_i   : sensor quality
v_i   : metric validity
h_i   : uncertainty risk
```

在每个 cluster 内做 percentile rank：

```math
\operatorname{rank}_c(a_i)
\in [0, 1]
```

然后定义：

```math
R_i =
\max \{
\operatorname{rank}_{c_i}(d_i^z),
\operatorname{rank}_{c_i}(d_i^m),
\operatorname{rank}_{c_i}(1-s_i),
\operatorname{rank}_{c_i}(1-v_i),
\operatorname{rank}_{c_i}(h_i)
\}
```

可靠性使用无权重指数衰减形式：

```math
\rho_i = \exp(-R_i)
```

实现中仅做数值保护：

```text
rho_i is clipped to [1e-6, 1.0] for non-rejected clips
```

由于 `R_i \in [0,1]`，非 reject 样本的可靠性范围约为：

```math
\rho_i \in [e^{-1}, 1] \approx [0.367, 1]
```

这比 `1-R_i` 更适合 mini 这种 cluster 很小的数据，因为最差 rank 的合法长尾样本不会被压到接近 0。

## 3. Hard Reject

Hard reject 只删除坏数据，不删除长尾或异常场景：

```math
\operatorname{Reject}(i)
=
\operatorname{InvalidMetric}(i)
\lor
\operatorname{SevereSensorMissing}(i)
\lor
\operatorname{BrokenTimestampOrLog}(i)
```

当前实现：

```text
InvalidMetric:
  ADE/FDE 非有限值，或 ADE/FDE/collision/offroad/jerk 等非负指标出现负数

SevereSensorMissing:
  clip 没有任何可用 numeric feature，或传入 camera cache 时该 clip 没有任何 camera feature 命中

BrokenTimestampOrLog:
  sample_tokens / num_samples 过短，或 scene/log/start/end token 为空
```

以下信号只影响 soft reliability，不 hard reject：

```text
feature_outlier_z
metric_outlier_z
uncertainty_risk
```

这保证了急刹、密集交通、奇异拓扑、罕见天气等长尾场景不会因为“像 outlier”而被直接删掉。

## 4. Quality

Quality 表示 planner 训练价值 / 困难度。当前版本不使用 ADE/FDE/collision/jerk 的绝对尺度，而是使用 rank-normalized planner difficulty。

对可用 planner metrics 分别做 cluster 内 percentile rank：

```math
a_i = \operatorname{rank}_{c_i}(ADE_i)
```

```math
f_i = \operatorname{rank}_{c_i}(FDE_i)
```

```math
b_i = \operatorname{rank}_{c_i}(collision_i)
```

```math
o_i = \operatorname{rank}_{c_i}(offroad_i)
```

```math
j_i = \operatorname{rank}_{c_i}(jerk_i)
```

先平均各 difficulty rank：

```math
\bar q_i =
\operatorname{mean}
\left[
a_i, f_i, b_i, o_i, j_i
\right]
```

再做一次 cluster 内 percentile rank：

```math
q_i = \operatorname{rank}_{c_i}(\bar q_i)
```

如果只提供了 `importance_score`，代码会把它作为 fallback 并做 rank；如果没有 planner metrics，则 `q_i=0`，RQC 退化为 reliability-weighted coverage。

## 5. Reliability-Quality Mass

最终覆盖质量为：

```math
m_i = \rho_i(1 + q_i)
```

已移除：

```text
beta / quality_strength
gamma / clean_mass_floor
```

因此 mass 的解释更直接：

```text
rho_i 高：数据可信；
q_i 高：planner 难、训练价值高；
m_i 高：更应该被覆盖或代表。
```

被 hard reject 的样本：

```math
m_i = 0
```

## 6. Equal-Energy Joint Geometry

RQC 同时覆盖 clip 表示空间和 planner residual / gradient proxy 空间。

先构造：

```text
z_i : clip representation
g_i : Fisher-normalized driving gradient proxy
```

PCA 维度不再写死。每个 block 自动保留解释 90% 方差的主成分，最多 32 维：

```math
d_z =
\min \{d: \operatorname{EVR}_z(d) \ge 0.90\},\quad d_z \le 32
```

```math
d_g =
\min \{d: \operatorname{EVR}_g(d) \ge 0.90\},\quad d_g \le 32
```

做 equal-energy normalization：

```math
\tilde z_i =
\frac{\operatorname{PCA}_{90\%,32}(z_i)}
{\sqrt{d_z}}
```

```math
\tilde g_i =
\frac{\operatorname{PCA}_{90\%,32}(g_i)}
{\sqrt{d_g}}
```

最终几何：

```math
u_i =
\frac{[\tilde z_i,\tilde g_i]}
{\|[\tilde z_i,\tilde g_i]\|_2}
```

已移除：

```text
lambda_z
lambda_g
representation_dim
gradient_dim
```

## 7. Coverage Objective

对每个 scenario cluster `c`，令：

```text
D_c = {i | c_i = c}
S_c = selected clips in cluster c
```

clip 到已选集合的覆盖距离：

```math
d_i(S_c) =
\min_{j \in S_c}
\|u_i-u_j\|_2^2
```

RQC 目标为：

```math
L_c(S_c)
=
(1-\eta)
\mathbb{E}_{i \sim m_c}
[d_i(S_c)]
+
\eta
\operatorname{CVaR}_{\kappa}
[d_i(S_c)]
```

当前固定：

```text
eta = 0.5
kappa = 0.1
```

解释：

```text
平均覆盖和尾部覆盖等权；
尾部定义为 mass-weighted 最差 10% 样本；
不把 eta/kappa 当作实验调参变量。
```

## 8. Dynamic Cluster Allocation

每个 cluster 内先生成一个局部 greedy ranking，再根据全局边际收益动态合并：

```math
\Delta_{c,t}
=
L_c(S_{c,t-1}) - L_c(S_{c,t})
```

全局调度：

```math
c^*
=
\arg\max_c
w_c \Delta_{c,t_c+1}
```

其中：

```math
w_c =
\frac{\sum_{i \in D_c} m_i}
{\sum_i m_i}
```

## 9. Representative Training Weights

选中 clip `j` 的训练权重来自同 cluster 内 Voronoi 代表质量：

```math
a_j =
\sum_{i:
j =
\arg\min_{k \in S_{c_i}}
\|u_i-u_k\|_2^2}
m_i
```

再归一化到均值 1，并截断：

```math
w_j =
\operatorname{clip}
\left(
\frac{a_j}{\operatorname{mean}(a)},
0.25,
4.0
\right)
```

输出字段：

```text
rqc_weight
```

## 10. mini / full nuScenes 命令

mini 版本：

```bash
python reliability_quality_coverage/code/nuscenes_rqc.py \
  --pool outputs/splits/pool.csv \
  --features outputs/features/clip_features.parquet \
  --clusters outputs/clusters/cluster_assignments.csv \
  --planner-metrics outputs/ranking/pool_importance_scores.csv \
  --camera-features outputs/features/camera_features_resnet18_mini.npz \
  --base-train outputs/splits/base_train.csv \
  --budget-ratios 0.30 0.50 \
  --out-dir outputs/rqc
```

如果暂时没有 camera cache，可以去掉：

```bash
--camera-features outputs/features/camera_features_resnet18_mini.npz
```

full / trainval 版本只需要替换输入路径：

```bash
python reliability_quality_coverage/code/nuscenes_rqc.py \
  --pool outputs/splits/pool.csv \
  --features outputs/features/clip_features.parquet \
  --clusters outputs/clusters/cluster_assignments.csv \
  --planner-metrics outputs/ranking/pool_importance_scores.csv \
  --camera-features outputs/features/camera_features_resnet18_trainval.npz \
  --base-train outputs/splits/base_train.csv \
  --budget-ratios 0.30 0.50 \
  --out-dir outputs/rqc_trainval
```

预算是比例，因此 `0.30` 和 `0.50` 会自动根据 pool 大小转换为 clip 数量，mini 和 full 可以共用同一套命令结构。

## 11. 输出文件

```text
outputs/rqc/rqc_signals.csv
outputs/rqc/rqc_ranking_max_budget_{B}.csv
outputs/rqc/rqc_trajectory_max_budget_{B}.csv
outputs/rqc/selected_rqc_nuscenes_p30.csv
outputs/rqc/selected_rqc_nuscenes_p50.csv
outputs/rqc/train_manifest_rqc_nuscenes_p30.csv
outputs/rqc/train_manifest_rqc_nuscenes_p50.csv
outputs/rqc/rqc_diagnostics.json
outputs/rqc/rqc_geometry.npz
```

`rqc_signals.csv` 包含：

```text
rqc_reliability
rqc_quality
rqc_mass
rqc_reject
rqc_rank_feature_outlier
rqc_rank_metric_outlier
rqc_rank_sensor_missing
rqc_rank_metric_invalid
rqc_rank_uncertainty
rqc_reliability_rank_max
rqc_reject_invalid_metrics
rqc_reject_severe_sensor_missing
rqc_reject_broken_timestamp_log
```

这些字段可以直接用于论文中的 reliability 分布、reject reason、quality 分布、coverage 诊断图。

## 12. 论文表述建议

可以这样描述当前 RQC：

> We propose a rank-based Reliability-Quality Coverage selector for autonomous driving data. Reliability is computed as an exponential decay of the maximum cluster-wise percentile rank over representation outlierness, metric outlierness, sensor missingness, metric invalidity, and uncertainty. Hard rejection is reserved for invalid metrics, severe sensor missingness, and broken timestamp/log metadata, so rare but valid scenarios are preserved. Planner quality is computed from rank-normalized ADE, FDE, collision, offroad, and jerk difficulty. The final mass is rho_i(1+q_i). Coverage is optimized in an equal-energy representation-gradient geometry with fixed equal weighting between average and worst-10% tail coverage.
