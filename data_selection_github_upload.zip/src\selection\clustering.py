from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from src.utils.io import ensure_dir, read_csv, read_json, require_columns, write_csv


TEXT_COLUMNS = {"clip_id", "location", "description"}
STOP_WORDS = {
    "the",
    "and",
    "with",
    "from",
    "into",
    "near",
    "this",
    "that",
    "road",
    "street",
    "scene",
}


@dataclass(frozen=True)
class ClusteringConfig:
    method: str = "kmeans++"
    num_clusters: int = 4
    random_state: int = 42
    kmeans_init: str = "k-means++"


def _sibling(path: Path, filename: str) -> Path:
    return path.parent / filename


def load_feature_frame(
    features_path: str | Path,
    pool: pd.DataFrame,
    feature_columns_path: str | Path | None = None,
    feature_ids_path: str | Path | None = None,
) -> pd.DataFrame:
    path = Path(features_path)
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path)
    if suffix == ".npy":
        columns_path = Path(feature_columns_path) if feature_columns_path else _sibling(
            path, "clip_feature_columns.json"
        )
        ids_path = Path(feature_ids_path) if feature_ids_path else _sibling(
            path, "clip_feature_ids.json"
        )
        if not columns_path.exists():
            raise FileNotFoundError(
                f"Feature column file is required for .npy input: {columns_path}"
            )
        matrix = np.load(path)
        columns = read_json(columns_path)
        if matrix.shape[1] != len(columns):
            raise ValueError(
                f"Feature matrix width {matrix.shape[1]} does not match {len(columns)} columns"
            )
        if ids_path.exists():
            clip_ids = read_json(ids_path)
        elif matrix.shape[0] == len(pool):
            clip_ids = pool["clip_id"].astype(str).tolist()
        else:
            raise FileNotFoundError(
                f"Feature id file is required for .npy input when row count differs: {ids_path}"
            )
        if len(clip_ids) != matrix.shape[0]:
            raise ValueError("Feature id count does not match .npy row count")
        frame = pd.DataFrame(matrix, columns=columns)
        frame.insert(0, "clip_id", clip_ids)
        return frame
    raise ValueError(f"Unsupported feature format: {features_path}")


def _merge_pool_features(pool: pd.DataFrame, features: pd.DataFrame) -> pd.DataFrame:
    require_columns(pool, ["clip_id", "location", "description"], "pool")
    require_columns(features, ["clip_id"], "features")
    merged = pool.merge(
        features,
        on="clip_id",
        how="left",
        suffixes=("", "_feature"),
        indicator=True,
    )
    missing = merged.loc[merged["_merge"] != "both", "clip_id"].astype(str).tolist()
    if missing:
        raise ValueError(f"Missing features for pool clips: {missing[:5]}")
    merged = merged.drop(columns=["_merge"])
    numeric_cols = [
        column
        for column in features.columns
        if column not in TEXT_COLUMNS and pd.api.types.is_numeric_dtype(features[column])
    ]
    if numeric_cols and merged[numeric_cols].isna().all(axis=1).any():
        bad = merged.loc[merged[numeric_cols].isna().all(axis=1), "clip_id"].tolist()
        raise ValueError(f"Missing features for pool clips: {bad[:5]}")
    if "location_feature" in merged.columns:
        merged["location"] = merged["location"].fillna(merged["location_feature"])
    if "description_feature" in merged.columns:
        merged["description"] = merged["description"].fillna(merged["description_feature"])
    drop_cols = [column for column in merged.columns if column.endswith("_feature")]
    return merged.drop(columns=drop_cols)


def numeric_feature_columns(frame: pd.DataFrame) -> list[str]:
    return [
        column
        for column in frame.columns
        if column not in TEXT_COLUMNS and pd.api.types.is_numeric_dtype(frame[column])
    ]


def assign_location_clusters(pool_features: pd.DataFrame) -> pd.DataFrame:
    locations = sorted(pool_features["location"].fillna("unknown").astype(str).unique())
    mapping = {location: idx for idx, location in enumerate(locations)}
    assignments = pd.DataFrame(
        {
            "clip_id": pool_features["clip_id"].astype(str),
            "cluster_id": pool_features["location"].fillna("unknown").astype(str).map(mapping),
            "cluster_method": "location",
        }
    )
    return assignments


def assign_kmeans_clusters(pool_features: pd.DataFrame, config: ClusteringConfig) -> pd.DataFrame:
    columns = numeric_feature_columns(pool_features)
    if not columns:
        raise ValueError("KMeans clustering needs at least one numeric feature column")
    if config.num_clusters < 1:
        raise ValueError("num_clusters must be positive")

    matrix = pool_features[columns].copy()
    for column in columns:
        median = matrix[column].median(skipna=True)
        matrix[column] = matrix[column].fillna(0.0 if pd.isna(median) else median)

    from sklearn.cluster import KMeans, MiniBatchKMeans
    from sklearn.preprocessing import StandardScaler

    scaled = StandardScaler().fit_transform(matrix.to_numpy(dtype=np.float64))
    n_clusters = min(config.num_clusters, len(pool_features))
    estimator_cls = MiniBatchKMeans if len(pool_features) > 10000 else KMeans
    estimator_kwargs = {
        "n_clusters": n_clusters,
        "init": config.kmeans_init,
        "random_state": config.random_state,
        "n_init": 10,
    }
    if estimator_cls is MiniBatchKMeans:
        estimator_kwargs["batch_size"] = 2048
    labels = estimator_cls(**estimator_kwargs).fit_predict(scaled)
    return pd.DataFrame(
        {
            "clip_id": pool_features["clip_id"].astype(str),
            "cluster_id": labels.astype(int),
            "cluster_method": "kmeans++" if config.kmeans_init == "k-means++" else "kmeans",
        }
    )


def _top_locations(frame: pd.DataFrame) -> str:
    counts = frame["location"].fillna("unknown").astype(str).value_counts().head(3)
    return ";".join(f"{location}:{count}" for location, count in counts.items())


def _top_keywords(frame: pd.DataFrame) -> str:
    counter: Counter[str] = Counter()
    for description in frame["description"].fillna("").astype(str):
        words = re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}", description.lower())
        counter.update(word for word in words if word not in STOP_WORDS)
    return ";".join(f"{word}:{count}" for word, count in counter.most_common(5))


def summarize_clusters(pool_features: pd.DataFrame, assignments: pd.DataFrame) -> pd.DataFrame:
    merged = pool_features.merge(assignments[["clip_id", "cluster_id"]], on="clip_id", how="inner")
    rows: list[dict[str, object]] = []
    for cluster_id, frame in merged.groupby("cluster_id", sort=True):
        row: dict[str, object] = {
            "cluster_id": int(cluster_id),
            "num_clips": int(len(frame)),
            "top_locations": _top_locations(frame),
            "top_description_keywords": _top_keywords(frame),
        }
        for column in ["mean_speed", "mean_num_agents"]:
            row[column] = float(frame[column].mean()) if column in frame.columns else np.nan
        rows.append(row)
    return pd.DataFrame(rows)


def validate_assignments(pool: pd.DataFrame, assignments: pd.DataFrame) -> None:
    require_columns(assignments, ["clip_id", "cluster_id", "cluster_method"], "assignments")
    pool_ids = set(pool["clip_id"].astype(str))
    assigned_ids = set(assignments["clip_id"].astype(str))
    missing = pool_ids - assigned_ids
    extra = assigned_ids - pool_ids
    if missing:
        raise ValueError(f"Cluster assignments missing pool clips: {list(missing)[:5]}")
    if extra:
        raise ValueError(f"Cluster assignments contain non-pool clips: {list(extra)[:5]}")
    cluster_ids = sorted(assignments["cluster_id"].astype(int).unique().tolist())
    if cluster_ids != list(range(len(cluster_ids))):
        raise ValueError(f"cluster_id values must be continuous from 0, got {cluster_ids}")


def cluster_pool(
    pool: pd.DataFrame,
    features: pd.DataFrame,
    config: ClusteringConfig,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if pool.empty:
        raise ValueError("pool.csv is empty")
    pool_features = _merge_pool_features(pool, features)
    method = config.method.lower().replace("_", "-")
    if method == "location":
        assignments = assign_location_clusters(pool_features)
    elif method in {"kmeans", "kmeans++", "k-means++"}:
        assignments = assign_kmeans_clusters(pool_features, config)
    else:
        raise ValueError(f"Unsupported clustering method: {config.method}")
    validate_assignments(pool, assignments)
    summary = summarize_clusters(pool_features, assignments)
    return assignments, summary


def cluster_and_save_pool(
    pool_path: str | Path,
    features_path: str | Path,
    out_dir: str | Path,
    config: ClusteringConfig,
    feature_columns_path: str | Path | None = None,
    feature_ids_path: str | Path | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    pool = read_csv(pool_path)
    features = load_feature_frame(features_path, pool, feature_columns_path, feature_ids_path)
    assignments, summary = cluster_pool(pool, features, config)
    output_dir = ensure_dir(out_dir)
    write_csv(assignments, output_dir / "cluster_assignments.csv")
    write_csv(summary, output_dir / "cluster_summary.csv")
    return assignments, summary
