from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.nuscenes_clips import ClipBuildConfig, build_and_save_clips
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def default_clip_path(version: str) -> Path:
    suffix = version.replace("v1.0-", "").replace(".", "_")
    return Path("outputs") / "clips" / f"nuscenes_{suffix}_clips.csv"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build non-overlapping 10 second nuScenes virtual clip manifests."
    )
    parser.add_argument("--config", type=str, default=None, help="Optional YAML config path.")
    parser.add_argument("--dataroot", type=str, default=None, help="nuScenes dataroot.")
    parser.add_argument("--version", type=str, default=None, help="nuScenes version.")
    parser.add_argument("--out", type=str, default=None, help="Output clips CSV path.")
    parser.add_argument("--clip-duration-sec", type=float, default=None)
    parser.add_argument("--min-num-samples-per-clip", type=int, default=None)
    parser.add_argument("--quiet", action="store_true", help="Disable verbose NuScenes loading.")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    dataset_cfg = cfg.get("dataset", {})

    dataroot = args.dataroot or dataset_cfg.get("dataroot")
    version = args.version or dataset_cfg.get("version")
    if not dataroot or not version:
        raise SystemExit("--dataroot and --version are required unless provided by --config")

    clip_duration_sec = (
        args.clip_duration_sec
        if args.clip_duration_sec is not None
        else float(dataset_cfg.get("clip_duration_sec", 10.0))
    )
    min_samples = (
        args.min_num_samples_per_clip
        if args.min_num_samples_per_clip is not None
        else int(dataset_cfg.get("min_num_samples_per_clip", 4))
    )
    out_path = Path(args.out) if args.out else default_clip_path(version)

    build_config = ClipBuildConfig(
        dataroot=dataroot,
        version=version,
        clip_duration_sec=clip_duration_sec,
        min_num_samples_per_clip=min_samples,
        verbose=not args.quiet,
    )
    clips = build_and_save_clips(build_config, out_path)
    logger.info("Wrote %d clips to %s", len(clips), out_path)
    logger.info("Clip locations: %s", clips["location"].value_counts().to_dict())


if __name__ == "__main__":
    main()
