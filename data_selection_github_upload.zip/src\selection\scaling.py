from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.utils.io import ensure_dir, write_json


def scaling_fn(n: np.ndarray, a: float, tau: float) -> np.ndarray:
    return a * (1.0 - np.exp(-n / tau))


def fit_cluster_scaling(frame: pd.DataFrame) -> dict[str, Any]:
    ns = pd.to_numeric(frame["n"], errors="coerce").to_numpy(dtype=np.float64)
    deltas = pd.to_numeric(frame["delta_utility"], errors="coerce").to_numpy(dtype=np.float64)
    valid = np.isfinite(ns) & np.isfinite(deltas)
    ns = ns[valid]
    deltas = deltas[valid]
    if len(ns) == 0:
        return {
            "a": 1e-6,
            "tau": 1.0,
            "fit_success": False,
            "fallback_reason": "no_valid_points",
            "observed_ns": [],
            "observed_delta_utility": [],
        }

    fallback_a = max(float(np.nanmax(deltas)), 1e-6)
    fallback_tau = max(float(np.nanmedian(ns)), 1.0)
    try:
        from scipy.optimize import curve_fit

        params, _ = curve_fit(
            scaling_fn,
            ns,
            np.maximum(deltas, 0.0),
            p0=[fallback_a, fallback_tau],
            bounds=([0.0, 1e-6], [np.inf, np.inf]),
            maxfev=10000,
        )
        a, tau = float(params[0]), float(params[1])
        fit_success = bool(np.isfinite(a) and np.isfinite(tau) and tau > 0)
        if not fit_success:
            raise RuntimeError("non_finite_fit")
        return {
            "a": max(a, 1e-6),
            "tau": max(tau, 1e-6),
            "fit_success": True,
            "observed_ns": ns.astype(float).tolist(),
            "observed_delta_utility": deltas.astype(float).tolist(),
        }
    except Exception as exc:
        return {
            "a": fallback_a,
            "tau": fallback_tau,
            "fit_success": False,
            "fallback_reason": str(exc),
            "observed_ns": ns.astype(float).tolist(),
            "observed_delta_utility": deltas.astype(float).tolist(),
        }


def fit_scaling_laws(pilot_results: pd.DataFrame) -> dict[str, dict[str, Any]]:
    required = {"cluster_id", "n", "delta_utility"}
    missing = required - set(pilot_results.columns)
    if missing:
        raise ValueError(f"pilot_results missing columns: {sorted(missing)}")
    params: dict[str, dict[str, Any]] = {}
    for cluster_id, frame in pilot_results.groupby("cluster_id", sort=True):
        params[str(cluster_id)] = fit_cluster_scaling(frame)
    return params


def marginal_gain(a: float, tau: float, current: int, step: int = 1) -> float:
    before = scaling_fn(np.asarray([current], dtype=np.float64), a, tau)[0]
    after = scaling_fn(np.asarray([current + step], dtype=np.float64), a, tau)[0]
    return float(after - before)


def save_scaling_outputs(
    scaling_params: dict[str, dict[str, Any]],
    out_dir: str | Path,
    pilot_results: pd.DataFrame | None = None,
) -> None:
    output_dir = ensure_dir(out_dir)
    write_json(scaling_params, output_dir / "scaling_params.json")
    if pilot_results is not None:
        try:
            import matplotlib.pyplot as plt

            for cluster_id, frame in pilot_results.groupby("cluster_id", sort=True):
                params = scaling_params[str(cluster_id)]
                ns = pd.to_numeric(frame["n"], errors="coerce").to_numpy(dtype=float)
                deltas = pd.to_numeric(frame["delta_utility"], errors="coerce").to_numpy(dtype=float)
                if len(ns) == 0:
                    continue
                xs = np.linspace(0, max(ns.max(), 1.0), 100)
                ys = scaling_fn(xs, params["a"], params["tau"])
                plt.figure()
                plt.scatter(ns, deltas, label="observed")
                plt.plot(xs, ys, label="fit")
                plt.xlabel("n")
                plt.ylabel("delta_utility")
                plt.legend()
                plt.tight_layout()
                plt.savefig(output_dir / f"scaling_fit_plot_cluster_{cluster_id}.png")
                plt.close()
        except Exception:
            pass
