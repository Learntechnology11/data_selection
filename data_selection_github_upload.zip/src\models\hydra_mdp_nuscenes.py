from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch
from torch import nn


@dataclass(frozen=True)
class HydraMDPNuScenesConfig:
    ego_input_dim: int
    camera_feature_dim: int
    agent_token_dim: int
    future_steps: int
    hidden_dim: int = 256
    fusion_dim: int = 256
    num_layers: int = 2
    num_attention_heads: int = 4
    decoder_layers: int = 2
    dropout: float = 0.1
    num_cameras: int = 6
    trajectory_vocab: torch.Tensor | None = None
    num_modes: int = 0
    metric_head_dim: int = 3
    metric_score_weights: Sequence[float] = (0.50, 0.30, 0.20)


def mlp_block(input_dim: int, hidden_dim: int, num_layers: int, dropout: float) -> nn.Sequential:
    layers: list[nn.Module] = []
    in_dim = int(input_dim)
    for _ in range(max(1, int(num_layers))):
        layers.append(nn.Linear(in_dim, hidden_dim))
        layers.append(nn.LayerNorm(hidden_dim))
        layers.append(nn.GELU())
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        in_dim = hidden_dim
    return nn.Sequential(*layers)


class HydraMDPNuScenes(nn.Module):
    """Hydra-MDP-inspired nuScenes planner with environment tokens.

    This model is still much smaller than the original Hydra-MDP, but it keeps
    the important mechanisms that the previous lite MLP did not have:

    * ego, camera, and agent tokens;
    * transformer environment fusion;
    * trajectory-vocabulary queries decoded against the environment memory;
    * per-mode trajectory residuals, imitation logits, and rule-metric scores.
    """

    def __init__(self, config: HydraMDPNuScenesConfig) -> None:
        super().__init__()
        if config.camera_feature_dim <= 0:
            raise ValueError("HydraMDPNuScenes requires cached camera features")
        self.future_steps = int(config.future_steps)
        self.hidden_dim = int(config.hidden_dim)
        self.metric_head_dim = int(config.metric_head_dim)

        if config.camera_feature_dim % max(int(config.num_cameras), 1) == 0:
            self.num_camera_tokens = max(int(config.num_cameras), 1)
            camera_token_dim = int(config.camera_feature_dim // self.num_camera_tokens)
        else:
            self.num_camera_tokens = 1
            camera_token_dim = int(config.camera_feature_dim)

        self.ego_encoder = mlp_block(
            config.ego_input_dim, config.hidden_dim, config.num_layers, config.dropout
        )
        self.camera_encoder = mlp_block(
            camera_token_dim, config.hidden_dim, config.num_layers, config.dropout
        )
        self.agent_encoder = mlp_block(
            config.agent_token_dim, config.hidden_dim, 1, config.dropout
        )
        self.type_embedding = nn.Embedding(3, config.hidden_dim)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.hidden_dim,
            nhead=config.num_attention_heads,
            dim_feedforward=config.hidden_dim * 4,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.environment_encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=max(1, int(config.num_layers)),
        )

        vocab = config.trajectory_vocab
        if vocab is not None:
            vocab = vocab.detach().float().view(vocab.shape[0], self.future_steps, 2)
            num_modes = int(vocab.shape[0])
        else:
            num_modes = max(1, int(config.num_modes))
            vocab = torch.zeros(num_modes, self.future_steps, 2, dtype=torch.float32)
        self.num_modes = num_modes
        self.register_buffer("trajectory_vocab", vocab)

        self.vocab_query_encoder = mlp_block(
            self.future_steps * 2,
            config.hidden_dim,
            1,
            config.dropout,
        )
        self.mode_embedding = nn.Parameter(torch.zeros(num_modes, config.hidden_dim))
        nn.init.normal_(self.mode_embedding, std=0.02)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=config.hidden_dim,
            nhead=config.num_attention_heads,
            dim_feedforward=config.hidden_dim * 4,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.trajectory_decoder = nn.TransformerDecoder(
            decoder_layer,
            num_layers=max(1, int(config.decoder_layers)),
        )
        self.decoder_norm = nn.LayerNorm(config.hidden_dim)
        self.regression_head = nn.Linear(config.hidden_dim, self.future_steps * 2)
        self.logits_head = nn.Linear(config.hidden_dim, 1)
        self.metric_head = nn.Linear(config.hidden_dim, self.metric_head_dim)

        weights = torch.as_tensor(list(config.metric_score_weights), dtype=torch.float32)
        if weights.numel() < self.metric_head_dim:
            weights = torch.cat([weights, torch.zeros(self.metric_head_dim - weights.numel())])
        self.register_buffer("metric_score_weights", weights[: self.metric_head_dim])

    def _camera_tokens(self, camera_features: torch.Tensor) -> torch.Tensor:
        if camera_features.ndim > 2:
            camera_features = camera_features.flatten(start_dim=1)
        if self.num_camera_tokens > 1:
            camera_features = camera_features.view(camera_features.shape[0], self.num_camera_tokens, -1)
        else:
            camera_features = camera_features[:, None, :]
        return self.camera_encoder(camera_features)

    def _environment_tokens(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        ego = batch["inputs"] if "inputs" in batch else batch["ego"]
        if ego.ndim > 2:
            ego = ego.flatten(start_dim=1)
        ego_token = self.ego_encoder(ego)[:, None, :]
        camera_tokens = self._camera_tokens(batch["camera_features"])
        agent_tokens = self.agent_encoder(batch["agent_tokens"])

        ego_token = ego_token + self.type_embedding.weight[0].view(1, 1, -1)
        camera_tokens = camera_tokens + self.type_embedding.weight[1].view(1, 1, -1)
        agent_tokens = agent_tokens + self.type_embedding.weight[2].view(1, 1, -1)
        return torch.cat([ego_token, camera_tokens, agent_tokens], dim=1)

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        memory = self.environment_encoder(self._environment_tokens(batch))

        vocab_flat = self.trajectory_vocab.reshape(self.num_modes, -1)
        query = self.vocab_query_encoder(vocab_flat) + self.mode_embedding
        query = query.unsqueeze(0).expand(memory.shape[0], -1, -1)

        decoded = self.decoder_norm(self.trajectory_decoder(query, memory))
        residual = self.regression_head(decoded).view(
            memory.shape[0], self.num_modes, self.future_steps, 2
        )
        candidates = self.trajectory_vocab.unsqueeze(0) + residual
        imitation_logits = self.logits_head(decoded).squeeze(-1)
        metric_scores = torch.sigmoid(self.metric_head(decoded))
        selection_logits = imitation_logits - torch.sum(
            metric_scores * self.metric_score_weights.view(1, 1, -1),
            dim=-1,
        )
        weights = torch.softmax(selection_logits, dim=1)
        trajectory = torch.einsum("bm,bmtc->btc", weights, candidates)
        features = torch.einsum("bm,bmh->bh", weights, decoded)
        return {
            "features": features,
            "trajectory": trajectory,
            "candidate_trajectories": candidates,
            "trajectory_logits": imitation_logits,
            "selection_logits": selection_logits,
            "metric_scores": metric_scores,
        }
