from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.selection.baselines import (
    save_baseline_selection,
    select_cluster_only,
    select_coreset,
    select_full,
    select_random,
    select_ranking_only,
    select_uncertainty,
)
from src.utils.io import read_csv
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Select baseline clip subsets.")
    parser.add_argument(
        "--method",
        choices=["random", "full", "coreset", "ranking_only", "cluster_only", "uncertainty"],
        required=True,
    )
    parser.add_argument("--pool", required=True)
    parser.add_argument("--budget", type=int, default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--features", default=None)
    parser.add_argument("--ranked-pool", default=None)
    parser.add_argument("--clusters", default=None)
    parser.add_argument("--out-dir", default="outputs/selections")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    pool = read_csv(args.pool)
    if args.method == "random":
        if args.budget is None:
            raise SystemExit("--budget is required for random")
        selection = select_random(pool, args.budget, args.seed)
    elif args.method == "full":
        selection = select_full(pool, args.seed)
    elif args.method == "coreset":
        if args.budget is None:
            raise SystemExit("--budget is required for coreset")
        if not args.features:
            raise SystemExit("--features is required for coreset")
        feature_path = Path(args.features)
        if feature_path.suffix.lower() == ".parquet":
            feature_frame = pd.read_parquet(feature_path)
        else:
            feature_frame = read_csv(feature_path)
        selection = select_coreset(pool, feature_frame, args.budget, args.seed)
    else:
        if args.budget is None:
            raise SystemExit(f"--budget is required for {args.method}")
        if not args.ranked_pool:
            raise SystemExit("--ranked-pool is required for this baseline")
        ranked_pool = read_csv(args.ranked_pool)
        if args.method == "ranking_only":
            selection = select_ranking_only(ranked_pool, args.budget, args.seed)
        elif args.method == "cluster_only":
            selection = select_cluster_only(ranked_pool, args.budget, args.seed)
        elif args.method == "uncertainty":
            selection = select_uncertainty(ranked_pool, args.budget, args.seed)
        else:
            raise ValueError(args.method)
    path = save_baseline_selection(selection, args.method, len(selection), args.seed, args.out_dir)
    logger.info("Wrote %s selection: %s", args.method, path)


if __name__ == "__main__":
    main()
