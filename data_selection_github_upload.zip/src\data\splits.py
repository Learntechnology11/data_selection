from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from src.utils.io import ensure_dir, read_csv, require_columns, write_csv


SPLIT_REQUIRED_COLUMNS = [
    "clip_id",
    "scene_token",
    "location",
    "description",
    "sample_tokens",
]


@dataclass(frozen=True)
class SplitConfig:
    mode: str = "auto"
    base_ratio: float = 0.2
    pool_ratio: float = 0.6
    base_ratio_within_train: float = 0.1
    seed: int = 42


def _shuffle(df: pd.DataFrame, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(df))
    return df.iloc[order].reset_index(drop=True)


def _with_subset(df: pd.DataFrame, subset: str) -> pd.DataFrame:
    out = df.copy()
    out["split_subset"] = subset
    return out


def split_mini_random(clips: pd.DataFrame, config: SplitConfig) -> dict[str, pd.DataFrame]:
    if config.base_ratio < 0 or config.pool_ratio < 0:
        raise ValueError("base_ratio and pool_ratio must be non-negative")
    if config.base_ratio + config.pool_ratio > 1.0:
        raise ValueError("base_ratio + pool_ratio cannot exceed 1")

    shuffled = _shuffle(clips, config.seed)
    total = len(shuffled)
    base_count = int(round(total * config.base_ratio))
    pool_count = int(round(total * config.pool_ratio))
    if total >= 3:
        base_count = max(1, base_count)
        val_count = max(1, total - base_count - pool_count)
        pool_count = total - base_count - val_count
    if pool_count < 0:
        pool_count = 0

    base = shuffled.iloc[:base_count].reset_index(drop=True)
    pool = shuffled.iloc[base_count : base_count + pool_count].reset_index(drop=True)
    val = shuffled.iloc[base_count + pool_count :].reset_index(drop=True)
    return {
        "base_train": _with_subset(base, "base_train"),
        "pool": _with_subset(pool, "pool"),
        "val": _with_subset(val, "val"),
    }


def split_official_trainval(clips: pd.DataFrame, config: SplitConfig) -> dict[str, pd.DataFrame]:
    require_columns(clips, ["split"], "clips")
    split_values = clips["split"].fillna("").astype(str).str.lower()
    train_mask = split_values.isin(["train", "mini_train"])
    val_mask = split_values.isin(["val", "mini_val"])
    train = clips.loc[train_mask].reset_index(drop=True)
    val = clips.loc[val_mask].reset_index(drop=True)
    if train.empty or val.empty:
        raise ValueError(
            "official_trainval mode needs clip rows with split in train/val or mini_train/mini_val"
        )

    train = _shuffle(train, config.seed)
    base_count = int(round(len(train) * config.base_ratio_within_train))
    if len(train) >= 2:
        base_count = min(max(1, base_count), len(train) - 1)
    base = train.iloc[:base_count].reset_index(drop=True)
    pool = train.iloc[base_count:].reset_index(drop=True)
    return {
        "base_train": _with_subset(base, "base_train"),
        "pool": _with_subset(pool, "pool"),
        "val": _with_subset(val, "val"),
    }


def validate_splits(splits: dict[str, pd.DataFrame], expected_total: int | None = None) -> None:
    ids_by_name = {
        name: set(frame["clip_id"].astype(str).tolist()) for name, frame in splits.items()
    }
    names = list(ids_by_name)
    for i, left in enumerate(names):
        for right in names[i + 1 :]:
            overlap = ids_by_name[left] & ids_by_name[right]
            if overlap:
                raise ValueError(
                    f"{left} and {right} have overlapping clip_id values: {list(overlap)[:5]}"
                )
    total = sum(len(frame) for frame in splits.values())
    if expected_total is not None and total != expected_total:
        raise ValueError(f"Split total {total} does not match clips total {expected_total}")


def create_splits(clips: pd.DataFrame, config: SplitConfig) -> dict[str, pd.DataFrame]:
    require_columns(clips, SPLIT_REQUIRED_COLUMNS, "clips")
    if clips["clip_id"].duplicated().any():
        raise ValueError("clips.csv contains duplicate clip_id values")

    mode = config.mode
    if mode == "auto":
        split_values = (
            set(clips["split"].dropna().astype(str).str.lower().tolist())
            if "split" in clips.columns
            else set()
        )
        official_values = {"train", "val", "mini_train", "mini_val"}
        mode = "official_trainval" if split_values & official_values else "mini_random"

    if mode == "mini_random":
        splits = split_mini_random(clips, config)
        validate_splits(splits, expected_total=len(clips))
        return splits
    if mode == "official_trainval":
        splits = split_official_trainval(clips, config)
        validate_splits(splits)
        return splits
    raise ValueError(f"Unsupported split mode: {config.mode}")


def create_and_save_splits(
    clips_path: str | Path,
    out_dir: str | Path,
    config: SplitConfig,
) -> dict[str, pd.DataFrame]:
    clips = read_csv(clips_path)
    splits = create_splits(clips, config)
    output_dir = ensure_dir(out_dir)
    write_csv(splits["base_train"], output_dir / "base_train.csv")
    write_csv(splits["pool"], output_dir / "pool.csv")
    write_csv(splits["val"], output_dir / "val.csv")
    return splits
