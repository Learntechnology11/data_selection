# MOSAIC 算法规格说明

## 1. 变量定义

| 符号 | 含义 |
|---|---|
| `D_train` | 初始训练集，也叫 `D_train_base` |
| `D_pool` | 待选择数据池 |
| `D_val` | 验证集 |
| `D_sel` | 被选择的数据子集 |
| `B` | 总选择预算 |
| `M` | cluster/domain 数量 |
| `D_pool^i` | 第 `i` 个 cluster 中的 pool samples |
| `n_i` | 从第 `i` 个 cluster 中选择的样本数量 |
| `b_i` | MOSAIC 迭代过程中已经从第 `i` 个 cluster 选择的数量 |
| `U(D)` | 模型在验证集上的 utility，higher is better |
| `Delta_U_i(n)` | 只从第 `i` 个 cluster 加入 `n` 个样本带来的 utility 提升 |
| `a_i` | 第 `i` 个 cluster scaling law 的渐近收益 |
| `tau_i` | 第 `i` 个 cluster scaling law 的饱和速度参数 |

## 2. 优化目标

给定训练集 `D_train`、数据池 `D_pool` 和预算 `B`，选择：

```math
D_{sel} \subset D_{pool}, \quad |D_{sel}| = B
```

使得：

```math
U(D_{train} \cup D_{sel})
```

尽可能大。

等价地，希望最大化：

```math
\Delta U = U(D_{train} \cup D_{sel}) - U(D_{train})
```

## 3. Cluster-wise 近似

MOSAIC 把数据池划分为 `M` 个 cluster：

```math
D_{pool} = \bigcup_{i=1}^{M} D_{pool}^{i}
```

选择集合可以写成：

```math
D_{sel} = \bigcup_{i=1}^{M} D_{sel}^{i}
```

其中：

```math
n_i = |D_{sel}^{i}|, \quad \sum_i n_i = B
```

MOSAIC 使用一阶近似：

```math
\Delta U_{mix}(n_1, \ldots, n_M) \approx \sum_{i=1}^{M} \Delta U_i(n_i)
```

这个近似的含义是：

```text
不同 cluster 的主要收益可以用各自的 scaling curve 解释；
cluster 间交互项被视为残差。
```

## 4. Scaling law

对每个 cluster 拟合饱和指数函数：

```math
\widehat{\Delta U_i}(n) = a_i \left(1 - e^{-n / \tau_i}\right)
```

其中：

```text
a_i: 该 cluster 的最大潜在收益
tau_i: 收益饱和速度，tau 越小，越快饱和
```

## 5. 边际收益

在当前已经从第 `i` 个 cluster 选择 `b_i` 个样本时，再增加一个样本的估计边际收益为：

```math
\delta_i(b_i) = \widehat{\Delta U_i}(b_i + 1) - \widehat{\Delta U_i}(b_i)
```

如果使用 batch selection，则为：

```math
\delta_i(b_i, s) = \widehat{\Delta U_i}(b_i + s) - \widehat{\Delta U_i}(b_i)
```

其中 `s` 是 step size 或 batch size。

## 6. MOSAIC 选择算法

```text
Require:
  D_pool
  cluster_assignments
  ranked_pool_within_each_cluster
  scaling_params: {cluster_id: {a, tau}}
  budget B
  step size s

Initialize:
  D_sel = []
  b_i = 0 for every cluster i

while len(D_sel) < B:
  for each cluster i:
    if cluster i still has unselected samples:
      gain_i = f_i(b_i + s) - f_i(b_i)
    else:
      gain_i = -inf

  j = argmax_i gain_i

  select next top-ranked sample from cluster j
  add it to D_sel
  b_j = b_j + 1

return D_sel
```

## 7. 样本排序规则

每个 cluster 内部先根据 importance score 排序。

推荐 importance score：

```text
importance =
  0.35 * normalized_ADE
+ 0.35 * normalized_FDE
+ 0.10 * normalized_heading_error
+ 0.10 * normalized_collision_proxy
+ 0.10 * normalized_offroad_proxy
```

如果某个指标不可用，则跳过并重新归一化权重。

排序方向：

```text
importance 越高，说明 base model 在该 clip 上越差，该样本越可能有训练价值，因此越优先选择。
```

## 8. scaling fitting 细节

输入：

```text
cluster_id, n, utility, delta_utility
```

拟合：

```python
def scaling_fn(n, a, tau):
    return a * (1 - np.exp(-n / tau))
```

约束：

```text
a >= 0
tau > 0
```

fallback：

```text
如果拟合失败：
  a = max(observed_delta_utility, 0)
  tau = median(pilot_budgets)
```

如果 observed delta 全部 <= 0：

```text
将 a 设置为很小的正数，或者标记该 cluster 为 low_gain。
MOSAIC 仍然可以运行，但该 cluster 会被低优先级选择。
```

## 9. 必须处理的边界条件

### 9.1 cluster 被取空

如果某个 cluster 中已经没有未选样本，则：

```text
gain_i = -inf
```

### 9.2 所有 scaling gain 都小于等于 0

如果所有 cluster 的边际收益都 <= 0，可以 fallback：

```text
从全局 importance ranking 中选择剩余样本。
```

### 9.3 budget 大于 pool size

直接报错：

```text
ValueError: budget B cannot be larger than pool size
```

### 9.4 step size 大于剩余预算

最后一轮：

```text
actual_step = min(step, B - len(D_sel))
```

如果实现逐样本选择，可以先忽略 batch step。

## 10. 输出文件

### 10.1 选择结果

`outputs/selections/mosaic_budget_{B}.csv`

字段：

```text
clip_id
cluster_id
rank_within_cluster
importance_score
selection_order
method
budget
```

### 10.2 选择轨迹

`outputs/selections/mosaic_trace_budget_{B}.csv`

字段：

```text
step_id
selected_cluster_id
selected_clip_id
cluster_count_before
cluster_count_after
estimated_marginal_gain
```

### 10.3 cluster 分配统计

`outputs/results/cluster_distribution.csv`

字段：

```text
method
budget
seed
cluster_id
num_selected
ratio_selected
```
