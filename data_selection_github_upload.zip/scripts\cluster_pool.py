from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.selection.clustering import ClusteringConfig, cluster_and_save_pool
from src.utils.io import read_yaml
from src.utils.logging import setup_logging


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Cluster D_pool clips into MOSAIC domains.")
    parser.add_argument("--config", type=str, default=None, help="Optional YAML config path.")
    parser.add_argument("--pool", type=str, required=False, help="Input pool CSV.")
    parser.add_argument("--features", type=str, required=False, help="Feature parquet or .npy file.")
    parser.add_argument("--feature-columns", type=str, default=None)
    parser.add_argument("--feature-ids", type=str, default=None)
    parser.add_argument("--method", choices=["location", "kmeans", "kmeans++"], default=None)
    parser.add_argument("--num-clusters", type=int, default=None)
    parser.add_argument("--random-state", type=int, default=None)
    parser.add_argument("--kmeans-init", type=str, default=None, help="sklearn KMeans init mode.")
    parser.add_argument("--out-dir", type=str, default="outputs/clusters")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logger = setup_logging(args.log_level)
    cfg = read_yaml(args.config) if args.config else {}
    cluster_cfg = cfg.get("clustering", {})

    if not args.pool:
        raise SystemExit("--pool is required")
    if not args.features:
        raise SystemExit("--features is required")

    config = ClusteringConfig(
        method=args.method or cluster_cfg.get("method", "kmeans++"),
        num_clusters=args.num_clusters
        if args.num_clusters is not None
        else int(cluster_cfg.get("num_clusters", 4)),
        random_state=args.random_state
        if args.random_state is not None
        else int(cluster_cfg.get("random_state", 42)),
        kmeans_init=args.kmeans_init or cluster_cfg.get("kmeans_init", "k-means++"),
    )
    assignments, summary = cluster_and_save_pool(
        pool_path=args.pool,
        features_path=args.features,
        out_dir=args.out_dir,
        config=config,
        feature_columns_path=args.feature_columns,
        feature_ids_path=args.feature_ids,
    )
    logger.info("Wrote %d cluster assignments", len(assignments))
    logger.info("Cluster sizes: %s", summary.set_index("cluster_id")["num_clips"].to_dict())


if __name__ == "__main__":
    main()
