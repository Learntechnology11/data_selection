"""nuScenes adapter for Reliability-Quality Coverage.

This file keeps the RQC algorithm independent from any particular planner
training code. It consumes clip-level nuScenes artifacts such as pool manifests,
clip features, cluster assignments, and base-planner metrics, then emits nested
RQC selections that can be used by downstream autonomous-driving training.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

CODE_DIR = Path(__file__).resolve().parent
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from reliability_quality_coverage import (
    fisher_normalize,
    select_reliability_quality_coverage,
)


ID_COLUMNS = {
    "clip_id",
    "scene_token",
    "log_token",
    "location",
    "description",
    "start_sample_token",
    "end_sample_token",
    "sample_tokens",
    "num_samples",
    "split",
    "cluster_id",
    "cluster_method",
}

PLANNER_METRIC_COLUMNS = [
    "ade",
    "fde",
    "heading_error",
    "collision_proxy",
    "offroad_proxy",
    "jerk",
    "uncertainty_entropy",
]

QUALITY_METRIC_COLUMNS = [
    "ade",
    "fde",
    "collision_proxy",
    "offroad_proxy",
    "jerk",
]

GEOMETRY_VARIANCE_TARGET = 0.90
GEOMETRY_MAX_COMPONENTS = 32
COVERAGE_ETA = 0.50
COVERAGE_TAIL_FRACTION = 0.10
CLUSTER_ALPHA = 1.0
RELIABILITY_FLOOR = 1e-6


@dataclass
class NuScenesRQCSignals:
    frame: pd.DataFrame
    representation: np.ndarray
    gradient_proxy: np.ndarray
    geometry: np.ndarray
    cluster_labels: np.ndarray
    reliability: np.ndarray
    quality: np.ndarray
    reliability_quality_mass: np.ndarray
    reject_mask: np.ndarray
    feature_columns: list[str]
    metric_columns: list[str]
    diagnostics: dict[str, Any]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Reliability-Quality Coverage selection on nuScenes clip artifacts."
    )
    parser.add_argument("--pool", required=True, help="Pool clip manifest CSV.")
    parser.add_argument("--features", required=True, help="Clip feature table, parquet or CSV.")
    parser.add_argument("--clusters", default=None, help="Cluster assignments CSV.")
    parser.add_argument(
        "--planner-metrics",
        default=None,
        help="Per-clip planner metrics, e.g. outputs/ranking/pool_importance_scores.csv.",
    )
    parser.add_argument(
        "--camera-features",
        default=None,
        help="Optional cached sample-level camera features npz from cache_camera_features.py.",
    )
    parser.add_argument(
        "--base-train",
        default=None,
        help="Optional base_train manifest. If set, combined train manifests are written.",
    )
    parser.add_argument("--budget-ratios", nargs="*", default=["0.30", "0.50"])
    parser.add_argument("--budgets", nargs="*", type=int, default=None)
    parser.add_argument("--out-dir", default="outputs/rqc")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gradient-proxy-dim", type=int, default=64)
    parser.add_argument("--min-samples-per-clip", type=float, default=4.0)
    parser.add_argument("--write-geometry", action="store_true")
    return parser.parse_args()


def run_nuscenes_rqc(
    *,
    pool_path: str | Path,
    features_path: str | Path,
    clusters_path: str | Path | None,
    planner_metrics_path: str | Path | None,
    camera_features_path: str | Path | None,
    budget_ratios: Sequence[str | float],
    budgets: Sequence[int] | None,
    out_dir: str | Path,
    base_train_path: str | Path | None = None,
    seed: int = 42,
    gradient_proxy_dim: int = 64,
    min_samples_per_clip: float = 4.0,
    write_geometry: bool = False,
) -> dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    signals = build_nuscenes_rqc_signals(
        pool_path=pool_path,
        features_path=features_path,
        clusters_path=clusters_path,
        planner_metrics_path=planner_metrics_path,
        camera_features_path=camera_features_path,
        seed=seed,
        gradient_proxy_dim=gradient_proxy_dim,
        min_samples_per_clip=min_samples_per_clip,
    )
    budget_specs = resolve_budget_specs(
        n=len(signals.frame),
        budget_ratios=budget_ratios,
        budgets=budgets,
    )
    max_budget = max(spec["budget"] for spec in budget_specs)
    geometry, geometry_diagnostics = build_equal_energy_geometry(
        signals.representation,
        signals.gradient_proxy,
    )
    signals.geometry = geometry
    selection = select_reliability_quality_coverage(
        geometry,
        signals.cluster_labels,
        max_budget,
        reliability=signals.reliability_quality_mass,
        reject_mask=signals.reject_mask,
        eta=COVERAGE_ETA,
        tail_fraction=COVERAGE_TAIL_FRACTION,
        cluster_alpha=CLUSTER_ALPHA,
        clean_mass_floor=0.0,
        method_name="rqc_nuscenes",
    )
    save_signal_table(signals, out / "rqc_signals.csv")
    save_ranking(signals, selection, out / f"rqc_ranking_max_budget_{max_budget}.csv")
    save_trajectory(selection.trajectory, out / f"rqc_trajectory_max_budget_{max_budget}.csv")
    selected_paths: dict[str, str] = {}
    train_manifest_paths: dict[str, str] = {}
    for spec in budget_specs:
        budget = int(spec["budget"])
        nested = selection.truncate(budget)
        name = budget_spec_name(spec)
        path = out / f"selected_rqc_nuscenes_{name}.csv"
        selected_frame = save_selected(signals, nested, spec, path)
        selected_paths[name] = str(path)
        if base_train_path:
            train_path = out / f"train_manifest_rqc_nuscenes_{name}.csv"
            save_combined_train_manifest(base_train_path, selected_frame, train_path)
            train_manifest_paths[name] = str(train_path)

    diagnostics = {
        "method": "rqc_nuscenes",
        "num_pool_clips": int(len(signals.frame)),
        "budget_specs": budget_specs,
        "max_budget": int(max_budget),
        "selected_paths": selected_paths,
        "train_manifest_paths": train_manifest_paths,
        "rqc_diagnostics": selection.diagnostics,
        "signal_diagnostics": signals.diagnostics,
        "geometry_diagnostics": geometry_diagnostics,
        "parameters": {
            "gradient_proxy_dim": int(gradient_proxy_dim),
            "geometry_variance_target": float(GEOMETRY_VARIANCE_TARGET),
            "geometry_max_components": int(GEOMETRY_MAX_COMPONENTS),
            "eta": float(COVERAGE_ETA),
            "tail_fraction": float(COVERAGE_TAIL_FRACTION),
            "cluster_alpha": float(CLUSTER_ALPHA),
            "mass_formula": "rho_i * (1 + q_i)",
            "hard_reject_policy": "invalid metrics OR severe sensor missing OR broken timestamp/log",
        },
    }
    write_json(diagnostics, out / "rqc_diagnostics.json")
    if write_geometry:
        np.savez_compressed(
            out / "rqc_geometry.npz",
            clip_ids=signals.frame["clip_id"].astype(str).to_numpy(),
            representation=signals.representation.astype(np.float32),
            gradient_proxy=signals.gradient_proxy.astype(np.float32),
            geometry=geometry.astype(np.float32),
            cluster_labels=signals.cluster_labels.astype(str),
            reliability=signals.reliability.astype(np.float32),
            quality=signals.quality.astype(np.float32),
            reliability_quality_mass=signals.reliability_quality_mass.astype(np.float32),
            reject_mask=signals.reject_mask.astype(np.uint8),
        )
    return diagnostics


def build_nuscenes_rqc_signals(
    *,
    pool_path: str | Path,
    features_path: str | Path,
    clusters_path: str | Path | None,
    planner_metrics_path: str | Path | None,
    camera_features_path: str | Path | None,
    seed: int,
    gradient_proxy_dim: int,
    min_samples_per_clip: float,
) -> NuScenesRQCSignals:
    pool = read_table(pool_path)
    require_columns(pool, ["clip_id"], "pool")
    pool = pool.drop_duplicates("clip_id", keep="first").reset_index(drop=True)

    features = read_table(features_path)
    require_columns(features, ["clip_id"], "features")
    feature_columns = [
        column
        for column in numeric_feature_columns(features)
        if column not in pool.columns
    ]
    frame = pool.merge(features[["clip_id", *feature_columns]], on="clip_id", how="left")
    if feature_columns and frame[feature_columns].isna().all(axis=None):
        raise ValueError("No feature rows matched pool clip_id values")

    if clusters_path:
        clusters = read_table(clusters_path)
        require_columns(clusters, ["clip_id", "cluster_id"], "clusters")
        frame = frame.merge(clusters[["clip_id", "cluster_id"]], on="clip_id", how="left")
    if "cluster_id" not in frame.columns:
        frame["cluster_id"] = derive_cluster_labels(frame)
    frame["cluster_id"] = frame["cluster_id"].fillna("unknown").astype(str)

    metric_columns: list[str] = []
    if planner_metrics_path:
        metrics = read_table(planner_metrics_path)
        require_columns(metrics, ["clip_id"], "planner_metrics")
        metric_columns = [
            column
            for column in [*PLANNER_METRIC_COLUMNS, "importance_score"]
            if column in metrics.columns
        ]
        frame = frame.merge(metrics[["clip_id", *metric_columns]], on="clip_id", how="left")

    representation_parts = [dense_numeric_matrix(frame, feature_columns)]
    camera_quality = np.ones(len(frame), dtype=np.float64)
    if camera_features_path:
        camera_matrix, camera_quality = clip_camera_feature_matrix(frame, camera_features_path)
        if camera_matrix.size:
            representation_parts.append(camera_matrix)
            frame["rqc_camera_feature_fraction"] = camera_quality
    representation = np.concatenate(representation_parts, axis=1)
    representation = fill_nan_by_column_median(representation)

    cluster_labels = frame["cluster_id"].astype(str).to_numpy()
    feature_outlier_z = cluster_outlier_z(representation, cluster_labels)
    metric_outlier_z = metric_outlier_zscores(frame, metric_columns)
    invalid_metrics = invalid_metric_mask(frame, metric_columns)
    severe_sensor_missing = severe_sensor_missing_mask(
        frame,
        feature_columns=feature_columns,
        camera_quality=camera_quality if camera_features_path else None,
    )
    broken_temporal = broken_timestamp_or_log_mask(
        frame,
        min_samples_per_clip=min_samples_per_clip,
    )
    reject_mask = invalid_metrics | severe_sensor_missing | broken_temporal
    sensor_quality = sensor_quality_score(
        frame,
        feature_columns=feature_columns,
        camera_quality=camera_quality,
        min_samples_per_clip=min_samples_per_clip,
    )
    metric_validity = metric_validity_score(frame, metric_columns)
    uncertainty_risk = uncertainty_score(frame)
    reliability, reliability_rank_max, reliability_rank_parts = estimate_driving_reliability(
        feature_outlier_z=feature_outlier_z,
        metric_outlier_z=metric_outlier_z,
        sensor_quality=sensor_quality,
        metric_validity=metric_validity,
        uncertainty_risk=uncertainty_risk,
        cluster_labels=cluster_labels,
        reject_mask=reject_mask,
    )
    quality, quality_rank_parts = task_quality_score(frame, metric_columns, cluster_labels)
    reliability_quality_mass = np.where(
        reject_mask,
        0.0,
        reliability * (1.0 + quality),
    )
    gradient_proxy = build_driving_gradient_proxy(
        representation,
        frame,
        metric_columns=metric_columns,
        quality=quality,
        out_dim=gradient_proxy_dim,
        seed=seed,
        representation_dim=max(8, min(64, GEOMETRY_MAX_COMPONENTS * 2)),
    )
    fisher_gradient = fisher_normalize(
        gradient_proxy,
        rank=max(1, min(int(gradient_proxy_dim), gradient_proxy.shape[1])),
        reg=1e-3,
    )

    frame["rqc_feature_outlier_z"] = feature_outlier_z
    frame["rqc_metric_outlier_z"] = metric_outlier_z
    frame["rqc_sensor_quality"] = sensor_quality
    frame["rqc_metric_validity"] = metric_validity
    frame["rqc_uncertainty_risk"] = uncertainty_risk
    frame["rqc_rank_feature_outlier"] = reliability_rank_parts["feature_outlier_z"]
    frame["rqc_rank_metric_outlier"] = reliability_rank_parts["metric_outlier_z"]
    frame["rqc_rank_sensor_missing"] = reliability_rank_parts["sensor_missing"]
    frame["rqc_rank_metric_invalid"] = reliability_rank_parts["metric_invalid"]
    frame["rqc_rank_uncertainty"] = reliability_rank_parts["uncertainty_risk"]
    frame["rqc_reliability_rank_max"] = reliability_rank_max
    for column, ranks in quality_rank_parts.items():
        frame[f"rqc_quality_rank_{column}"] = ranks
    frame["rqc_reliability"] = reliability
    frame["rqc_quality"] = quality
    frame["rqc_mass"] = reliability_quality_mass
    frame["rqc_reject"] = reject_mask.astype(int)
    frame["rqc_reject_invalid_metrics"] = invalid_metrics.astype(int)
    frame["rqc_reject_severe_sensor_missing"] = severe_sensor_missing.astype(int)
    frame["rqc_reject_broken_timestamp_log"] = broken_temporal.astype(int)

    diagnostics = {
        "num_clips": int(len(frame)),
        "num_clusters": int(pd.Series(cluster_labels).nunique()),
        "feature_dim": int(representation.shape[1]),
        "gradient_proxy_dim": int(fisher_gradient.shape[1]),
        "feature_columns": feature_columns,
        "metric_columns": metric_columns,
        "mean_reliability": float(np.mean(reliability)) if len(reliability) else 0.0,
        "mean_quality": float(np.mean(quality)) if len(quality) else 0.0,
        "reject_count": int(np.sum(reject_mask)),
        "reject_rate": float(np.mean(reject_mask)) if len(reject_mask) else 0.0,
        "reject_invalid_metrics": int(np.sum(invalid_metrics)),
        "reject_severe_sensor_missing": int(np.sum(severe_sensor_missing)),
        "reject_broken_timestamp_log": int(np.sum(broken_temporal)),
        "reliability_policy": "exp(-max cluster percentile rank of feature outlier, metric outlier, sensor missing, metric invalid, uncertainty)",
        "quality_policy": "cluster percentile rank of mean rank-normalized planner difficulty",
        "cluster_counts": frame["cluster_id"].value_counts().sort_index().astype(int).to_dict(),
    }
    return NuScenesRQCSignals(
        frame=frame,
        representation=representation,
        gradient_proxy=fisher_gradient,
        geometry=np.zeros((len(frame), 1), dtype=np.float64),
        cluster_labels=cluster_labels,
        reliability=reliability,
        quality=quality,
        reliability_quality_mass=reliability_quality_mass,
        reject_mask=reject_mask,
        feature_columns=feature_columns,
        metric_columns=metric_columns,
        diagnostics=diagnostics,
    )


def numeric_feature_columns(frame: pd.DataFrame) -> list[str]:
    return [
        column
        for column in frame.columns
        if column not in ID_COLUMNS
        and not column.startswith("normalized_")
        and column not in PLANNER_METRIC_COLUMNS
        and pd.api.types.is_numeric_dtype(frame[column])
    ]


def dense_numeric_matrix(frame: pd.DataFrame, columns: Sequence[str]) -> np.ndarray:
    if not columns:
        return np.ones((len(frame), 1), dtype=np.float64)
    return frame[list(columns)].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)


def clip_camera_feature_matrix(frame: pd.DataFrame, camera_features_path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    path = Path(camera_features_path)
    if not path.exists():
        raise FileNotFoundError(path)
    if "sample_tokens" not in frame.columns:
        return np.zeros((len(frame), 0), dtype=np.float64), np.ones(len(frame), dtype=np.float64)
    data = np.load(path, allow_pickle=True)
    token_key = "sample_tokens" if "sample_tokens" in data.files else "tokens"
    feature_key = "features" if "features" in data.files else data.files[-1]
    tokens = [str(token) for token in data[token_key].tolist()]
    features = np.asarray(data[feature_key], dtype=np.float64)
    mapping = {token: features[idx] for idx, token in enumerate(tokens)}
    rows: list[np.ndarray] = []
    quality: list[float] = []
    zero = np.zeros(features.shape[1], dtype=np.float64)
    for _, row in frame.iterrows():
        clip_tokens = parse_json_list(row.get("sample_tokens"))
        vectors = [mapping[token] for token in clip_tokens if token in mapping]
        if vectors:
            rows.append(np.mean(vectors, axis=0))
            quality.append(float(len(vectors)) / max(float(len(clip_tokens)), 1.0))
        else:
            rows.append(zero.copy())
            quality.append(0.0)
    return np.vstack(rows), np.asarray(quality, dtype=np.float64)


def derive_cluster_labels(frame: pd.DataFrame) -> np.ndarray:
    if "location" in frame.columns:
        labels, _ = pd.factorize(frame["location"].fillna("unknown").astype(str), sort=True)
        return labels.astype(str)
    if "description" in frame.columns:
        labels, _ = pd.factorize(frame["description"].fillna("unknown").astype(str), sort=True)
        return labels.astype(str)
    return np.full(len(frame), "0", dtype=object)


def cluster_outlier_z(values: np.ndarray, clusters: np.ndarray) -> np.ndarray:
    values = fill_nan_by_column_median(values)
    z = np.zeros(len(values), dtype=np.float64)
    global_z = robust_distance_z(values)
    for cluster in np.unique(clusters):
        idx = np.flatnonzero(clusters == cluster)
        if len(idx) < 4:
            z[idx] = global_z[idx]
        else:
            z[idx] = robust_distance_z(values[idx])
    return np.maximum(z, 0.0)


def robust_distance_z(values: np.ndarray) -> np.ndarray:
    center = np.nanmedian(values, axis=0)
    scale = np.nanmedian(np.abs(values - center[None, :]), axis=0) * 1.4826
    scale = np.maximum(scale, 1e-3)
    distance = np.sqrt(np.nanmean(((values - center[None, :]) / scale[None, :]) ** 2, axis=1))
    median = float(np.nanmedian(distance))
    mad = float(np.nanmedian(np.abs(distance - median)) * 1.4826)
    return (distance - median) / max(mad, 1e-6)


def metric_outlier_zscores(frame: pd.DataFrame, metric_columns: Sequence[str]) -> np.ndarray:
    usable = available_metric_columns(frame, metric_columns)
    if not usable:
        return np.zeros(len(frame), dtype=np.float64)
    values = dense_numeric_matrix(frame, usable)
    values = fill_nan_by_column_median(values)
    return np.maximum(robust_distance_z(values), 0.0)


def invalid_metric_mask(frame: pd.DataFrame, metric_columns: Sequence[str]) -> np.ndarray:
    """Reject only planner metric rows that are structurally invalid."""

    mask = np.zeros(len(frame), dtype=bool)
    required = [column for column in ("ade", "fde") if column in metric_columns and column in frame.columns]
    if required:
        values = dense_numeric_matrix(frame, required)
        mask |= ~np.isfinite(values).all(axis=1)

    nonnegative = [
        column
        for column in ("ade", "fde", "heading_error", "collision_proxy", "offroad_proxy", "jerk")
        if column in metric_columns and column in frame.columns
    ]
    for column in nonnegative:
        values = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=np.float64)
        mask |= np.isfinite(values) & (values < 0.0)
    return mask


def severe_sensor_missing_mask(
    frame: pd.DataFrame,
    *,
    feature_columns: Sequence[str],
    camera_quality: np.ndarray | None,
) -> np.ndarray:
    """Reject rows with no usable sensor/feature payload, not rare feature geometry."""

    mask = np.zeros(len(frame), dtype=bool)
    if feature_columns:
        finite_fraction = np.isfinite(dense_numeric_matrix(frame, feature_columns)).mean(axis=1)
        mask |= finite_fraction <= 0.0
    if camera_quality is not None and len(camera_quality) == len(frame):
        mask |= np.asarray(camera_quality, dtype=np.float64) <= 0.0
    return mask


def broken_timestamp_or_log_mask(frame: pd.DataFrame, *, min_samples_per_clip: float) -> np.ndarray:
    """Reject broken clip metadata such as empty sample sequences or missing logs."""

    mask = np.zeros(len(frame), dtype=bool)
    if "sample_tokens" in frame.columns:
        counts = np.asarray([len(parse_json_list(value)) for value in frame["sample_tokens"]], dtype=np.float64)
        mask |= counts < max(float(min_samples_per_clip), 1.0)
    if "num_samples" in frame.columns:
        values = pd.to_numeric(frame["num_samples"], errors="coerce").to_numpy(dtype=np.float64)
        mask |= ~np.isfinite(values) | (values < max(float(min_samples_per_clip), 1.0))
    for column in ("scene_token", "log_token", "start_sample_token", "end_sample_token"):
        if column in frame.columns:
            text = frame[column].fillna("").astype(str).str.strip()
            mask |= text.eq("").to_numpy()
    return mask


def sensor_quality_score(
    frame: pd.DataFrame,
    *,
    feature_columns: Sequence[str],
    camera_quality: np.ndarray,
    min_samples_per_clip: float,
) -> np.ndarray:
    pieces: list[np.ndarray] = []
    if "num_samples" in frame.columns:
        num = pd.to_numeric(frame["num_samples"], errors="coerce").fillna(0.0).to_numpy(dtype=np.float64)
        pieces.append(np.clip(num / max(float(min_samples_per_clip), 1.0), 0.0, 1.0))
    if feature_columns:
        finite = np.isfinite(dense_numeric_matrix(frame, feature_columns)).mean(axis=1)
        pieces.append(np.asarray(finite, dtype=np.float64))
    if camera_quality is not None and len(camera_quality) == len(frame):
        pieces.append(np.asarray(camera_quality, dtype=np.float64))
    if not pieces:
        return np.ones(len(frame), dtype=np.float64)
    return np.clip(np.mean(np.vstack(pieces), axis=0), 0.0, 1.0)


def metric_validity_score(frame: pd.DataFrame, metric_columns: Sequence[str]) -> np.ndarray:
    usable = available_metric_columns(frame, metric_columns)
    if not usable:
        return np.ones(len(frame), dtype=np.float64)
    values = dense_numeric_matrix(frame, usable)
    return np.asarray(np.isfinite(values).mean(axis=1), dtype=np.float64)


def uncertainty_score(frame: pd.DataFrame) -> np.ndarray:
    if "uncertainty_entropy" not in frame.columns:
        return np.zeros(len(frame), dtype=np.float64)
    values = pd.to_numeric(frame["uncertainty_entropy"], errors="coerce").to_numpy(dtype=np.float64)
    return robust_minmax(values, high_is_large=True)


def estimate_driving_reliability(
    *,
    feature_outlier_z: np.ndarray,
    metric_outlier_z: np.ndarray,
    sensor_quality: np.ndarray,
    metric_validity: np.ndarray,
    uncertainty_risk: np.ndarray,
    cluster_labels: np.ndarray,
    reject_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    parts = {
        "feature_outlier_z": cluster_percentile_rank(feature_outlier_z, cluster_labels),
        "metric_outlier_z": cluster_percentile_rank(metric_outlier_z, cluster_labels),
        "sensor_missing": cluster_percentile_rank(1.0 - np.clip(sensor_quality, 0.0, 1.0), cluster_labels),
        "metric_invalid": cluster_percentile_rank(1.0 - np.clip(metric_validity, 0.0, 1.0), cluster_labels),
        "uncertainty_risk": cluster_percentile_rank(np.clip(uncertainty_risk, 0.0, 1.0), cluster_labels),
    }
    max_rank = np.maximum.reduce(list(parts.values())) if parts else np.zeros(len(cluster_labels), dtype=np.float64)
    reliability = np.clip(np.exp(-max_rank), RELIABILITY_FLOOR, 1.0)
    reliability = np.where(reject_mask, 0.0, reliability)
    return reliability, max_rank, parts


def task_quality_score(
    frame: pd.DataFrame,
    metric_columns: Sequence[str],
    cluster_labels: np.ndarray,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    usable = [
        column
        for column in QUALITY_METRIC_COLUMNS
        if column in metric_columns and column in frame.columns and pd.to_numeric(frame[column], errors="coerce").notna().any()
    ]
    if not usable and "importance_score" in frame.columns:
        values = pd.to_numeric(frame["importance_score"], errors="coerce").to_numpy(dtype=np.float64)
        ranks = cluster_percentile_rank(values, cluster_labels)
        return ranks, {"importance_score": ranks}
    if not usable:
        return np.zeros(len(frame), dtype=np.float64), {}

    parts: dict[str, np.ndarray] = {}
    for column in usable:
        values = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=np.float64)
        parts[column] = cluster_percentile_rank(values, cluster_labels)
    mean_rank = np.mean(np.vstack(list(parts.values())), axis=0)
    quality = cluster_percentile_rank(mean_rank, cluster_labels)
    return np.clip(quality, 0.0, 1.0), parts


def cluster_percentile_rank(values: np.ndarray, clusters: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    labels = np.asarray(clusters)
    if len(arr) != len(labels):
        raise ValueError("values and clusters must have the same length")
    ranks = np.zeros(len(arr), dtype=np.float64)
    for cluster in np.unique(labels):
        idx = np.flatnonzero(labels == cluster)
        local = arr[idx]
        finite = np.isfinite(local)
        if len(idx) <= 1:
            ranks[idx] = 0.0
            continue
        if finite.any():
            finite_values = local[finite]
            fill = float(np.max(finite_values)) + max(float(np.std(finite_values)), 1e-6)
        else:
            fill = 0.0
        filled = np.where(finite, local, fill)
        if float(np.max(filled) - np.min(filled)) <= 1e-12:
            ranks[idx] = 0.0
            continue
        sorted_values = np.sort(filled)
        ranks[idx] = np.searchsorted(sorted_values, filled, side="left") / float(len(idx) - 1)
    return np.clip(ranks, 0.0, 1.0)


def build_driving_gradient_proxy(
    representation: np.ndarray,
    frame: pd.DataFrame,
    *,
    metric_columns: Sequence[str],
    quality: np.ndarray,
    out_dim: int,
    seed: int,
    representation_dim: int,
) -> np.ndarray:
    rng = np.random.default_rng(int(seed) + 7919)
    z = standardize(fill_nan_by_column_median(representation))
    if z.shape[1] > representation_dim:
        projection = rng.normal(0.0, 1.0 / math.sqrt(representation_dim), size=(z.shape[1], representation_dim))
        z = z @ projection

    usable = available_metric_columns(frame, metric_columns)
    if usable:
        residual = dense_numeric_matrix(frame, usable)
        residual = standardize(fill_nan_by_column_median(residual))
    else:
        residual = standardize(np.asarray(quality, dtype=np.float64).reshape(-1, 1))
    raw = np.concatenate([z * residual[:, [col]] for col in range(residual.shape[1])], axis=1)
    if raw.shape[1] > int(out_dim):
        projection = rng.normal(0.0, 1.0 / math.sqrt(max(int(out_dim), 1)), size=(raw.shape[1], int(out_dim)))
        raw = raw @ projection
    return raw


def build_equal_energy_geometry(
    representation: np.ndarray,
    fisher_gradient: np.ndarray | None,
) -> tuple[np.ndarray, dict[str, Any]]:
    z, z_info = pca_equal_energy_block(representation)
    parts = [z] if z.shape[1] else []
    g_info: dict[str, Any] = {
        "input_dim": 0,
        "retained_components": 0,
        "explained_variance": 0.0,
    }
    if fisher_gradient is not None:
        g, g_info = pca_equal_energy_block(fisher_gradient)
        if g.shape[1]:
            parts.append(g)
    if not parts:
        raise ValueError("At least one geometry block must be non-empty")
    geometry = np.concatenate(parts, axis=1)
    geometry = geometry / np.maximum(np.linalg.norm(geometry, axis=1, keepdims=True), 1e-12)
    diagnostics = {
        "normalization": "PCA variance >= 90%, capped at 32 components per block; each block divided by sqrt(retained_dim); final row L2 normalization",
        "representation": z_info,
        "gradient": g_info,
    }
    return geometry, diagnostics


def pca_equal_energy_block(values: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
    arr = fill_nan_by_column_median(values)
    n, d = arr.shape
    diagnostics = {
        "input_dim": int(d),
        "retained_components": 0,
        "explained_variance": 0.0,
        "variance_target": float(GEOMETRY_VARIANCE_TARGET),
        "max_components": int(GEOMETRY_MAX_COMPONENTS),
    }
    if n == 0 or d == 0:
        return np.zeros((n, 0), dtype=np.float64), diagnostics

    standardized = standardize(arr)
    max_components = max(1, min(int(GEOMETRY_MAX_COMPONENTS), int(d), int(max(n - 1, 1))))
    try:
        pca = PCA(n_components=max_components, random_state=0)
        scores = pca.fit_transform(standardized)
        ratios = np.nan_to_num(pca.explained_variance_ratio_, nan=0.0, posinf=0.0, neginf=0.0)
    except ValueError:
        scores = standardized[:, :max_components]
        ratios = np.zeros(max_components, dtype=np.float64)

    if ratios.size and float(np.sum(ratios)) > 0.0:
        keep = int(np.searchsorted(np.cumsum(ratios), GEOMETRY_VARIANCE_TARGET, side="left") + 1)
        keep = max(1, min(keep, max_components))
        explained = float(np.sum(ratios[:keep]))
    else:
        keep = max_components
        explained = 0.0
    scores = standardize(scores[:, :keep])
    scaled = scores / math.sqrt(float(max(keep, 1)))
    diagnostics["retained_components"] = int(keep)
    diagnostics["explained_variance"] = explained
    return scaled, diagnostics


def available_metric_columns(frame: pd.DataFrame, metric_columns: Sequence[str]) -> list[str]:
    usable: list[str] = []
    for column in metric_columns:
        if column not in PLANNER_METRIC_COLUMNS or column not in frame.columns:
            continue
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.notna().any():
            usable.append(column)
    return usable


def resolve_budget_specs(
    *,
    n: int,
    budget_ratios: Sequence[str | float],
    budgets: Sequence[int] | None,
) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []
    for budget in budgets or []:
        count = min(max(1, int(budget)), n)
        specs.append(
            {
                "budget": count,
                "requested_budget": int(budget),
                "budget_ratio": float(count) / max(float(n), 1.0),
                "budget_percent": 100.0 * float(count) / max(float(n), 1.0),
                "source": "count",
            }
        )
    for raw in budget_ratios or []:
        ratio = parse_ratio(raw)
        count = min(max(1, int(math.ceil(n * ratio))), n)
        specs.append(
            {
                "budget": count,
                "requested_budget_ratio": ratio,
                "requested_budget_percent": 100.0 * ratio,
                "budget_ratio": float(count) / max(float(n), 1.0),
                "budget_percent": 100.0 * float(count) / max(float(n), 1.0),
                "source": "ratio",
            }
        )
    if not specs:
        raise ValueError("At least one budget or budget ratio is required")
    seen: set[int] = set()
    deduped: list[dict[str, Any]] = []
    for spec in sorted(specs, key=lambda item: int(item["budget"])):
        budget = int(spec["budget"])
        if budget not in seen:
            deduped.append(spec)
            seen.add(budget)
    return deduped


def budget_spec_name(spec: dict[str, Any]) -> str:
    if spec.get("source") == "ratio":
        percent = float(spec.get("requested_budget_percent", spec["budget_percent"]))
        return f"p{percent:g}".replace(".", "p")
    return f"n{int(spec['budget'])}"


def save_signal_table(signals: NuScenesRQCSignals, path: Path) -> None:
    columns = [
        "clip_id",
        "cluster_id",
        "rqc_reliability",
        "rqc_quality",
        "rqc_mass",
        "rqc_reject",
        "rqc_feature_outlier_z",
        "rqc_metric_outlier_z",
        "rqc_sensor_quality",
        "rqc_metric_validity",
        "rqc_uncertainty_risk",
        "rqc_rank_feature_outlier",
        "rqc_rank_metric_outlier",
        "rqc_rank_sensor_missing",
        "rqc_rank_metric_invalid",
        "rqc_rank_uncertainty",
        "rqc_reliability_rank_max",
        "rqc_reject_invalid_metrics",
        "rqc_reject_severe_sensor_missing",
        "rqc_reject_broken_timestamp_log",
    ]
    quality_rank_columns = sorted(
        column for column in signals.frame.columns if column.startswith("rqc_quality_rank_")
    )
    existing = [column for column in [*columns, *quality_rank_columns] if column in signals.frame.columns]
    write_csv(signals.frame[existing], path)


def save_ranking(signals: NuScenesRQCSignals, selection: Any, path: Path) -> None:
    selected = signals.frame.iloc[selection.ranking].copy().reset_index(drop=True)
    selected.insert(0, "selection_order", np.arange(1, len(selected) + 1))
    selected["rqc_weight"] = selection.weights
    selected["method"] = selection.method
    write_csv(selected, path)


def save_selected(signals: NuScenesRQCSignals, selection: Any, spec: dict[str, Any], path: Path) -> pd.DataFrame:
    selected = signals.frame.iloc[selection.ranking].copy().reset_index(drop=True)
    selected.insert(0, "selection_order", np.arange(1, len(selected) + 1))
    selected["rqc_weight"] = selection.weights
    selected["method"] = selection.method
    selected["budget"] = int(spec["budget"])
    selected["budget_ratio"] = float(spec["budget_ratio"])
    selected["budget_percent"] = float(spec["budget_percent"])
    if "requested_budget_percent" in spec:
        selected["requested_budget_percent"] = float(spec["requested_budget_percent"])
    write_csv(selected, path)
    return selected


def save_combined_train_manifest(base_train_path: str | Path, selected: pd.DataFrame, path: Path) -> None:
    base = read_table(base_train_path)
    common = [column for column in base.columns if column in selected.columns]
    if "clip_id" not in common or "sample_tokens" not in common:
        raise ValueError("base_train and selected clips must share clip_id and sample_tokens")
    combined = pd.concat([base, selected[common]], ignore_index=True)
    combined = combined.drop_duplicates("clip_id", keep="first")
    write_csv(combined, path)


def save_trajectory(rows: Sequence[dict[str, Any]], path: Path) -> None:
    write_csv(pd.DataFrame(rows), path)


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path)
    if suffix in {".csv", ".txt"}:
        return pd.read_csv(path)
    raise ValueError(f"Unsupported table format: {path}")


def write_csv(frame: pd.DataFrame, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def write_json(payload: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(to_jsonable(payload), f, indent=2, ensure_ascii=False)


def require_columns(frame: pd.DataFrame, columns: Iterable[str], name: str) -> None:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise ValueError(f"{name} missing required columns: {missing}")


def parse_json_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    if pd.isna(value):
        return []
    text = str(value).strip()
    if not text:
        return []
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        parsed = [item.strip() for item in text.split(",") if item.strip()]
    if not isinstance(parsed, list):
        return []
    return [str(item) for item in parsed]


def parse_ratio(value: str | float) -> float:
    text = str(value).strip()
    if text.endswith("%"):
        ratio = float(text[:-1]) / 100.0
    else:
        ratio = float(text)
        if ratio > 1.0:
            ratio = ratio / 100.0
    if ratio <= 0.0:
        raise ValueError(f"Budget ratio must be positive: {value}")
    return min(ratio, 1.0)


def fill_nan_by_column_median(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64).copy()
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    medians = np.nanmedian(arr, axis=0)
    medians = np.where(np.isfinite(medians), medians, 0.0)
    rows, cols = np.where(~np.isfinite(arr))
    if len(rows):
        arr[rows, cols] = medians[cols]
    return arr


def robust_minmax(values: np.ndarray, *, high_is_large: bool) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return np.ones(len(arr), dtype=np.float64)
    lo = float(np.quantile(finite, 0.05))
    hi = float(np.quantile(finite, 0.95))
    if abs(hi - lo) < 1e-12:
        return np.zeros(len(arr), dtype=np.float64)
    out = (np.nan_to_num(arr, nan=lo) - lo) / (hi - lo)
    out = np.clip(out, 0.0, 1.0)
    return out if high_is_large else 1.0 - out


def standardize(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    return (arr - arr.mean(axis=0, keepdims=True)) / np.maximum(arr.std(axis=0, keepdims=True), 1e-6)


def to_jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def main() -> None:
    args = parse_args()
    diagnostics = run_nuscenes_rqc(
        pool_path=args.pool,
        features_path=args.features,
        clusters_path=args.clusters,
        planner_metrics_path=args.planner_metrics,
        camera_features_path=args.camera_features,
        budget_ratios=args.budget_ratios,
        budgets=args.budgets,
        out_dir=args.out_dir,
        base_train_path=args.base_train,
        seed=args.seed,
        gradient_proxy_dim=args.gradient_proxy_dim,
        min_samples_per_clip=args.min_samples_per_clip,
        write_geometry=args.write_geometry,
    )
    print(json.dumps(to_jsonable(diagnostics), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
