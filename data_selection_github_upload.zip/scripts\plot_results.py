from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.utils.io import ensure_dir, write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot and summarize MOSAIC experiment results.")
    parser.add_argument("--results", default="outputs/results/main_results.csv")
    parser.add_argument("--metric-breakdown", default="outputs/results/metric_breakdown.csv")
    parser.add_argument("--cluster-distribution", default="outputs/results/cluster_distribution.csv")
    parser.add_argument("--pilot-results", default="outputs/pilot/pilot_results.csv")
    parser.add_argument("--ranked-pool", default="outputs/ranking/cluster_ranked_pool.csv")
    parser.add_argument("--selections-dir", default="outputs/selections")
    parser.add_argument("--checkpoint-dir", default="outputs/checkpoints")
    parser.add_argument("--out-dir", default="outputs/analysis")
    return parser.parse_args()


def load_optional_csv(path: str | Path) -> pd.DataFrame | None:
    path = Path(path)
    if not path.exists():
        return None
    frame = pd.read_csv(path)
    if frame.empty:
        return None
    return frame


def budget_x_column(frame: pd.DataFrame) -> tuple[str, str]:
    if "budget_percent" in frame.columns:
        return "budget_percent", "Selected pool clips (%)"
    return "budget", "Selected pool clips"


def budget_label(value: Any, x_col: str) -> str:
    if x_col == "budget_percent":
        return f"{float(value):.1f}%"
    return str(int(value))


def summarize_results(results: pd.DataFrame) -> dict[str, Any]:
    required = {"method", "budget", "seed", "utility"}
    missing = required - set(results.columns)
    if missing:
        raise ValueError(f"results missing columns: {sorted(missing)}")

    grouped = (
        results.groupby(["method", "budget"], as_index=False)
        .agg(
            utility_mean=("utility", "mean"),
            utility_std=("utility", "std"),
            num_runs=("utility", "count"),
        )
        .sort_values(["budget", "utility_mean"], ascending=[True, False])
    )
    best_by_budget = grouped.loc[grouped.groupby("budget")["utility_mean"].idxmax()].copy()

    summary: dict[str, Any] = {
        "num_rows": int(len(results)),
        "methods": sorted(results["method"].astype(str).unique().tolist()),
        "budgets": sorted(int(x) for x in results["budget"].unique().tolist()),
        "best_by_budget": best_by_budget.to_dict(orient="records"),
        "utility_table": grouped.to_dict(orient="records"),
    }
    if "budget_percent" in results.columns:
        summary["budget_percents"] = sorted(float(x) for x in results["budget_percent"].unique().tolist())

    if {"mosaic", "random"}.issubset(set(results["method"].astype(str))):
        pivot = grouped.pivot(index="budget", columns="method", values="utility_mean")
        comparisons = []
        for budget, row in pivot.iterrows():
            if pd.notna(row.get("mosaic")) and pd.notna(row.get("random")):
                comparisons.append(
                    {
                        "budget": int(budget),
                        "mosaic_minus_random": float(row["mosaic"] - row["random"]),
                    }
                )
        summary["mosaic_vs_random"] = comparisons

    return summary


def plot_utility(results: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x_col, x_label = budget_x_column(results)
    grouped = (
        results.groupby(["method", x_col], as_index=False)
        .agg(utility_mean=("utility", "mean"), utility_std=("utility", "std"))
        .sort_values(x_col)
    )
    plt.figure(figsize=(8, 5))
    for method, frame in grouped.groupby("method", sort=True):
        frame = frame.sort_values(x_col)
        std = frame["utility_std"].fillna(0.0)
        plt.plot(frame[x_col], frame["utility_mean"], marker="o", label=str(method))
        plt.fill_between(
            frame[x_col],
            frame["utility_mean"] - std,
            frame["utility_mean"] + std,
            alpha=0.15,
        )
    plt.xlabel(x_label)
    plt.ylabel("Validation utility")
    plt.title("Utility vs. Selection Budget")
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_dir / "utility_vs_budget.png", dpi=180)
    plt.close()


def plot_metrics(metric_breakdown: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    required = {"method", "budget", "metric", "value"}
    if required - set(metric_breakdown.columns):
        return

    frame = metric_breakdown.copy()
    x_col, x_label = budget_x_column(frame)
    frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
    for metric, metric_frame in frame.groupby("metric", sort=True):
        if metric_frame["value"].notna().sum() == 0:
            continue
        grouped = (
            metric_frame.groupby(["method", x_col], as_index=False)
            .agg(mean=("value", "mean"), std=("value", "std"))
            .sort_values(x_col)
        )
        plt.figure(figsize=(8, 5))
        for method, method_frame in grouped.groupby("method", sort=True):
            method_frame = method_frame.sort_values(x_col)
            std = method_frame["std"].fillna(0.0)
            plt.plot(method_frame[x_col], method_frame["mean"], marker="o", label=str(method))
            plt.fill_between(
                method_frame[x_col],
                method_frame["mean"] - std,
                method_frame["mean"] + std,
                alpha=0.15,
            )
        plt.xlabel(x_label)
        plt.ylabel(str(metric))
        plt.title(f"{metric} vs. Selection Budget")
        plt.grid(True, alpha=0.25)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / f"metric_{metric}.png", dpi=180)
        plt.close()


def plot_cluster_distribution(distribution: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    required = {"method", "budget", "cluster_id", "num_selected"}
    if required - set(distribution.columns):
        return
    grouped = (
        distribution.groupby(["method", "budget", "cluster_id"], as_index=False)["num_selected"]
        .mean()
        .sort_values(["budget", "method", "cluster_id"])
    )
    if grouped.empty:
        return
    for budget, frame in grouped.groupby("budget", sort=True):
        pivot = frame.pivot_table(
            index="method",
            columns="cluster_id",
            values="num_selected",
            aggfunc="sum",
            fill_value=0,
        ).sort_index()
        ax = pivot.plot(kind="bar", stacked=True, figsize=(8, 5))
        ax.set_xlabel("Method")
        ax.set_ylabel("Mean selected clips")
        ax.set_title(f"Cluster Distribution at Budget {budget}")
        ax.grid(True, axis="y", alpha=0.25)
        plt.tight_layout()
        plt.savefig(out_dir / f"cluster_distribution_budget_{budget}.png", dpi=180)
        plt.close()


def plot_utility_heatmaps(results: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x_col, x_label = budget_x_column(results)
    grouped = (
        results.groupby(["method", x_col], as_index=False)["utility"]
        .mean()
        .sort_values([x_col, "method"])
    )
    pivot = grouped.pivot(index="method", columns=x_col, values="utility").sort_index()
    if pivot.empty:
        return

    plt.figure(figsize=(max(7, 1.0 * len(pivot.columns)), max(4, 0.45 * len(pivot.index))))
    image = plt.imshow(pivot.to_numpy(dtype=float), aspect="auto", cmap="viridis")
    plt.colorbar(image, label="Mean utility")
    plt.xticks(np.arange(len(pivot.columns)), [budget_label(x, x_col) for x in pivot.columns])
    plt.yticks(np.arange(len(pivot.index)), [str(x) for x in pivot.index])
    for row_idx, method in enumerate(pivot.index):
        for col_idx, budget in enumerate(pivot.columns):
            value = pivot.loc[method, budget]
            if pd.notna(value):
                plt.text(col_idx, row_idx, f"{value:.1f}", ha="center", va="center", color="white")
    plt.xlabel(x_label)
    plt.ylabel("Method")
    plt.title("Mean Utility Heatmap")
    plt.tight_layout()
    plt.savefig(out_dir / "utility_heatmap.png", dpi=180)
    plt.close()

    ranks = pivot.rank(axis=0, ascending=False, method="min")
    plt.figure(figsize=(max(7, 1.0 * len(ranks.columns)), max(4, 0.45 * len(ranks.index))))
    image = plt.imshow(ranks.to_numpy(dtype=float), aspect="auto", cmap="magma_r")
    plt.colorbar(image, label="Rank, 1 is best")
    plt.xticks(np.arange(len(ranks.columns)), [budget_label(x, x_col) for x in ranks.columns])
    plt.yticks(np.arange(len(ranks.index)), [str(x) for x in ranks.index])
    for row_idx, method in enumerate(ranks.index):
        for col_idx, budget in enumerate(ranks.columns):
            value = ranks.loc[method, budget]
            if pd.notna(value):
                plt.text(col_idx, row_idx, f"{int(value)}", ha="center", va="center", color="white")
    plt.xlabel(x_label)
    plt.ylabel("Method")
    plt.title("Method Rank Heatmap")
    plt.tight_layout()
    plt.savefig(out_dir / "method_rank_heatmap.png", dpi=180)
    plt.close()


def plot_mosaic_vs_random(results: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x_col, x_label = budget_x_column(results)
    grouped = results.groupby(["method", x_col], as_index=False)["utility"].mean()
    pivot = grouped.pivot(index=x_col, columns="method", values="utility")
    if not {"mosaic", "random"}.issubset(set(pivot.columns)):
        return
    diff = (pivot["mosaic"] - pivot["random"]).dropna()
    if diff.empty:
        return
    colors = ["#2ca02c" if value >= 0 else "#d62728" for value in diff]
    plt.figure(figsize=(7, 4))
    plt.bar([budget_label(x, x_col) for x in diff.index], diff.values, color=colors)
    plt.axhline(0.0, color="black", linewidth=1.0)
    plt.xlabel(x_label)
    plt.ylabel("MOSAIC utility minus random")
    plt.title("MOSAIC Gain Over Random")
    plt.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(out_dir / "mosaic_gain_vs_random.png", dpi=180)
    plt.close()


def plot_pilot_scaling(pilot_results: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    required = {"cluster_id", "n", "delta_utility"}
    if required - set(pilot_results.columns):
        return
    frame = pilot_results.copy()
    frame["n"] = pd.to_numeric(frame["n"], errors="coerce")
    frame["delta_utility"] = pd.to_numeric(frame["delta_utility"], errors="coerce")
    frame = frame.dropna(subset=["n", "delta_utility"])
    if frame.empty:
        return

    plt.figure(figsize=(8, 5))
    for cluster_id, cluster_frame in frame.groupby("cluster_id", sort=True):
        cluster_frame = cluster_frame.sort_values("n")
        grouped = cluster_frame.groupby("n", as_index=False)["delta_utility"].mean()
        plt.plot(grouped["n"], grouped["delta_utility"], marker="o", label=f"cluster {cluster_id}")
    plt.axhline(0.0, color="black", linewidth=1.0)
    plt.xlabel("Pilot selected clips from cluster")
    plt.ylabel("Validation utility gain")
    plt.title("Pilot Scaling Observations")
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_dir / "pilot_scaling_observed.png", dpi=180)
    plt.close()


def plot_ranking_distribution(ranked_pool: pd.DataFrame, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    required = {"cluster_id", "importance_score"}
    if required - set(ranked_pool.columns):
        return
    frame = ranked_pool.copy()
    frame["importance_score"] = pd.to_numeric(frame["importance_score"], errors="coerce")
    frame = frame.dropna(subset=["importance_score"])
    if frame.empty:
        return

    clusters = sorted(frame["cluster_id"].unique().tolist())
    data = [frame.loc[frame["cluster_id"] == cluster_id, "importance_score"].to_numpy() for cluster_id in clusters]
    plt.figure(figsize=(max(7, 0.8 * len(clusters)), 5))
    plt.boxplot(data, labels=[str(cluster_id) for cluster_id in clusters], showfliers=False)
    counts = frame["cluster_id"].value_counts().to_dict()
    for idx, cluster_id in enumerate(clusters, start=1):
        plt.text(idx, plt.ylim()[1], f"n={counts.get(cluster_id, 0)}", ha="center", va="top", fontsize=8)
    plt.xlabel("Cluster")
    plt.ylabel("Importance score")
    plt.title("Pool Importance Score by Cluster")
    plt.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(out_dir / "ranking_importance_by_cluster.png", dpi=180)
    plt.close()


def plot_mosaic_traces(selections_dir: str | Path, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    selection_path = Path(selections_dir)
    if not selection_path.exists():
        return
    for trace_path in sorted(selection_path.glob("mosaic_trace_budget_*.csv")):
        trace = load_optional_csv(trace_path)
        if trace is None or {"step_id", "selected_cluster_id"} - set(trace.columns):
            continue
        trace = trace.sort_values("step_id").copy()
        dummies = pd.get_dummies(trace["selected_cluster_id"].astype(str))
        cumulative = dummies.cumsum()
        plt.figure(figsize=(8, 5))
        bottom = np.zeros(len(cumulative), dtype=float)
        x = trace["step_id"].to_numpy(dtype=float)
        for cluster_id in cumulative.columns:
            values = cumulative[cluster_id].to_numpy(dtype=float)
            top = bottom + values
            plt.fill_between(x, bottom, top, alpha=0.6, label=f"cluster {cluster_id}")
            bottom = top
        plt.xlabel("MOSAIC selection step")
        plt.ylabel("Cumulative selected clips")
        plt.title(trace_path.stem.replace("_", " "))
        plt.grid(True, alpha=0.25)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / f"{trace_path.stem}.png", dpi=180)
        plt.close()


def plot_training_curves(checkpoint_dir: str | Path, out_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    checkpoint_path = Path(checkpoint_dir)
    if not checkpoint_path.exists():
        return
    try:
        import torch
    except Exception:
        return

    histories: list[tuple[str, pd.DataFrame]] = []
    for path in sorted(checkpoint_path.glob("*.pt")):
        try:
            checkpoint = torch.load(path, map_location="cpu")
        except Exception:
            continue
        history = checkpoint.get("history", [])
        if not history:
            continue
        frame = pd.DataFrame(history)
        if {"epoch", "train_loss", "val_loss"} - set(frame.columns):
            continue
        histories.append((path.stem, frame))

    if not histories:
        return

    plt.figure(figsize=(10, 6))
    show_labels = len(histories) <= 12
    for name, frame in histories:
        plt.plot(
            frame["epoch"],
            frame["val_loss"],
            linewidth=1.2,
            alpha=0.75,
            label=name if show_labels else None,
        )
    plt.xlabel("Epoch")
    plt.ylabel("Validation loss")
    plt.title("Validation Loss Curves")
    plt.grid(True, alpha=0.25)
    if show_labels:
        plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "training_val_loss_curves.png", dpi=180)
    plt.close()

    summary_rows = []
    for name, frame in histories:
        best_idx = pd.to_numeric(frame["val_loss"], errors="coerce").idxmin()
        summary_rows.append(
            {
                "experiment": name,
                "epochs_ran": int(pd.to_numeric(frame["epoch"], errors="coerce").max()),
                "best_epoch": int(frame.loc[best_idx, "epoch"]),
                "best_val_loss": float(frame.loc[best_idx, "val_loss"]),
            }
        )
    summary_frame = pd.DataFrame(summary_rows).sort_values("best_val_loss").head(30)
    plt.figure(figsize=(10, max(4, 0.3 * len(summary_frame))))
    y = np.arange(len(summary_frame))
    plt.barh(y, summary_frame["best_val_loss"])
    plt.yticks(y, summary_frame["experiment"])
    plt.xlabel("Best validation loss")
    plt.title("Best Validation Loss by Experiment")
    plt.gca().invert_yaxis()
    plt.grid(True, axis="x", alpha=0.25)
    plt.tight_layout()
    plt.savefig(out_dir / "training_best_val_loss.png", dpi=180)
    plt.close()


def write_markdown(summary: dict[str, Any], out_dir: Path) -> None:
    lines = [
        "# MOSAIC Result Analysis",
        "",
        f"- Rows: {summary['num_rows']}",
        f"- Methods: {', '.join(summary['methods'])}",
        f"- Budgets: {', '.join(str(x) for x in summary['budgets'])}",
        "",
        "## Best Method By Budget",
        "",
        "| budget | method | utility_mean | utility_std | runs |",
        "|---:|---|---:|---:|---:|",
    ]
    for row in summary["best_by_budget"]:
        lines.append(
            "| {budget} | {method} | {utility_mean:.6f} | {utility_std:.6f} | {num_runs} |".format(
                budget=int(row["budget"]),
                method=row["method"],
                utility_mean=float(row["utility_mean"]),
                utility_std=0.0 if pd.isna(row["utility_std"]) else float(row["utility_std"]),
                num_runs=int(row["num_runs"]),
            )
        )
    if summary.get("mosaic_vs_random"):
        lines.extend(["", "## MOSAIC vs Random", "", "| budget | utility gain |", "|---:|---:|"])
        for row in summary["mosaic_vs_random"]:
            lines.append(f"| {row['budget']} | {row['mosaic_minus_random']:.6f} |")
    lines.extend(
        [
            "",
            "## Plots",
            "",
            "- `utility_vs_budget.png`",
            "- `utility_heatmap.png`",
            "- `method_rank_heatmap.png`",
            "- `mosaic_gain_vs_random.png`",
            "- `metric_*.png`",
            "- `cluster_distribution_budget_*.png`",
            "- `pilot_scaling_observed.png`",
            "- `ranking_importance_by_cluster.png`",
            "- `mosaic_trace_budget_*.png`",
            "- `training_val_loss_curves.png`",
            "- `training_best_val_loss.png`",
        ]
    )
    (out_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    out_dir = ensure_dir(args.out_dir)
    results = pd.read_csv(args.results)
    summary = summarize_results(results)
    write_json(summary, out_dir / "summary.json")
    write_markdown(summary, out_dir)
    plot_utility(results, out_dir)
    plot_utility_heatmaps(results, out_dir)
    plot_mosaic_vs_random(results, out_dir)

    metric_breakdown = load_optional_csv(args.metric_breakdown)
    if metric_breakdown is not None:
        plot_metrics(metric_breakdown, out_dir)

    distribution = load_optional_csv(args.cluster_distribution)
    if distribution is not None:
        plot_cluster_distribution(distribution, out_dir)

    pilot_results = load_optional_csv(args.pilot_results)
    if pilot_results is not None:
        plot_pilot_scaling(pilot_results, out_dir)

    ranked_pool = load_optional_csv(args.ranked_pool)
    if ranked_pool is not None:
        plot_ranking_distribution(ranked_pool, out_dir)

    plot_mosaic_traces(args.selections_dir, out_dir)
    plot_training_curves(args.checkpoint_dir, out_dir)

    print(json.dumps({"out_dir": str(out_dir), "summary": summary}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
