"""Clip-level feature extraction."""
