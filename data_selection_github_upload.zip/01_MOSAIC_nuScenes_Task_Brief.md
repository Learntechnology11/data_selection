# 任务书：在 nuScenes 上复现 MOSAIC 数据选择算法

## 1. 项目目标

本项目目标是在 nuScenes 数据集上复现论文 **Scaling-Aware Data Selection for End-to-End Autonomous Driving Systems** 中的核心算法 **MOSAIC**。

需要特别注意：本项目不是完全复现论文中的 OpenScene/Navtrain/NAVSIM/Hydra-MDP/EPDMS 实验配置，而是把 MOSAIC 的核心机制迁移到 nuScenes 上，验证其作为自动驾驶数据选择/数据瘦身/核心集构建算法的有效性。

## 2. MOSAIC 核心思想

MOSAIC 的核心流程是：

```text
1. 将数据池 D_pool 划分为若干 domain/cluster；
2. 在每个 cluster 内根据样本重要性排序；
3. 针对每个 cluster 做小规模 pilot 训练，估计加入该 cluster 数据后 validation utility 的提升；
4. 对每个 cluster 拟合 scaling law；
5. 在给定总预算 B 下，每次选择边际收益最大的 cluster；
6. 从该 cluster 的 ranked list 中取下一个样本；
7. 直到选满预算 B。
```

## 3. 为什么不能直接照搬论文实验

原论文设置：

| 项目 | 原论文设置 |
|---|---|
| 数据集 | OpenScene / Navtrain |
| 评测框架 | NAVSIM |
| 模型 | Hydra-MDP |
| 指标 | EPDMS |
| 样本单位 | 10 秒 virtual clip |
| domain | 地理位置或 caption cluster |

当前项目设置：

| 项目 | 本项目设置 |
|---|---|
| 数据集 | nuScenes v1.0-mini / v1.0-trainval |
| 评测框架 | 自定义 open-loop planning evaluation |
| 模型 | 轻量 ego trajectory planner，后续可升级 |
| 指标 | ADE/FDE/heading/collision/off-road/jerk 组合 utility |
| 样本单位 | 10 秒 virtual clip |
| domain | location / metadata+motion+agent-density cluster |

因此，本项目要复现的是：

```text
MOSAIC 的数据选择机制 + scaling-aware cluster allocation
```

而不是强行复现原论文中的 EPDMS 数值。

## 4. 第一阶段最小可运行闭环

第一阶段只要求 nuScenes mini 跑通：

```text
nuScenes v1.0-mini
  -> build 10s clips
  -> split base_train / pool / val
  -> extract clip features
  -> cluster pool
  -> train base planner
  -> rank pool clips
  -> run pilot experiments
  -> fit scaling laws
  -> select with MOSAIC
  -> compare with baselines
```

## 5. 样本单位定义

nuScenes 的 scene 约 20 秒。每个 scene 尽量切成两个非重叠 10 秒 clip。

每个 clip 至少包含：

```text
clip_id
scene_token
log_token
location
description
start_sample_token
end_sample_token
sample_tokens
num_samples
```

## 6. 数据划分

### 6.1 v1.0-mini

建议：

```text
D_train_base = 20%
D_pool       = 60%
D_val        = 20%
```

使用固定 seed，保证可复现。

### 6.2 v1.0-trainval

优先使用官方 train/val scene split。

```text
train scenes -> base_train + pool
val scenes   -> val
```

## 7. 模型定义

第一阶段不要追求复杂模型。先实现轻量 planner：

```text
输入：过去若干帧 ego state，例如 x, y, yaw, speed
输出：未来 ego trajectory，例如未来 3s 或 6s 的 x/y offsets
模型：MLPPlanner 或 GRUPlanner
loss：SmoothL1Loss 或 L1Loss
```

模型只需要足够稳定地提供样本误差和 validation utility，用于验证数据选择算法。

## 8. utility 定义

nuScenes 没有 EPDMS，因此定义一个 higher-is-better 的 open-loop planning utility。

原始指标：

```text
ADE: lower is better
FDE: lower is better
heading_error: lower is better
collision_proxy: lower is better
offroad_proxy: lower is better
jerk: lower is better
```

转换为 utility：

```text
U = 100
    - w_ade * normalized_ADE
    - w_fde * normalized_FDE
    - w_heading * normalized_heading_error
    - w_collision * normalized_collision_proxy
    - w_offroad * normalized_offroad_proxy
    - w_jerk * normalized_jerk
```

默认权重：

```yaml
utility_weights:
  ade: 30
  fde: 30
  heading_error: 10
  collision_proxy: 15
  offroad_proxy: 10
  jerk: 5
```

如果某个指标不可用，例如 off-road proxy 暂时无法实现，则自动跳过该指标并重新归一化剩余权重。

## 9. 输出结果

最终需要输出：

```text
outputs/results/main_results.csv
outputs/results/metric_breakdown.csv
outputs/results/cluster_distribution.csv
outputs/results/scaling_params.json
outputs/results/selection_traces/
outputs/results/plots/
```

`main_results.csv` 字段：

```text
dataset_version
method
budget
seed
utility
ade
fde
heading_error
collision_proxy
offroad_proxy
jerk
```

## 10. 对比方法

至少实现：

```text
Random
Coreset
Ranking-only
Cluster-only
Uncertainty 或 MC-dropout uncertainty
MOSAIC
```

如果 deterministic planner 暂时不能提供 uncertainty，不要把 prediction error 冒充 uncertainty。可以先实现 MC dropout，或者把该方法明确命名为 `error_ranking`。

## 11. 最终验收标准

当以下命令可以跑通时，认为第一阶段完成：

```bash
python scripts/run_selection_experiments.py \
    --config configs/mosaic_nuscenes_mini.yaml \
    --budgets 20 40 80 \
    --methods random coreset ranking_only mosaic \
    --seeds 0 2025 424242
```

并且能够生成：

```text
outputs/results/main_results.csv
outputs/selections/mosaic_budget_20.csv
outputs/selections/mosaic_budget_40.csv
outputs/selections/mosaic_budget_80.csv
outputs/scaling/scaling_params.json
```
