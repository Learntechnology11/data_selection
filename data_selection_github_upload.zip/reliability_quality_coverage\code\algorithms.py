"""Coreset algorithms adapted to Fashion-MNIST.

Fashion-MNIST labels are treated as pre-clustered domains. The DriveCore-style
selector uses:

- image representation matching in a whitened feature space,
- Fisher-normalized proxy gradients,
- per-class coverage constraints,
- representation non-redundancy through farthest/prototype selection.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import math
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

import numpy as np


@dataclass
class DatasetArrays:
    """In-memory image classification arrays."""

    images: np.ndarray
    labels: np.ndarray
    indices: np.ndarray


@dataclass
class CoresetResult:
    """Selected indices and diagnostics."""

    method: str
    budget_name: str
    selected_indices: List[int]
    weights: List[float]
    diagnostics: Dict[str, Any]


def random_coreset(data: DatasetArrays, budget: int, seed: int) -> CoresetResult:
    """Random subset baseline."""

    rng = np.random.default_rng(seed)
    selected = rng.choice(data.indices, size=budget, replace=False).astype(int).tolist()
    return CoresetResult("random", str(budget), selected, [1.0] * len(selected), {})


def class_balanced_coreset(data: DatasetArrays, budget: int, seed: int) -> CoresetResult:
    """Allocate nearly equal samples per class."""

    rng = np.random.default_rng(seed)
    by_class = _indices_by_class(data.labels, data.indices)
    quota = _largest_remainder({str(k): len(v) for k, v in by_class.items()}, budget, {str(k): len(v) for k, v in by_class.items()}, alpha=0.0)
    selected: List[int] = []
    for cls, indices in sorted(by_class.items()):
        take = int(quota.get(str(cls), 0))
        if take <= 0:
            continue
        chosen = rng.choice(indices, size=min(take, len(indices)), replace=False)
        selected.extend(int(idx) for idx in chosen)
    if len(selected) < budget:
        remaining = [int(idx) for idx in data.indices if int(idx) not in set(selected)]
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])
    return CoresetResult("class_balanced", str(budget), selected[:budget], [1.0] * min(budget, len(selected)), {"quota": quota})


def drivecore_coreset(
    data: DatasetArrays,
    features: np.ndarray,
    budget: int,
    seed: int,
    fisher_rank: int = 64,
    candidate_multiplier: int = 8,
) -> CoresetResult:
    """DriveCore-style coreset for labeled image data."""

    rng = np.random.default_rng(seed)
    labels = data.labels.astype(int)
    z = whiten_reduce(features, min(128, features.shape[1]), eps=1e-6)
    grad_proxy = build_gradient_proxy(z, labels, out_dim=128, seed=seed)
    grad_f = fisher_normalize(grad_proxy, rank=min(fisher_rank, grad_proxy.shape[1]), reg=1e-3)
    class_onehot = np.eye(10, dtype=np.float64)[labels]
    psi = np.concatenate([z, grad_f, 0.75 * class_onehot], axis=1)
    psi = psi / np.maximum(np.linalg.norm(psi, axis=1, keepdims=True), 1e-12)

    by_class = _indices_by_class(labels, np.arange(len(labels)))
    caps = {str(cls): len(local_indices) for cls, local_indices in by_class.items()}
    quotas = _largest_remainder({str(cls): len(local_indices) for cls, local_indices in by_class.items()}, budget, caps, alpha=0.7)

    local_orders: Dict[int, List[int]] = {}
    local_gains: Dict[int, List[float]] = {}
    local_weights: Dict[int, float] = {}
    for cls, local_indices in sorted(by_class.items()):
        quota = int(quotas.get(str(cls), 0))
        order, gains, weights = _select_within_class(
            local_indices,
            quota,
            psi,
            z,
            labels,
            rng,
            candidate_multiplier=candidate_multiplier,
        )
        local_orders[cls] = order
        local_gains[cls] = gains
        local_weights.update(weights)

    selected_local = _merge_class_orders(local_orders, local_gains, budget)
    selected_indices = [int(data.indices[local_idx]) for local_idx in selected_local]
    weights = [float(local_weights.get(local_idx, 1.0)) for local_idx in selected_local]
    weights = _normalize_weights(weights)
    diagnostics = {
        "quotas": quotas,
        "class_counts": dict(Counter(int(labels[idx]) for idx in selected_local)),
        "feature_dim": int(features.shape[1]),
        "psi_dim": int(psi.shape[1]),
    }
    return CoresetResult("drivecore", str(budget), selected_indices, weights, diagnostics)


def image_feature_matrix(images: np.ndarray) -> np.ndarray:
    """Extract deterministic lightweight image features."""

    arr = images.astype(np.float64)
    if arr.max() > 1.0:
        arr = arr / 255.0
    rows = []
    h, w = arr.shape[1], arr.shape[2]
    yy, xx = np.mgrid[0:h, 0:w]
    xx = xx / max(w - 1, 1)
    yy = yy / max(h - 1, 1)
    for image in arr:
        flat = image.reshape(-1)
        hist, _ = np.histogram(flat, bins=16, range=(0.0, 1.0), density=True)
        mass = float(flat.sum()) + 1e-9
        cx = float((image * xx).sum() / mass)
        cy = float((image * yy).sum() / mass)
        row_mean = image.mean(axis=1)
        col_mean = image.mean(axis=0)
        center = image[h // 4 : 3 * h // 4, w // 4 : 3 * w // 4]
        border_mask = np.ones_like(image, dtype=bool)
        border_mask[h // 4 : 3 * h // 4, w // 4 : 3 * w // 4] = False
        stats = [
            float(flat.mean()),
            float(flat.std()),
            float(flat.min()),
            float(flat.max()),
            float(np.quantile(flat, 0.25)),
            float(np.quantile(flat, 0.75)),
            cx,
            cy,
            float(center.mean()),
            float(image[border_mask].mean()),
            float(np.abs(np.diff(image, axis=0)).mean()),
            float(np.abs(np.diff(image, axis=1)).mean()),
        ]
        pooled = _avg_pool(image, 7).reshape(-1)
        rows.append(np.concatenate([np.asarray(stats), hist, row_mean[::2], col_mean[::2], pooled]))
    return np.vstack(rows).astype(np.float64)


def whiten_reduce(matrix: np.ndarray, dim: int, eps: float = 1e-6) -> np.ndarray:
    """PCA whitening with dimension cap."""

    arr = np.asarray(matrix, dtype=np.float64)
    centered = arr - arr.mean(axis=0, keepdims=True)
    if centered.shape[0] <= 1:
        return centered
    _, s, vt = np.linalg.svd(centered, full_matrices=False)
    rank = max(1, min(dim, vt.shape[0], centered.shape[0] - 1))
    components = vt[:rank].T
    variances = (s[:rank] ** 2) / max(centered.shape[0] - 1, 1)
    return centered @ components / np.sqrt(variances[None, :] + eps)


def build_gradient_proxy(z: np.ndarray, labels: np.ndarray, out_dim: int, seed: int) -> np.ndarray:
    """Approximate classification-head gradients without training a teacher."""

    labels = labels.astype(int)
    class_means = np.vstack([
        z[labels == cls].mean(axis=0) if np.any(labels == cls) else np.zeros(z.shape[1])
        for cls in range(10)
    ])
    logits = z @ class_means.T
    logits = logits - logits.max(axis=1, keepdims=True)
    probs = np.exp(logits)
    probs = probs / np.maximum(probs.sum(axis=1, keepdims=True), 1e-12)
    onehot = np.eye(10)[labels]
    residual = probs - onehot
    grad_blocks = [residual[:, cls : cls + 1] * z for cls in range(10)]
    raw = np.concatenate(grad_blocks, axis=1)
    rng = np.random.default_rng(seed + 104729)
    proj = rng.normal(0.0, 1.0 / math.sqrt(out_dim), size=(raw.shape[1], out_dim))
    return raw @ proj


def fisher_normalize(g: np.ndarray, rank: int, reg: float) -> np.ndarray:
    """Top-rank empirical Fisher normalization."""

    centered = g - g.mean(axis=0, keepdims=True)
    cov = centered.T @ centered / max(centered.shape[0], 1)
    vals, vecs = np.linalg.eigh(cov)
    order = np.argsort(vals)[::-1][: max(1, min(rank, len(vals)))]
    vals_q = np.maximum(vals[order], 0.0)
    vecs_q = vecs[:, order]
    projected = centered @ vecs_q
    return projected / np.sqrt(vals_q[None, :] + reg)


def save_coreset_result(result: CoresetResult, output_dir: Path, budget_name: str) -> Path:
    """Save selected indices and weights as JSON."""

    import json

    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"selected_{result.method}_{budget_name}.json"
    rows = [
        {"index": int(index), "weight": float(weight), "rank": rank}
        for rank, (index, weight) in enumerate(zip(result.selected_indices, result.weights), start=1)
    ]
    with path.open("w", encoding="utf-8") as f:
        json.dump({"method": result.method, "budget": budget_name, "samples": rows, "diagnostics": result.diagnostics}, f, indent=2)
    return path


def budget_to_count(budget: float, n: int) -> int:
    """Convert ratio/count budget to sample count."""

    if budget <= 1.0:
        return int(math.floor(budget * n))
    return int(budget)


def budget_name(budget: float) -> str:
    """Format budget for filenames."""

    if budget <= 1.0:
        return str(int(round(budget * 100)))
    return str(int(budget))


def _select_within_class(
    local_indices: Sequence[int],
    quota: int,
    psi: np.ndarray,
    z: np.ndarray,
    labels: np.ndarray,
    rng: np.random.Generator,
    candidate_multiplier: int,
) -> tuple[List[int], List[float], Dict[int, float]]:
    if quota <= 0:
        return [], [], {}
    local_indices = list(local_indices)
    class_center = psi[local_indices].mean(axis=0)
    difficulty = np.linalg.norm(z[local_indices] - z[local_indices].mean(axis=0, keepdims=True), axis=1)
    candidate_count = min(len(local_indices), max(quota * candidate_multiplier, quota + 16))
    candidate_positions = np.argsort(difficulty)[::-1][:candidate_count]
    candidates = [local_indices[int(pos)] for pos in candidate_positions]
    prototypes = _prototype_indices(local_indices, z, min(quota, len(local_indices)))
    candidates = list(dict.fromkeys([*candidates, *prototypes]))

    selected: List[int] = []
    gains: List[float] = []
    weights: Dict[int, float] = {}
    residual = class_center.copy()
    while len(selected) < min(quota, len(local_indices)):
        best_idx = None
        best_gain = -float("inf")
        for idx in candidates:
            if idx in selected:
                continue
            alignment = float(np.dot(residual, psi[idx]) ** 2 / (np.dot(psi[idx], psi[idx]) + 1e-8))
            redundancy = max((_cosine(z[idx], z[j]) for j in selected), default=0.0)
            gain = alignment - 0.25 * max(0.0, redundancy)
            if gain > best_gain:
                best_idx = idx
                best_gain = gain
        if best_idx is None:
            leftovers = [idx for idx in local_indices if idx not in selected]
            if not leftovers:
                break
            best_idx = int(rng.choice(leftovers))
            best_gain = 0.0
        selected.append(best_idx)
        selected_psi = psi[selected]
        w = _ridge_nnls(selected_psi, class_center)
        weights = {idx: float(w[pos]) for pos, idx in enumerate(selected)}
        residual = class_center - selected_psi.T @ w
        gains.append(float(best_gain))
    return selected, gains, weights


def _merge_class_orders(local_orders: Mapping[int, Sequence[int]], local_gains: Mapping[int, Sequence[float]], budget: int) -> List[int]:
    positions = {cls: 0 for cls in local_orders}
    selected: List[int] = []
    while len(selected) < budget:
        best_cls = None
        best_score = -float("inf")
        for cls, order in local_orders.items():
            pos = positions[cls]
            if pos >= len(order):
                continue
            gains = local_gains.get(cls, [])
            gain = float(gains[pos]) if pos < len(gains) else 0.0
            score = gain / float(pos + 1)
            if score > best_score:
                best_cls = cls
                best_score = score
        if best_cls is None:
            break
        pos = positions[best_cls]
        selected.append(int(local_orders[best_cls][pos]))
        positions[best_cls] = pos + 1
    return selected


def _ridge_nnls(selected_psi: np.ndarray, target: np.ndarray) -> np.ndarray:
    gram = selected_psi @ selected_psi.T + 1e-3 * np.eye(selected_psi.shape[0])
    rhs = selected_psi @ target
    try:
        weights = np.linalg.solve(gram, rhs)
    except np.linalg.LinAlgError:
        weights = np.linalg.lstsq(gram, rhs, rcond=None)[0]
    weights = np.maximum(weights, 0.0)
    if weights.sum() <= 1e-12:
        weights = np.ones(selected_psi.shape[0]) / max(selected_psi.shape[0], 1)
    return weights


def _normalize_weights(weights: Sequence[float]) -> List[float]:
    arr = np.asarray(weights, dtype=np.float64)
    if arr.size == 0:
        return []
    mean = float(arr.mean())
    if mean <= 1e-12:
        return [1.0] * len(arr)
    return (arr / mean).tolist()


def _prototype_indices(indices: Sequence[int], z: np.ndarray, count: int) -> List[int]:
    if not indices:
        return []
    indices = list(indices)
    count = min(count, len(indices))
    arr = z[indices]
    center = arr.mean(axis=0)
    first = int(np.argmin(np.linalg.norm(arr - center[None, :], axis=1)))
    selected_pos = [first]
    while len(selected_pos) < count:
        selected_arr = arr[selected_pos]
        dist = np.min(((arr[:, None, :] - selected_arr[None, :, :]) ** 2).sum(axis=2), axis=1)
        for pos in selected_pos:
            dist[pos] = -1.0
        selected_pos.append(int(np.argmax(dist)))
    return [indices[pos] for pos in selected_pos]


def _indices_by_class(labels: np.ndarray, indices: np.ndarray) -> Dict[int, List[int]]:
    out: Dict[int, List[int]] = defaultdict(list)
    for local_idx, label in zip(indices, labels):
        out[int(label)].append(int(local_idx))
    return dict(out)


def _largest_remainder(weights: Mapping[str, int], target: int, caps: Mapping[str, int], alpha: float) -> Dict[str, int]:
    raw_weights = {key: max(float(value), 0.0) ** alpha for key, value in weights.items()}
    total = sum(raw_weights.values())
    if total <= 1e-12:
        raw = {key: target / max(len(raw_weights), 1) for key in raw_weights}
    else:
        raw = {key: target * value / total for key, value in raw_weights.items()}
    quotas = {key: min(int(caps.get(key, 0)), int(math.floor(value))) for key, value in raw.items()}
    current = sum(quotas.values())
    addable = sorted(raw, key=lambda key: raw[key] - math.floor(raw[key]), reverse=True)
    while current < target:
        changed = False
        for key in addable:
            if current >= target:
                break
            if quotas[key] >= int(caps.get(key, 0)):
                continue
            quotas[key] += 1
            current += 1
            changed = True
        if not changed:
            break
    return quotas


def _avg_pool(image: np.ndarray, out_size: int) -> np.ndarray:
    h, w = image.shape
    pooled = np.zeros((out_size, out_size), dtype=np.float64)
    for y in range(out_size):
        y0 = int(round(y * h / out_size))
        y1 = int(round((y + 1) * h / out_size))
        for x in range(out_size):
            x0 = int(round(x * w / out_size))
            x1 = int(round((x + 1) * w / out_size))
            pooled[y, x] = image[y0:y1, x0:x1].mean()
    return pooled


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(np.linalg.norm(a) * np.linalg.norm(b))
    if denom <= 1e-12:
        return 0.0
    return float(np.dot(a, b) / denom)

