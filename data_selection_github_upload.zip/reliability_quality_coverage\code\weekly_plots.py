"""Visualizations for the V0/V1/V2 weekly research study."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from sklearn.decomposition import PCA


def plot_joint_embedding(
    geometry: np.ndarray,
    labels: np.ndarray,
    selected: Sequence[int],
    rejected: np.ndarray,
    true_noise: np.ndarray,
    path: Path,
    title: str,
) -> None:
    """Show full data, noise/rejected points, and selected samples."""

    xy = PCA(n_components=2, random_state=0).fit_transform(geometry)
    selected_mask = np.zeros(len(labels), dtype=bool)
    selected_mask[list(selected)] = True
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(7, 5.8))
    plt.scatter(xy[:, 0], xy[:, 1], c=labels, cmap="tab10", s=7, alpha=0.16)
    if np.any(true_noise):
        plt.scatter(xy[true_noise, 0], xy[true_noise, 1], marker="x", c="tab:red", s=20, label="true noise")
    if np.any(rejected):
        plt.scatter(xy[rejected, 0], xy[rejected, 1], facecolors="none", edgecolors="tab:orange", s=22, label="rejected")
    plt.scatter(
        xy[selected_mask, 0],
        xy[selected_mask, 1],
        facecolors="none",
        edgecolors="black",
        linewidths=0.8,
        s=30,
        label="selected",
    )
    plt.title(title)
    plt.xlabel("joint geometry PC1")
    plt.ylabel("joint geometry PC2")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(path, dpi=170)
    plt.close()


def plot_coverage_cdf(curves: Mapping[str, Sequence[float]], path: Path, title: str) -> None:
    """Plot empirical CDFs of nearest-selected distances."""

    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6.7, 4.6))
    for name, values in curves.items():
        arr = np.sort(np.asarray(values, dtype=np.float64))
        if not len(arr):
            continue
        y = np.arange(1, len(arr) + 1) / len(arr)
        plt.plot(arr, y, label=name)
    plt.xlabel("nearest selected distance")
    plt.ylabel("empirical CDF")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=170)
    plt.close()


def plot_allocation_trajectory(
    trajectory: Sequence[Mapping[str, Any]],
    path: Path,
    title: str,
) -> None:
    """Plot cumulative selected counts for every class."""

    if not trajectory:
        return
    steps = [int(row["step"]) for row in trajectory]
    counts = {cls: 0 for cls in range(10)}
    series = {cls: [] for cls in range(10)}
    for row in trajectory:
        counts[int(row["class"])] += 1
        for cls in range(10):
            series[cls].append(counts[cls])
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(7.5, 5.0))
    for cls in range(10):
        plt.plot(steps, series[cls], label=str(cls), linewidth=1.2)
    plt.xlabel("global selection step")
    plt.ylabel("cumulative class budget")
    plt.title(title)
    plt.legend(title="class", ncol=5, fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=170)
    plt.close()


def plot_class_budget(
    full_labels: np.ndarray,
    clean_mask: np.ndarray,
    selections: Mapping[str, Sequence[int]],
    path: Path,
) -> None:
    """Compare original, gate-surviving, and selected class counts."""

    names = ["original", "after_gate", *selections.keys()]
    rows = [
        np.bincount(full_labels.astype(int), minlength=10),
        np.bincount(full_labels[clean_mask].astype(int), minlength=10),
    ]
    rows.extend(np.bincount(full_labels[list(indices)].astype(int), minlength=10) for indices in selections.values())
    values = np.asarray(rows, dtype=np.float64)
    x = np.arange(10)
    width = min(0.82 / len(names), 0.14)
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(10, 4.8))
    for idx, name in enumerate(names):
        offset = (idx - (len(names) - 1) / 2.0) * width
        plt.bar(x + offset, values[idx], width=width, label=name)
    plt.xticks(x, range(10))
    plt.xlabel("class")
    plt.ylabel("sample count")
    plt.title("Unequal class sizes and dynamically selected budgets")
    plt.legend(fontsize=7, ncol=2)
    plt.tight_layout()
    plt.savefig(path, dpi=170)
    plt.close()


def plot_reliability_distance(
    reliability: np.ndarray,
    nearest_distance: np.ndarray,
    selected: Sequence[int],
    true_noise: np.ndarray,
    path: Path,
    title: str,
) -> None:
    """Plot reliability against current coverage distance."""

    selected_mask = np.zeros(len(reliability), dtype=bool)
    selected_mask[list(selected)] = True
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6.5, 5.0))
    plt.scatter(reliability, nearest_distance, s=8, alpha=0.2, label="pool")
    if np.any(true_noise):
        plt.scatter(reliability[true_noise], nearest_distance[true_noise], marker="x", s=18, c="tab:red", label="true noise")
    plt.scatter(
        reliability[selected_mask],
        nearest_distance[selected_mask],
        facecolors="none",
        edgecolors="black",
        s=28,
        label="selected",
    )
    plt.xlabel("reliability mass")
    plt.ylabel("nearest selected distance")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=170)
    plt.close()


def plot_failure_grid(
    images: np.ndarray,
    labels: np.ndarray,
    reliability: np.ndarray,
    indices: Sequence[int],
    path: Path,
    title: str,
    limit: int = 48,
) -> None:
    """Plot V1-only edge samples that V2 avoided or delayed."""

    chosen = list(indices)[:limit]
    if not chosen:
        return
    cols = 8
    rows = int(np.ceil(len(chosen) / cols))
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 1.25, rows * 1.45))
    axes_arr = np.asarray(axes).reshape(-1)
    for ax in axes_arr:
        ax.axis("off")
    for ax, idx in zip(axes_arr, chosen):
        ax.imshow(images[idx], cmap="gray")
        ax.set_title(f"y={int(labels[idx])}\nr={reliability[idx]:.2f}", fontsize=7)
        ax.axis("off")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=170)
    plt.close(fig)


def plot_noise_retention(rows: Sequence[Mapping[str, Any]], path: Path) -> None:
    """Plot selected noise rate by method and budget."""

    labels = [f"{row['method']}_{row['budget']}" for row in rows]
    values = [float(row.get("selected_noise_rate", 0.0)) for row in rows]
    plt = _pyplot()
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(max(7, len(labels) * 0.55), 4.5))
    plt.bar(labels, values)
    plt.xticks(rotation=35, ha="right")
    plt.ylabel("selected noise rate")
    plt.title("Noise remaining in each coreset")
    plt.tight_layout()
    plt.savefig(path, dpi=170)
    plt.close()


def class_counts(indices: Sequence[int], labels: np.ndarray) -> dict[str, int]:
    """Return JSON-friendly class counts."""

    return {str(cls): int(count) for cls, count in Counter(int(labels[idx]) for idx in indices).items()}


def _pyplot():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt


__all__ = [
    "class_counts",
    "plot_allocation_trajectory",
    "plot_class_budget",
    "plot_coverage_cdf",
    "plot_failure_grid",
    "plot_joint_embedding",
    "plot_noise_retention",
    "plot_reliability_distance",
]
