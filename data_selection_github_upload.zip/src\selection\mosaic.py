from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from src.selection.scaling import marginal_gain
from src.utils.io import ensure_dir, write_csv


def select_mosaic(
    ranked_pool: pd.DataFrame,
    scaling_params: dict[str, dict[str, Any]],
    budget: int,
    step: int = 1,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if budget <= 0:
        raise ValueError("budget must be positive")
    if budget > len(ranked_pool):
        raise ValueError("budget B cannot be larger than pool size")
    required = {"clip_id", "cluster_id", "importance_score", "rank_within_cluster"}
    missing = required - set(ranked_pool.columns)
    if missing:
        raise ValueError(f"ranked_pool missing columns: {sorted(missing)}")

    pool_by_cluster = {
        str(cluster_id): frame.sort_values("rank_within_cluster").reset_index(drop=True)
        for cluster_id, frame in ranked_pool.groupby("cluster_id", sort=True)
    }
    counts = {cluster_id: 0 for cluster_id in pool_by_cluster}
    selected_rows: list[pd.Series] = []
    trace_rows: list[dict[str, Any]] = []
    selected_clip_ids: set[str] = set()

    global_fallback = ranked_pool.sort_values(
        ["importance_score", "clip_id"], ascending=[False, True]
    ).reset_index(drop=True)

    for step_id in range(1, budget + 1):
        best_cluster = None
        best_gain = float("-inf")
        for cluster_id, frame in pool_by_cluster.items():
            current = counts[cluster_id]
            if current >= len(frame):
                continue
            params = scaling_params.get(cluster_id) or scaling_params.get(str(cluster_id))
            if not params:
                gain = 0.0
            else:
                gain = marginal_gain(
                    float(params.get("a", 0.0)),
                    float(params.get("tau", 1.0)),
                    current,
                    step=max(1, step),
                )
            if gain > best_gain:
                best_gain = gain
                best_cluster = cluster_id

        if best_cluster is None or best_gain <= 0:
            candidate = None
            for _, row in global_fallback.iterrows():
                if str(row["clip_id"]) not in selected_clip_ids:
                    candidate = row.copy()
                    best_cluster = str(row["cluster_id"])
                    best_gain = max(best_gain, 0.0)
                    break
            if candidate is None:
                break
        else:
            candidate = pool_by_cluster[best_cluster].iloc[counts[best_cluster]].copy()

        cluster_before = counts[str(best_cluster)]
        selected_clip_ids.add(str(candidate["clip_id"]))
        counts[str(best_cluster)] = cluster_before + 1
        candidate["selection_order"] = step_id
        candidate["method"] = "mosaic"
        candidate["budget"] = budget
        selected_rows.append(candidate)
        trace_rows.append(
            {
                "step_id": step_id,
                "selected_cluster_id": best_cluster,
                "selected_clip_id": candidate["clip_id"],
                "cluster_count_before": cluster_before,
                "cluster_count_after": counts[str(best_cluster)],
                "estimated_marginal_gain": best_gain,
            }
        )

    selected = pd.DataFrame(selected_rows)
    trace = pd.DataFrame(trace_rows)
    if len(selected) != budget:
        raise ValueError(f"MOSAIC selected {len(selected)} clips, expected {budget}")
    return selected, trace


def save_mosaic_outputs(
    selected: pd.DataFrame,
    trace: pd.DataFrame,
    budget: int,
    out_dir: str | Path,
) -> None:
    output_dir = ensure_dir(out_dir)
    write_csv(selected, output_dir / f"mosaic_budget_{budget}.csv")
    write_csv(trace, output_dir / f"mosaic_trace_budget_{budget}.csv")
