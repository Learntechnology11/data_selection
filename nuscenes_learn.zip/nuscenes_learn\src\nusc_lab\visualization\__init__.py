"""Visualization helpers for camera, lidar, radar, fusion, and maps."""

