# 00. 项目总览

`nuscenes_learn` 是一个 nuScenes 学习工程，重点不是从零实现深度学习框架，而是帮你把数据集先跑通、看懂、可视化出来，并理解它如何进入 3D detection 训练和评估。

工程默认假设服务器目录如下：

```text
parent_dir/
├── nuscenes_learn
└── nuscenes
    ├── maps
    ├── samples
    ├── sweeps
    └── v1.0-mini
```

因此，在 `nuscenes_learn` 内运行脚本时，默认 `--dataroot` 是 `../nuscenes`。如果你的数据在别处，所有脚本都支持显式传入：

```bash
python scripts/check_dataset.py --dataroot /data/sets/nuscenes --version v1.0-mini
```

## 学习目标

1. 理解 nuScenes 的文件目录和 13 张基础 JSON 表。
2. 会通过 token 查询 scene、sample、sample_data、annotation。
3. 会读取 camera、LiDAR、Radar 文件。
4. 会画 camera box、LiDAR BEV、Radar BEV 和投影图。
5. 理解 sensor -> ego -> global -> camera -> image 的坐标链路。
6. 理解 detection 10 类、官方 JSON 提交格式、mAP/NDS 指标。

## 快速检查

```bash
python scripts/check_dataset.py --version v1.0-mini
python scripts/list_scenes.py --version v1.0-mini
python scripts/inspect_sample.py --version v1.0-mini --sample-index 0
```

## 快速可视化

```bash
python scripts/visualize_sample.py --version v1.0-mini --sample-index 0 --mode camera-mosaic --with-boxes
python scripts/visualize_lidar_bev.py --version v1.0-mini --sample-index 0 --with-boxes
python scripts/visualize_radar_bev.py --version v1.0-mini --sample-index 0 --radar all
```

