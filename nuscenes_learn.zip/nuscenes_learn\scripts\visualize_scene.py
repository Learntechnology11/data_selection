from __future__ import annotations

import argparse
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, get_scene, load_nuscenes
from nusc_lab.visualization.maps import plot_ego_trajectory


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize scene-level information.")
    add_common_args(parser)
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--scene-index", type=int, default=0)
    parser.add_argument("--show-map", action="store_true", help="Reserved for map expansion overlays; trajectory is always plotted.")
    parser.add_argument("--out", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        scene = get_scene(nusc, args.scene_name, args.scene_index)
    except (NuScenesLoadError, KeyError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    out = resolve_output_path(cfg.output_dir, args.out, f"{scene['name']}_ego_trajectory.png")
    if args.show_map:
        print("Map raster/vector overlay depends on map expansion files; plotting ego trajectory now.")
    plot_ego_trajectory(nusc, scene, save_path=out)
    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

