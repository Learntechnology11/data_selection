# References

优先参考：

1. nuScenes official website。
2. nuScenes official devkit GitHub。
3. nuScenes schema documentation。
4. nuScenes official paper。
5. nuScenes detection README。
6. MMDetection3D nuScenes dataset guide。
7. 用户提供的 `nuscenes的相关博客.docx`。
8. 用户提供的 `nuscenes数据集文档.md`。

本工程文档以官方定义为准，博客和工程实践文章作为辅助理解材料。

