from __future__ import annotations

import argparse
import sys

import matplotlib.pyplot as plt

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, get_scene, iter_scene_samples, load_nuscenes, scene_location
from nusc_lab.utils.io import write_json
from nusc_lab.visualization.camera import render_camera_mosaic
from nusc_lab.visualization.lidar import render_lidar_bev
from nusc_lab.visualization.maps import plot_ego_trajectory
from nusc_lab.visualization.radar import render_radar_bev


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export visualizations for a scene.")
    add_common_args(parser)
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--scene-index", type=int, default=0)
    parser.add_argument("--max-samples", type=int, default=None, help="Limit exported samples.")
    parser.add_argument("--with-boxes", action="store_true")
    parser.add_argument("--out", default=None, help="Output directory.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        scene = get_scene(nusc, args.scene_name, args.scene_index)
    except (NuScenesLoadError, KeyError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    out_dir = resolve_output_path(cfg.output_dir, args.out, scene["name"], make_parent=False)
    out_dir.mkdir(parents=True, exist_ok=True)
    summary = {
        "scene": scene["name"],
        "description": scene["description"],
        "location": scene_location(nusc, scene),
        "nbr_samples": scene["nbr_samples"],
        "version": cfg.version,
    }
    write_json(out_dir / "metadata.json", summary)
    plot_ego_trajectory(nusc, scene, save_path=out_dir / "ego_trajectory.png")
    plt.close("all")

    for idx, sample in enumerate(iter_scene_samples(nusc, scene)):
        if args.max_samples is not None and idx >= args.max_samples:
            break
        render_camera_mosaic(nusc, sample, with_boxes=args.with_boxes, save_path=out_dir / f"sample_{idx:03d}_camera_mosaic.png")
        plt.close("all")
        render_lidar_bev(nusc, sample, with_boxes=args.with_boxes, save_path=out_dir / f"sample_{idx:03d}_lidar_bev.png")
        plt.close("all")
        render_radar_bev(nusc, sample, with_boxes=args.with_boxes, save_path=out_dir / f"sample_{idx:03d}_radar_bev.png")
        plt.close("all")
        print(f"exported sample {idx:03d}")

    print(f"Wrote scene export: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

