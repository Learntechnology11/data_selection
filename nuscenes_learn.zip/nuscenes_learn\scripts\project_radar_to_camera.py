from __future__ import annotations

import argparse
import sys

import matplotlib.pyplot as plt
import numpy as np

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, get_sample_by_index_or_token, load_nuscenes
from nusc_lab.schema import RADAR_CHANNELS
from nusc_lab.sensors import load_image, load_radar_points_from_sample, radar_channels, sensor_file_path
from nusc_lab.transforms import project_sensor_points_to_camera


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Project radar points to a camera image.")
    add_common_args(parser)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--sample-token", default=None)
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--camera", default="CAM_FRONT")
    parser.add_argument("--radar", default="all")
    parser.add_argument("--color-by", choices=["depth", "rcs", "velocity"], default="depth")
    parser.add_argument("--disable-filters", action="store_true")
    parser.add_argument("--out", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        sample = get_sample_by_index_or_token(nusc, args.sample_index, args.sample_token, args.scene_name)
    except (NuScenesLoadError, KeyError, IndexError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    camera_token = sample["data"][args.camera]
    camera_sd = nusc.get("sample_data", camera_token)
    image = load_image(sensor_file_path(nusc, camera_sd))
    all_uv, all_color = [], []
    total, kept = 0, 0
    for channel in radar_channels(args.radar):
        radar_token = sample["data"][channel]
        points = load_radar_points_from_sample(nusc, sample, radar=channel, disable_filters=args.disable_filters)
        if points.size == 0:
            continue
        uv, depth, mask, _points_camera = project_sensor_points_to_camera(nusc, points[:, :3], radar_token, camera_token)
        if args.color_by == "rcs":
            color = points[:, 5]
        elif args.color_by == "velocity":
            color = np.linalg.norm(points[:, 8:10], axis=1)
        else:
            color = depth
        all_uv.append(uv[mask])
        all_color.append(color[mask])
        total += len(points)
        kept += int(mask.sum())

    fig, ax = plt.subplots(figsize=(12, 7))
    ax.imshow(image)
    if all_uv:
        uv_stack = np.vstack(all_uv)
        color_stack = np.concatenate(all_color)
        sc = ax.scatter(uv_stack[:, 0], uv_stack[:, 1], c=color_stack, s=18, cmap="turbo", alpha=0.85, edgecolors="black", linewidths=0.2)
        fig.colorbar(sc, ax=ax, label=args.color_by, fraction=0.03, pad=0.01)
    ax.set_title(f"Radar {args.radar} projected to {args.camera}")
    ax.axis("off")

    out = resolve_output_path(cfg.output_dir, args.out, f"sample_{args.sample_index:03d}_radar_on_{args.camera.lower()}.png")
    fig.savefig(out, dpi=180, bbox_inches="tight")
    print(f"Projected points: {kept}/{total}")
    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

