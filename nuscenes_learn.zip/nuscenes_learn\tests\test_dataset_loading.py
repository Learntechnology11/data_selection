from __future__ import annotations

from conftest import dataset_config

from nusc_lab.dataset import load_nuscenes


def test_dataset_loads():
    dataroot, version = dataset_config()
    nusc = load_nuscenes(dataroot, version)
    assert len(nusc.scene) > 0
    assert len(nusc.sample) > 0

