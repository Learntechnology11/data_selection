"""Human-readable schema metadata and detection-class helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Optional


BASE_TABLES = [
    "log",
    "scene",
    "sample",
    "sample_data",
    "ego_pose",
    "sensor",
    "calibrated_sensor",
    "instance",
    "category",
    "attribute",
    "visibility",
    "sample_annotation",
    "map",
]


TABLE_DESCRIPTIONS: Dict[str, str] = {
    "log": "A driving log from which scenes are extracted.",
    "scene": "A roughly 20-second driving segment.",
    "sample": "A 2 Hz annotated keyframe in a scene.",
    "sample_data": "A concrete sensor file: image, lidar point cloud, or radar point cloud.",
    "ego_pose": "Vehicle pose in the global map frame at a timestamp.",
    "sensor": "A sensor channel and modality definition.",
    "calibrated_sensor": "Sensor extrinsics relative to ego frame and camera intrinsics.",
    "instance": "A tracked physical object instance within a scene.",
    "category": "The raw nuScenes object taxonomy.",
    "attribute": "Mutable object state such as moving, parked, or standing.",
    "visibility": "Object visibility ratio in camera images.",
    "sample_annotation": "3D box annotation attached to a sample.",
    "map": "Raster and vector map metadata linked by log location.",
}


CAMERA_CHANNELS = [
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_FRONT_LEFT",
]

LIDAR_CHANNELS = ["LIDAR_TOP"]

RADAR_CHANNELS = [
    "RADAR_FRONT",
    "RADAR_FRONT_LEFT",
    "RADAR_FRONT_RIGHT",
    "RADAR_BACK_LEFT",
    "RADAR_BACK_RIGHT",
]

ALL_SENSOR_CHANNELS = CAMERA_CHANNELS + LIDAR_CHANNELS + RADAR_CHANNELS


DETECTION_CLASSES = [
    "car",
    "truck",
    "bus",
    "trailer",
    "construction_vehicle",
    "pedestrian",
    "motorcycle",
    "bicycle",
    "traffic_cone",
    "barrier",
]

DETECTION_RANGES = {
    "car": 50,
    "truck": 50,
    "bus": 50,
    "trailer": 50,
    "construction_vehicle": 50,
    "pedestrian": 40,
    "motorcycle": 40,
    "bicycle": 40,
    "traffic_cone": 30,
    "barrier": 30,
}


RAW_TO_DETECTION = {
    "vehicle.car": "car",
    "vehicle.truck": "truck",
    "vehicle.bus.bendy": "bus",
    "vehicle.bus.rigid": "bus",
    "vehicle.trailer": "trailer",
    "vehicle.construction": "construction_vehicle",
    "human.pedestrian.adult": "pedestrian",
    "human.pedestrian.child": "pedestrian",
    "human.pedestrian.construction_worker": "pedestrian",
    "human.pedestrian.police_officer": "pedestrian",
    "vehicle.motorcycle": "motorcycle",
    "vehicle.bicycle": "bicycle",
    "movable_object.trafficcone": "traffic_cone",
    "movable_object.barrier": "barrier",
}


@dataclass(frozen=True)
class SensorKind:
    """Grouped sensor channel metadata."""

    cameras: tuple[str, ...] = tuple(CAMERA_CHANNELS)
    lidars: tuple[str, ...] = tuple(LIDAR_CHANNELS)
    radars: tuple[str, ...] = tuple(RADAR_CHANNELS)


def raw_category_to_detection(raw_name: str) -> Optional[str]:
    """Map a raw nuScenes category to a 10-class detection label if possible."""
    return RAW_TO_DETECTION.get(raw_name)


def matches_class_filter(raw_name: str, class_filter: Iterable[str] | None) -> bool:
    """Return true when a raw or mapped category matches the user filter."""
    if not class_filter:
        return True
    filters = {item.strip() for item in class_filter if item.strip()}
    detection_name = raw_category_to_detection(raw_name)
    return raw_name in filters or (detection_name in filters if detection_name else False)

