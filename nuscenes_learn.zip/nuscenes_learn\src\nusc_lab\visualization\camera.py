"""Camera image and 3D box visualization."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import matplotlib.pyplot as plt
import numpy as np

from nusc_lab.annotations import filter_annotation_tokens
from nusc_lab.schema import CAMERA_CHANNELS, raw_category_to_detection
from nusc_lab.sensors import load_image, sensor_file_path
from nusc_lab.utils.colors import CATEGORY_COLORS, DEFAULT_BOX_COLOR


MOSAIC_CHANNELS = [
    "CAM_FRONT_LEFT",
    "CAM_FRONT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK_LEFT",
    "CAM_BACK",
    "CAM_BACK_RIGHT",
]


def draw_camera(
    ax,
    nusc,
    sample: dict,
    camera: str = "CAM_FRONT",
    with_boxes: bool = False,
    class_filter: Optional[Iterable[str]] = None,
) -> None:
    """Draw one camera image and optionally project visible 3D boxes."""
    sd_token = sample["data"][camera]
    sd = nusc.get("sample_data", sd_token)
    image = load_image(sensor_file_path(nusc, sd))
    ax.imshow(image)
    ax.set_title(camera)
    ax.axis("off")

    if not with_boxes:
        return

    selected = filter_annotation_tokens(nusc, sample, class_filter)
    _data_path, boxes, camera_intrinsic = nusc.get_sample_data(sd_token, selected_anntokens=selected)
    view = np.asarray(camera_intrinsic)
    for box in boxes:
        det_name = raw_category_to_detection(box.name)
        color = CATEGORY_COLORS.get(det_name or box.name, DEFAULT_BOX_COLOR)
        box.render(ax, view=view, normalize=True, colors=(color, color, color), linewidth=1.0)
        corners = box.corners()
        center = view @ corners[:, :1]
        if center[2, 0] > 0:
            center = center[:2, 0] / center[2, 0]
            ax.text(center[0], center[1], det_name or box.name.split(".")[-1], color=color, fontsize=6)


def render_camera(
    nusc,
    sample: dict,
    camera: str = "CAM_FRONT",
    with_boxes: bool = False,
    class_filter: Optional[Iterable[str]] = None,
    save_path: str | Path | None = None,
):
    """Render a single camera view."""
    if camera not in CAMERA_CHANNELS:
        raise ValueError(f"Unknown camera {camera!r}. Expected one of {CAMERA_CHANNELS}.")
    fig, ax = plt.subplots(figsize=(10, 6))
    draw_camera(ax, nusc, sample, camera=camera, with_boxes=with_boxes, class_filter=class_filter)
    if save_path:
        fig.savefig(save_path, dpi=180, bbox_inches="tight")
    return fig, ax


def render_camera_mosaic(
    nusc,
    sample: dict,
    with_boxes: bool = False,
    class_filter: Optional[Iterable[str]] = None,
    save_path: str | Path | None = None,
):
    """Render the six nuScenes cameras in a 2 x 3 mosaic."""
    fig, axes = plt.subplots(2, 3, figsize=(16, 8))
    for ax, channel in zip(axes.ravel(), MOSAIC_CHANNELS):
        draw_camera(ax, nusc, sample, camera=channel, with_boxes=with_boxes, class_filter=class_filter)
    fig.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=180, bbox_inches="tight")
    return fig, axes

