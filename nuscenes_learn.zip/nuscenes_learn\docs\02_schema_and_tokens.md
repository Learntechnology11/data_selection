# 02. Schema 与 Token 关系

nuScenes 的 JSON 表像一个小型关系数据库。每条记录都有 `token`，其他表通过外键 token 指向它。

## 13 张基础表

| 表 | 含义 |
| --- | --- |
| log | 一段采集日志，包含 location、date、vehicle 等信息 |
| scene | 约 20 秒驾驶片段 |
| sample | 2Hz 标注关键帧 |
| sample_data | 某个传感器在某一时刻的具体文件 |
| ego_pose | 某时刻自车在 global frame 下的位姿 |
| sensor | 传感器通道和 modality |
| calibrated_sensor | 传感器相对于 ego frame 的外参，相机还包含内参 |
| instance | 被跟踪的物体实例 |
| category | 原始类别体系 |
| attribute | moving、parked、standing 等属性 |
| visibility | 物体在相机中的可见比例 |
| sample_annotation | 挂在 sample 上的 3D box 标注 |
| map | 与 log location 相关的地图信息 |

## 核心链路

```text
log
 └── scene
      └── sample
           ├── sample_data: CAM_FRONT / LIDAR_TOP / RADAR_FRONT ...
           └── sample_annotation: 3D boxes

sample_data
 ├── calibrated_sensor
 │    └── sensor
 └── ego_pose

map
 └── log
```

## scene / sample / sample_data 的区别

`scene` 是一段约 20 秒的驾驶片段。`sample` 是这段片段里的 2Hz 标注关键帧。`sample_data` 是某个具体传感器文件，例如一张前视相机图像、一帧 LiDAR 点云或一帧 Radar PCD。

annotation 属于 `sample`，不属于单个相机或 LiDAR 文件，因为标注是综合所有传感器得到的全局 3D box。

## 常用查询

```python
scene = nusc.scene[0]
sample = nusc.get("sample", scene["first_sample_token"])
cam = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
ego = nusc.get("ego_pose", cam["ego_pose_token"])
calib = nusc.get("calibrated_sensor", cam["calibrated_sensor_token"])
anns = [nusc.get("sample_annotation", t) for t in sample["anns"]]
```

