from __future__ import annotations

from conftest import dataset_config

from nusc_lab.dataset import load_nuscenes


def test_basic_schema_links():
    dataroot, version = dataset_config()
    nusc = load_nuscenes(dataroot, version)
    scene = nusc.scene[0]
    sample = nusc.get("sample", scene["first_sample_token"])
    channel, sd_token = next(iter(sample["data"].items()))
    sample_data = nusc.get("sample_data", sd_token)
    nusc.get("ego_pose", sample_data["ego_pose_token"])
    nusc.get("calibrated_sensor", sample_data["calibrated_sensor_token"])
    if sample["anns"]:
        ann = nusc.get("sample_annotation", sample["anns"][0])
        instance = nusc.get("instance", ann["instance_token"])
        nusc.get("category", instance["category_token"])
    assert channel

