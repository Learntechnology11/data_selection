"""Dataset loading, traversal, and relation helpers."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Dict, Iterator, List, Optional

from .config import SUPPORTED_VERSIONS, default_dataroot
from .schema import ALL_SENSOR_CHANNELS, BASE_TABLES


class NuScenesLoadError(RuntimeError):
    """Raised when nuScenes cannot be loaded with a helpful message."""


def require_devkit():
    """Import the official nuScenes devkit or raise a clear installation hint."""
    try:
        from nuscenes.nuscenes import NuScenes
    except ImportError as exc:
        raise NuScenesLoadError(
            "nuscenes-devkit is not installed. Run: pip install -r requirements.txt"
        ) from exc
    return NuScenes


def validate_dataroot(dataroot: Path, version: str) -> None:
    """Validate the expected nuScenes root layout before devkit initialization."""
    if version not in SUPPORTED_VERSIONS:
        raise NuScenesLoadError(f"Unsupported version {version!r}. Expected one of {SUPPORTED_VERSIONS}.")
    if not dataroot.exists():
        raise NuScenesLoadError(f"dataroot does not exist: {dataroot}")
    if dataroot.name == version:
        raise NuScenesLoadError(
            f"dataroot points inside {version}. Use the nuScenes root instead: {dataroot.parent}"
        )
    version_dir = dataroot / version
    if not version_dir.exists():
        raise NuScenesLoadError(f"Missing metadata directory: {version_dir}")


def load_nuscenes(
    dataroot: str | Path | None = None,
    version: str = "v1.0-mini",
    verbose: bool = False,
):
    """Load the official NuScenes object after path validation."""
    root = Path(dataroot).expanduser().resolve() if dataroot else default_dataroot().resolve()
    validate_dataroot(root, version)
    NuScenes = require_devkit()
    return NuScenes(version=version, dataroot=str(root), verbose=verbose)


def expected_paths(dataroot: Path, version: str) -> Dict[str, Path]:
    """Return the standard directories expected under a nuScenes root."""
    return {
        "dataroot": dataroot,
        "samples": dataroot / "samples",
        "sweeps": dataroot / "sweeps",
        "maps": dataroot / "maps",
        version: dataroot / version,
    }


def path_status(dataroot: Path, version: str) -> Dict[str, bool]:
    """Return existence flags for required dataset paths."""
    return {name: path.exists() for name, path in expected_paths(dataroot, version).items()}


def dataset_counts(nusc) -> Dict[str, int]:
    """Count records in the core tables available on the NuScenes object."""
    counts = {}
    for table in BASE_TABLES:
        records = getattr(nusc, table, None)
        if records is not None:
            counts[table] = len(records)
    return counts


def channel_summary(nusc) -> Dict[str, str]:
    """Return channel -> modality for all sensors known to the dataset."""
    summary = {}
    for sensor in getattr(nusc, "sensor", []):
        summary[sensor["channel"]] = sensor["modality"]
    return dict(sorted(summary.items()))


def get_scene_by_name(nusc, scene_name: str) -> dict:
    """Find a scene by name."""
    for scene in nusc.scene:
        if scene["name"] == scene_name:
            return scene
    raise KeyError(f"scene not found: {scene_name}")


def get_scene(nusc, scene_name: Optional[str] = None, scene_index: int = 0) -> dict:
    """Return a scene by name or index."""
    if scene_name:
        return get_scene_by_name(nusc, scene_name)
    if scene_index < 0 or scene_index >= len(nusc.scene):
        raise IndexError(f"scene-index {scene_index} outside [0, {len(nusc.scene) - 1}]")
    return nusc.scene[scene_index]


def iter_scene_samples(nusc, scene: dict) -> Iterator[dict]:
    """Yield samples in a scene by following sample['next']."""
    token = scene["first_sample_token"]
    while token:
        sample = nusc.get("sample", token)
        yield sample
        if token == scene["last_sample_token"]:
            break
        token = sample["next"]


def get_sample_by_index_or_token(
    nusc,
    sample_index: Optional[int] = None,
    sample_token: Optional[str] = None,
    scene_name: Optional[str] = None,
) -> dict:
    """Resolve a sample from a token or an index within a scene/global list."""
    if sample_token:
        return nusc.get("sample", sample_token)
    if sample_index is None:
        sample_index = 0
    if scene_name:
        scene = get_scene_by_name(nusc, scene_name)
        samples = list(iter_scene_samples(nusc, scene))
    else:
        samples = nusc.sample
    if sample_index < 0 or sample_index >= len(samples):
        raise IndexError(f"sample-index {sample_index} outside [0, {len(samples) - 1}]")
    return samples[sample_index]


def iter_sample_data(nusc, sample: dict) -> Iterator[tuple[str, dict]]:
    """Yield (channel, sample_data) pairs for a sample."""
    for channel in ALL_SENSOR_CHANNELS:
        token = sample.get("data", {}).get(channel)
        if token:
            yield channel, nusc.get("sample_data", token)


def iter_annotations(nusc, sample: dict) -> Iterator[dict]:
    """Yield sample_annotation records for a sample."""
    for ann_token in sample.get("anns", []):
        yield nusc.get("sample_annotation", ann_token)


def get_log_for_scene(nusc, scene: dict) -> dict:
    """Return the log record associated with a scene."""
    return nusc.get("log", scene["log_token"])


def scene_location(nusc, scene: dict) -> str:
    """Return the log location for a scene."""
    return get_log_for_scene(nusc, scene).get("location", "")


def annotation_class_distribution(nusc, sample: dict) -> Dict[str, int]:
    """Count raw categories in a sample's annotations."""
    return dict(Counter(ann["category_name"] for ann in iter_annotations(nusc, sample)))


def sample_sensor_table(nusc, sample: dict) -> List[dict]:
    """Return a list of sensor metadata rows for display/export."""
    rows = []
    for channel, sd in iter_sample_data(nusc, sample):
        cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
        sensor = nusc.get("sensor", cs["sensor_token"])
        ego = nusc.get("ego_pose", sd["ego_pose_token"])
        rows.append(
            {
                "channel": channel,
                "modality": sensor["modality"],
                "filename": sd["filename"],
                "timestamp": sd["timestamp"],
                "is_key_frame": sd["is_key_frame"],
                "ego_translation": ego["translation"],
                "sensor_translation": cs["translation"],
                "has_camera_intrinsic": bool(cs.get("camera_intrinsic")),
            }
        )
    return rows

