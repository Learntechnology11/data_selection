"""Coordinate transforms for nuScenes sensor, ego, global, and camera frames."""

from __future__ import annotations

from typing import Tuple

import numpy as np


def quaternion_to_rotation_matrix(rotation_quaternion) -> np.ndarray:
    """Convert a nuScenes quaternion [w, x, y, z] to a 3 x 3 rotation matrix."""
    q = np.asarray(rotation_quaternion, dtype=float)
    if q.shape != (4,):
        raise ValueError(f"Expected quaternion shape (4,), got {q.shape}")
    norm = np.linalg.norm(q)
    if norm == 0:
        raise ValueError("Quaternion norm is zero.")
    w, x, y, z = q / norm
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=float,
    )


def make_transform_matrix(translation, rotation_quaternion) -> np.ndarray:
    """Build a 4 x 4 homogeneous transform from translation and quaternion."""
    T = np.eye(4, dtype=float)
    T[:3, :3] = quaternion_to_rotation_matrix(rotation_quaternion)
    T[:3, 3] = np.asarray(translation, dtype=float)
    return T


def invert_transform(T: np.ndarray) -> np.ndarray:
    """Invert a rigid 4 x 4 homogeneous transform."""
    T = np.asarray(T, dtype=float)
    if T.shape != (4, 4):
        raise ValueError(f"Expected transform shape (4, 4), got {T.shape}")
    inv = np.eye(4, dtype=float)
    R = T[:3, :3]
    t = T[:3, 3]
    inv[:3, :3] = R.T
    inv[:3, 3] = -R.T @ t
    return inv


def transform_points(points: np.ndarray, T: np.ndarray) -> np.ndarray:
    """Apply a 4 x 4 transform to N x 3 or N x C points, preserving extra columns."""
    arr = np.asarray(points, dtype=float)
    if arr.ndim != 2 or arr.shape[1] < 3:
        raise ValueError(f"Expected N x C points with C >= 3, got {arr.shape}")
    xyz1 = np.c_[arr[:, :3], np.ones(arr.shape[0])]
    transformed = (T @ xyz1.T).T[:, :3]
    out = arr.copy()
    out[:, :3] = transformed
    return out


def sensor_to_ego(points: np.ndarray, calibrated_sensor: dict) -> np.ndarray:
    """Transform sensor-frame points to ego vehicle frame."""
    T = make_transform_matrix(calibrated_sensor["translation"], calibrated_sensor["rotation"])
    return transform_points(points, T)


def ego_to_global(points: np.ndarray, ego_pose: dict) -> np.ndarray:
    """Transform ego-frame points to global map frame."""
    T = make_transform_matrix(ego_pose["translation"], ego_pose["rotation"])
    return transform_points(points, T)


def global_to_ego(points: np.ndarray, ego_pose: dict) -> np.ndarray:
    """Transform global-frame points to ego vehicle frame."""
    T = invert_transform(make_transform_matrix(ego_pose["translation"], ego_pose["rotation"]))
    return transform_points(points, T)


def ego_to_sensor(points: np.ndarray, calibrated_sensor: dict) -> np.ndarray:
    """Transform ego-frame points to sensor frame."""
    T = invert_transform(make_transform_matrix(calibrated_sensor["translation"], calibrated_sensor["rotation"]))
    return transform_points(points, T)


def sample_data_sensor_to_global(nusc, points: np.ndarray, sample_data_token: str) -> np.ndarray:
    """Transform points from a sample_data sensor frame to global frame."""
    sd = nusc.get("sample_data", sample_data_token)
    cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
    ego = nusc.get("ego_pose", sd["ego_pose_token"])
    return ego_to_global(sensor_to_ego(points, cs), ego)


def sample_data_global_to_sensor(nusc, points: np.ndarray, sample_data_token: str) -> np.ndarray:
    """Transform points from global frame to a sample_data sensor frame."""
    sd = nusc.get("sample_data", sample_data_token)
    cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
    ego = nusc.get("ego_pose", sd["ego_pose_token"])
    return ego_to_sensor(global_to_ego(points, ego), cs)


def transform_between_sample_data(
    nusc,
    points: np.ndarray,
    source_sample_data_token: str,
    target_sample_data_token: str,
) -> np.ndarray:
    """Transform sensor-frame points from one sample_data record to another."""
    global_points = sample_data_sensor_to_global(nusc, points, source_sample_data_token)
    return sample_data_global_to_sensor(nusc, global_points, target_sample_data_token)


def project_camera_points(
    points_camera: np.ndarray,
    camera_intrinsic,
    width: int | None = None,
    height: int | None = None,
    min_depth: float = 1e-6,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Project camera-frame points to pixels.

    Returns (uv, depth, mask), where uv is N x 2 and mask keeps positive-depth
    points inside image bounds when width/height are provided.
    """
    points = np.asarray(points_camera, dtype=float)
    K = np.asarray(camera_intrinsic, dtype=float)
    xyz = points[:, :3]
    uvw = (K @ xyz.T).T
    depth = xyz[:, 2]
    uv = np.zeros((points.shape[0], 2), dtype=float)
    valid_depth = depth > min_depth
    uv[valid_depth, 0] = uvw[valid_depth, 0] / depth[valid_depth]
    uv[valid_depth, 1] = uvw[valid_depth, 1] / depth[valid_depth]
    mask = valid_depth.copy()
    if width is not None:
        mask &= (uv[:, 0] >= 0) & (uv[:, 0] < width)
    if height is not None:
        mask &= (uv[:, 1] >= 0) & (uv[:, 1] < height)
    return uv, depth, mask


def project_sensor_points_to_camera(
    nusc,
    points: np.ndarray,
    source_sample_data_token: str,
    camera_sample_data_token: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Transform arbitrary sensor points to camera frame and project to pixels."""
    camera_sd = nusc.get("sample_data", camera_sample_data_token)
    camera_cs = nusc.get("calibrated_sensor", camera_sd["calibrated_sensor_token"])
    points_camera = transform_between_sample_data(
        nusc,
        points,
        source_sample_data_token,
        camera_sample_data_token,
    )
    uv, depth, mask = project_camera_points(
        points_camera,
        camera_cs["camera_intrinsic"],
        width=camera_sd.get("width"),
        height=camera_sd.get("height"),
    )
    return uv, depth, mask, points_camera

