"""Export a Markdown scene summary."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

from nusc_lab.dataset import iter_scene_samples, scene_location


def export_scene_summary(nusc, scene: dict, out_path: str | Path) -> Path:
    """Write a scene summary Markdown file."""
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    counts = Counter()
    samples = list(iter_scene_samples(nusc, scene))
    for sample in samples:
        for ann_token in sample["anns"]:
            ann = nusc.get("sample_annotation", ann_token)
            counts[ann["category_name"]] += 1
    lines = [
        f"# {scene['name']}",
        "",
        f"- description: {scene['description']}",
        f"- location: {scene_location(nusc, scene)}",
        f"- number of samples: {scene['nbr_samples']}",
        f"- first sample token: `{scene['first_sample_token']}`",
        f"- last sample token: `{scene['last_sample_token']}`",
        "",
        "## Annotation Class Distribution",
        "",
    ]
    for name, count in counts.most_common():
        lines.append(f"- {name}: {count}")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out

