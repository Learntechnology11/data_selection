from __future__ import annotations

import numpy as np

from nusc_lab.transforms import (
    invert_transform,
    make_transform_matrix,
    project_camera_points,
    quaternion_to_rotation_matrix,
    transform_points,
)


def test_transform_inverse_recovers_points():
    points = np.array([[1.0, 2.0, 3.0], [-4.0, 0.5, 2.0]])
    T = make_transform_matrix([10, -2, 1], [0.9238795, 0, 0, 0.3826834])
    recovered = transform_points(transform_points(points, T), invert_transform(T))
    np.testing.assert_allclose(recovered, points, atol=1e-6)


def test_quaternion_matrix_shape():
    R = quaternion_to_rotation_matrix([1, 0, 0, 0])
    assert R.shape == (3, 3)
    np.testing.assert_allclose(R, np.eye(3), atol=1e-8)


def test_projection_depth_filter():
    points = np.array([[1.0, 2.0, 10.0], [1.0, 2.0, -1.0]])
    K = np.array([[100.0, 0, 50.0], [0, 100.0, 50.0], [0, 0, 1.0]])
    uv, depth, mask = project_camera_points(points, K, width=200, height=200)
    assert mask.tolist() == [True, False]
    assert depth.tolist() == [10.0, -1.0]
    np.testing.assert_allclose(uv[0], [60.0, 70.0])

