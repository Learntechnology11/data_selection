# 01. 数据集目录结构

nuScenes 不是普通的图片文件夹，而是“传感器文件 + 关系型 JSON 元数据”的组合。解压后根目录应该包含：

```text
nuscenes/
├── maps
├── samples
├── sweeps
└── v1.0-mini 或 v1.0-trainval 或 v1.0-test
```

`samples/` 存放关键帧传感器文件，`sweeps/` 存放非关键帧连续采样，`maps/` 存放地图文件，`v1.0-*` 存放 JSON 表和标注。

## 传感器子目录

Camera：

```text
samples/CAM_FRONT
samples/CAM_FRONT_RIGHT
samples/CAM_BACK_RIGHT
samples/CAM_BACK
samples/CAM_BACK_LEFT
samples/CAM_FRONT_LEFT
```

LiDAR：

```text
samples/LIDAR_TOP
```

Radar：

```text
samples/RADAR_FRONT
samples/RADAR_FRONT_LEFT
samples/RADAR_FRONT_RIGHT
samples/RADAR_BACK_LEFT
samples/RADAR_BACK_RIGHT
```

## dataroot 要指向哪里

正确：

```text
../nuscenes
```

错误：

```text
../nuscenes/v1.0-mini
```

因为官方 devkit 会在 dataroot 下继续查找 `samples/`、`sweeps/`、`maps/` 和版本目录。

