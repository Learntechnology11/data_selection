# 03. Camera / LiDAR / Radar

## Camera

nuScenes 有 6 个相机：

```text
CAM_FRONT
CAM_FRONT_RIGHT
CAM_BACK_RIGHT
CAM_BACK
CAM_BACK_LEFT
CAM_FRONT_LEFT
```

图像是 undistorted and rectified。相机标定在 `calibrated_sensor` 表中：

```text
translation: sensor 原点在 ego 坐标系下的位置
rotation: sensor -> ego 的四元数，顺序为 w, x, y, z
camera_intrinsic: 3x3 相机内参矩阵
```

## LiDAR

LiDAR 通道为 `LIDAR_TOP`。原始 `.bin` 文件按 float32 存储：

```text
x, y, z, intensity, ring_index
```

官方 devkit 默认常用前四维 `x, y, z, intensity`。多 sweep 聚合时，不同 sweep 有不同 ego pose 和 sensor timestamp，必须转换到同一个 reference frame。

## Radar

Radar 通道：

```text
RADAR_FRONT
RADAR_FRONT_LEFT
RADAR_FRONT_RIGHT
RADAR_BACK_LEFT
RADAR_BACK_RIGHT
```

官方 `RadarPointCloud` 读取 18 维字段：

| 字段 | 含义 |
| --- | --- |
| x, y, z | radar 点坐标，x forward, y left |
| dyn_prop | 动态属性，例如 moving、stationary、oncoming、crossing |
| id | radar cluster id |
| rcs | radar cross section，反射强度 |
| vx, vy | 未补偿速度 |
| vx_comp, vy_comp | ego motion compensated velocity |
| is_quality_valid | 质量标志 |
| ambig_state | Doppler ambiguity 状态 |
| x_rms, y_rms | 位置不确定性 |
| invalid_state | cluster validity 状态 |
| pdh0 | false alarm probability |
| vx_rms, vy_rms | 速度不确定性 |

实际使用 Radar 速度时，优先看 `vx_comp / vy_comp`，因为它们已经做过 ego motion compensation。

