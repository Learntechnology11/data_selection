from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


def dataset_config():
    dataroot = os.environ.get("NUSCENES_DATAROOT")
    version = os.environ.get("NUSCENES_VERSION", "v1.0-mini")
    if not dataroot:
        pytest.skip("Set NUSCENES_DATAROOT to run dataset-dependent tests.")
    return Path(dataroot), version
