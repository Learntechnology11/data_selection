# 06. Detection 训练与评估

nuScenes detection benchmark 不是直接使用全部原始 23 类，而是映射到 10 个检测类别：

```text
car
truck
bus
trailer
construction_vehicle
pedestrian
motorcycle
bicycle
traffic_cone
barrier
```

常见原始类别映射包括：

```text
vehicle.car -> car
vehicle.truck -> truck
vehicle.bus.bendy / vehicle.bus.rigid -> bus
human.pedestrian.* -> pedestrian
movable_object.trafficcone -> traffic_cone
movable_object.barrier -> barrier
```

## 评估范围

| 类别 | 范围 |
| --- | ---: |
| car / truck / bus / trailer / construction_vehicle | 50m |
| pedestrian / motorcycle / bicycle | 40m |
| traffic_cone / barrier | 30m |

## 提交 JSON

```json
{
  "meta": {
    "use_camera": true,
    "use_lidar": false,
    "use_radar": false,
    "use_map": false,
    "use_external": false
  },
  "results": {
    "<sample_token>": [
      {
        "sample_token": "<sample_token>",
        "translation": [0, 0, 0],
        "size": [0, 0, 0],
        "rotation": [1, 0, 0, 0],
        "velocity": [0, 0],
        "detection_name": "car",
        "detection_score": 0.9,
        "attribute_name": "vehicle.moving"
      }
    ]
  }
}
```

本工程可以生成空预测模板：

```bash
python scripts/export_detection_json.py --version v1.0-mini --out outputs/detection_empty.json
```

## 指标

| 指标 | 含义 |
| --- | --- |
| mAP | 使用 ground plane 2D center distance 匹配，而不是 3D IoU |
| mATE | Average Translation Error |
| mASE | Average Scale Error |
| mAOE | Average Orientation Error |
| mAVE | Average Velocity Error |
| mAAE | Average Attribute Error |
| NDS | nuScenes Detection Score |

mAP 匹配阈值通常为 `{0.5, 1, 2, 4}` 米。TP metrics 使用 2m center distance。NDS 将 mAP 和若干 TP scores 汇总，mAP 权重更高。

## train / val / test

1. train / val 有标注，可以本地评估。
2. test 有传感器数据，但不公开标注。
3. test 只能生成 result JSON 并提交官方 evaluation server。
4. 不要在 test set 中依赖 sample_annotation 或 scene description 这类未提供信息。

## MMDetection3D 接入思路

```bash
ln -s /data/sets/nuscenes ./data/nuscenes
python tools/create_data.py nuscenes \
  --root-path ./data/nuscenes \
  --out-dir ./data/nuscenes \
  --extra-tag nuscenes
```

LiDAR pipeline 常见模块：

```text
LoadPointsFromFile
LoadPointsFromMultiSweeps
LoadAnnotations3D
GlobalRotScaleTrans
RandomFlip3D
PointsRangeFilter
ObjectRangeFilter
ObjectNameFilter
PointShuffle
Pack3DDetInputs
```

Camera BEV pipeline 通常读取 6 个相机视角，再进入 BEV encoder。

