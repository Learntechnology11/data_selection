"""Export helpers for sample packs, summaries, and detection JSON."""

