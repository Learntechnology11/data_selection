from __future__ import annotations

import matplotlib

matplotlib.use("Agg")

from conftest import dataset_config
from pathlib import Path

from nusc_lab.dataset import load_nuscenes
from nusc_lab.visualization.camera import render_camera
from nusc_lab.visualization.lidar import render_lidar_bev


def test_visualization_smoke():
    dataroot, version = dataset_config()
    nusc = load_nuscenes(dataroot, version)
    sample = nusc.sample[0]
    out_dir = Path(__file__).resolve().parents[1] / "outputs" / "_test_smoke"
    out_dir.mkdir(parents=True, exist_ok=True)
    render_camera(nusc, sample, save_path=out_dir / "camera.png")
    render_lidar_bev(nusc, sample, save_path=out_dir / "lidar.png")
    assert (out_dir / "camera.png").exists()
    assert (out_dir / "lidar.png").exists()
