"""Configuration helpers shared by scripts and notebooks."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


SUPPORTED_VERSIONS = ("v1.0-mini", "v1.0-trainval", "v1.0-test")


def project_root() -> Path:
    """Return the nuscenes_learn project root."""
    return Path(__file__).resolve().parents[2]


def default_dataroot() -> Path:
    """Return the default dataset root, sibling to this project directory."""
    return project_root().parent / "nuscenes"


def default_output_dir() -> Path:
    """Return the default project output directory."""
    return project_root() / "outputs"


@dataclass(frozen=True)
class LabConfig:
    """Resolved runtime configuration for a script."""

    dataroot: Path = default_dataroot()
    version: str = "v1.0-mini"
    output_dir: Path = default_output_dir()
    verbose: bool = False


def add_common_args(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Add dataroot/version/output flags used by all command-line tools."""
    parser.add_argument(
        "--dataroot",
        type=Path,
        default=default_dataroot(),
        help="nuScenes root directory. Default: ../nuscenes from project root.",
    )
    parser.add_argument(
        "--version",
        default="v1.0-mini",
        choices=SUPPORTED_VERSIONS,
        help="nuScenes metadata version.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=default_output_dir(),
        help="Directory for generated outputs.",
    )
    parser.add_argument("--verbose", action="store_true", help="Enable verbose devkit logs.")
    return parser


def config_from_args(args: argparse.Namespace) -> LabConfig:
    """Create a LabConfig from parsed argparse args."""
    return LabConfig(
        dataroot=Path(args.dataroot).expanduser().resolve(),
        version=args.version,
        output_dir=Path(args.output_dir).expanduser().resolve(),
        verbose=bool(getattr(args, "verbose", False)),
    )


def resolve_output_path(
    output_dir: Path,
    out: Optional[Path],
    default_name: str,
    make_parent: bool = True,
) -> Path:
    """Resolve an output path, defaulting inside output_dir."""
    path = Path(out).expanduser() if out else Path(output_dir) / default_name
    if not path.is_absolute():
        path = project_root() / path
    if make_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path.resolve()

