"""Create nuScenes detection-result JSON files for learning submissions."""

from __future__ import annotations

from pathlib import Path
from typing import Dict

from nusc_lab.utils.io import write_json


def create_empty_detection_results(
    nusc,
    save_path: str | Path,
    use_camera: bool = False,
    use_lidar: bool = True,
    use_radar: bool = False,
    use_map: bool = False,
    use_external: bool = False,
) -> Path:
    """Create a valid empty prediction JSON keyed by every sample token."""
    data: Dict[str, object] = {
        "meta": {
            "use_camera": use_camera,
            "use_lidar": use_lidar,
            "use_radar": use_radar,
            "use_map": use_map,
            "use_external": use_external,
        },
        "results": {sample["token"]: [] for sample in nusc.sample},
    }
    return write_json(save_path, data)

