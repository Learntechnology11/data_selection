"""LiDAR BEV visualization."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import matplotlib.pyplot as plt
import numpy as np

from nusc_lab.sensors import load_lidar_points_from_sample
from nusc_lab.visualization.bev import plot_boxes_bev, save_figure, setup_bev_axis


def render_lidar_bev(
    nusc,
    sample: dict,
    nsweeps: int = 1,
    with_boxes: bool = False,
    class_filter: Optional[Iterable[str]] = None,
    save_path: str | Path | None = None,
    xlim=(-50, 50),
    ylim=(-50, 50),
    color_by: str = "distance",
):
    """Render LIDAR_TOP as a BEV scatter plot."""
    points = load_lidar_points_from_sample(nusc, sample, nsweeps=nsweeps)
    xyz = points[:, :3]
    if color_by == "intensity" and points.shape[1] > 3:
        color = points[:, 3]
        label = "intensity"
    else:
        color = np.linalg.norm(xyz[:, :2], axis=1)
        label = "distance"

    fig, ax = plt.subplots(figsize=(8, 8))
    setup_bev_axis(ax, xlim=xlim, ylim=ylim, title=f"LIDAR_TOP BEV ({nsweeps} sweep)")
    scatter = ax.scatter(xyz[:, 0], xyz[:, 1], c=color, s=0.3, cmap="viridis", linewidths=0, alpha=0.85)
    fig.colorbar(scatter, ax=ax, label=label, fraction=0.046, pad=0.04)
    if with_boxes:
        plot_boxes_bev(nusc, sample, ax, class_filter=class_filter)
    save_figure(fig, save_path)
    return fig, ax

