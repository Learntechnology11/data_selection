# 04. 坐标系与转换

nuScenes 里最容易出错的是坐标系。核心链路是：

```text
sensor frame
 -> ego frame at that sensor timestamp
 -> global frame
 -> ego frame at target sensor timestamp
 -> target sensor frame
 -> camera intrinsic projection
 -> image pixel
```

## 坐标系

| 坐标系 | 含义 |
| --- | --- |
| sensor frame | 某个 camera/LiDAR/Radar 自己的坐标系 |
| ego frame | 自车坐标系，随车辆移动 |
| global frame | log 地图坐标系 |
| camera pixel frame | 图像像素坐标 |
| BEV frame | 俯视图，通常 x forward、y left |
| box frame | 3D box 自身局部坐标系 |

## 投影伪代码

```python
p_global = T_global_ego_src @ T_ego_src_sensor @ p_sensor
p_ego_cam = inverse(T_global_ego_cam) @ p_global
p_cam = inverse(T_ego_cam_sensor) @ p_ego_cam
uv_depth = K @ p_cam[:3]
u = uv_depth[0] / uv_depth[2]
v = uv_depth[1] / uv_depth[2]
```

注意：

1. 只保留 `depth > 0` 的点。
2. 只保留落在图像范围内的点。
3. annotation box 默认在 global frame，不能直接用 camera intrinsic 投影。
4. 四元数顺序是 `w, x, y, z`。

本工程对应实现见 `src/nusc_lab/transforms.py`，投影脚本见：

```bash
python scripts/project_lidar_to_camera.py --sample-index 0 --camera CAM_FRONT
python scripts/project_radar_to_camera.py --sample-index 0 --camera CAM_FRONT --radar all
```

