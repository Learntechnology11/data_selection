from __future__ import annotations

import argparse
import sys

import matplotlib.pyplot as plt

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, get_sample_by_index_or_token, load_nuscenes
from nusc_lab.sensors import load_image, load_lidar_points_from_sample, sensor_file_path
from nusc_lab.transforms import project_sensor_points_to_camera


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Project LIDAR_TOP points to a camera image.")
    add_common_args(parser)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--sample-token", default=None)
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--camera", default="CAM_FRONT")
    parser.add_argument("--nsweeps", type=int, default=1)
    parser.add_argument("--color-by", choices=["depth", "intensity"], default="depth")
    parser.add_argument("--out", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        sample = get_sample_by_index_or_token(nusc, args.sample_index, args.sample_token, args.scene_name)
    except (NuScenesLoadError, KeyError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    lidar_token = sample["data"]["LIDAR_TOP"]
    camera_token = sample["data"][args.camera]
    camera_sd = nusc.get("sample_data", camera_token)
    image = load_image(sensor_file_path(nusc, camera_sd))
    points = load_lidar_points_from_sample(nusc, sample, nsweeps=args.nsweeps)
    uv, depth, mask, _points_camera = project_sensor_points_to_camera(nusc, points[:, :3], lidar_token, camera_token)

    fig, ax = plt.subplots(figsize=(12, 7))
    ax.imshow(image)
    color = points[:, 3] if args.color_by == "intensity" and points.shape[1] > 3 else depth
    sc = ax.scatter(uv[mask, 0], uv[mask, 1], c=color[mask], s=1.0, cmap="turbo", alpha=0.85)
    fig.colorbar(sc, ax=ax, label=args.color_by, fraction=0.03, pad=0.01)
    ax.set_title(f"LIDAR_TOP projected to {args.camera}")
    ax.axis("off")

    out = resolve_output_path(cfg.output_dir, args.out, f"sample_{args.sample_index:03d}_lidar_on_{args.camera.lower()}.png")
    fig.savefig(out, dpi=180, bbox_inches="tight")
    print(f"Projected points: {int(mask.sum())}/{len(mask)}")
    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

