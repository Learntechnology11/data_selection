"""Combined sample visualization panels."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import matplotlib.pyplot as plt
import numpy as np

from nusc_lab.visualization.bev import plot_boxes_bev, setup_bev_axis
from nusc_lab.visualization.camera import draw_camera
from nusc_lab.sensors import load_lidar_points_from_sample
from nusc_lab.visualization.radar import _radar_points_in_lidar_frame


def render_fusion_overview(
    nusc,
    sample: dict,
    with_boxes: bool = True,
    class_filter: Optional[Iterable[str]] = None,
    save_path: str | Path | None = None,
):
    """Render camera front, lidar BEV, and radar BEV in one figure."""
    fig = plt.figure(figsize=(16, 10))
    gs = fig.add_gridspec(2, 2)
    ax_cam = fig.add_subplot(gs[0, :])
    draw_camera(ax_cam, nusc, sample, "CAM_FRONT", with_boxes=with_boxes, class_filter=class_filter)

    ax_lidar = fig.add_subplot(gs[1, 0])
    setup_bev_axis(ax_lidar, title="LIDAR_TOP BEV")
    lidar = load_lidar_points_from_sample(nusc, sample)
    ax_lidar.scatter(lidar[:, 0], lidar[:, 1], c=np.linalg.norm(lidar[:, :2], axis=1), s=0.3, cmap="viridis")
    if with_boxes:
        plot_boxes_bev(nusc, sample, ax_lidar, class_filter=class_filter)

    ax_radar = fig.add_subplot(gs[1, 1])
    setup_bev_axis(ax_radar, xlim=(-70, 70), ylim=(-70, 70), title="Radar BEV")
    radar_xyz, radar_rcs, _radar_vel = _radar_points_in_lidar_frame(nusc, sample, "all", False, "compensated")
    if radar_xyz.size:
        ax_radar.scatter(radar_xyz[:, 0], radar_xyz[:, 1], c=radar_rcs, s=8, cmap="plasma")
    if with_boxes:
        plot_boxes_bev(nusc, sample, ax_radar, class_filter=class_filter)

    fig.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=180, bbox_inches="tight")
    return fig
