"""Console formatting helpers."""

from __future__ import annotations


def print_kv(title: str, mapping: dict) -> None:
    """Print a compact key/value block."""
    print(f"\n{title}")
    print("-" * len(title))
    for key, value in mapping.items():
        print(f"{key}: {value}")

