from __future__ import annotations

from pathlib import Path

from _bootstrap import bootstrap


ROOT = bootstrap()


def main() -> int:
    docs = ROOT / "docs"
    docs.mkdir(exist_ok=True)
    out = docs / "mmdet3d_quickstart.md"
    out.write_text(
        """# MMDetection3D nuScenes quickstart

This note is intentionally lightweight. Use it after you can already inspect
and visualize `v1.0-mini` with the scripts in this project.

```bash
ln -s /data/sets/nuscenes ./data/nuscenes
python tools/create_data.py nuscenes \\
  --root-path ./data/nuscenes \\
  --out-dir ./data/nuscenes \\
  --extra-tag nuscenes
```

LiDAR pipelines usually include `LoadPointsFromFile`,
`LoadPointsFromMultiSweeps`, `LoadAnnotations3D`, range/class filters,
augmentation, point shuffle, and `Pack3DDetInputs`.

Camera BEV pipelines usually load six camera views with
`LoadMultiViewImageFromFiles`, then pack annotations and camera metadata into
the model input.
""",
        encoding="utf-8",
    )
    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

