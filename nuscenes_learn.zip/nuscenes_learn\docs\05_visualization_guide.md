# 05. 可视化指南

## Camera mosaic

```bash
python scripts/visualize_sample.py --mode camera-mosaic --sample-index 0 --with-boxes
```

输出 6 相机环视图。`--classes car pedestrian truck` 可以只显示指定 detection 类别或原始类别。

## LiDAR BEV

```bash
python scripts/visualize_lidar_bev.py --sample-index 0 --with-boxes --color-by distance
```

`--color-by intensity` 可按强度上色。`--nsweeps 10` 会调用官方 devkit 的多 sweep 聚合逻辑。

## Radar BEV

```bash
python scripts/visualize_radar_bev.py --sample-index 0 --radar all --velocity compensated
```

点颜色默认表示 RCS，箭头表示速度。`--disable-filters` 会关闭官方 Radar 默认过滤，适合调试原始 PCD 字段。

## LiDAR / Radar 投影到 Camera

```bash
python scripts/project_lidar_to_camera.py --sample-index 0 --camera CAM_FRONT
python scripts/project_radar_to_camera.py --sample-index 0 --camera CAM_FRONT --radar all --color-by velocity
```

这两个脚本体现完整的跨时间戳坐标转换链路。

## Scene 轨迹

```bash
python scripts/visualize_scene.py --scene-name scene-0061 --show-map
```

当前实现会稳定输出 ego trajectory。地图 raster/vector 叠加依赖 map expansion 文件，后续可在 `visualization/maps.py` 中扩展。

