from __future__ import annotations

import argparse
import json
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.annotations import annotation_summary, annotation_to_record
from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import (
    NuScenesLoadError,
    get_sample_by_index_or_token,
    load_nuscenes,
    sample_sensor_table,
)
from nusc_lab.utils.io import write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Inspect one nuScenes sample.")
    add_common_args(parser)
    parser.add_argument("--sample-index", type=int, default=0, help="Global sample index or scene-local index.")
    parser.add_argument("--sample-token", default=None, help="Sample token. Overrides --sample-index.")
    parser.add_argument("--scene-name", default=None, help="Use sample index within this scene.")
    parser.add_argument("--export-json", default=None, help="Optional JSON output path.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        sample = get_sample_by_index_or_token(
            nusc,
            sample_index=args.sample_index,
            sample_token=args.sample_token,
            scene_name=args.scene_name,
        )
    except (NuScenesLoadError, KeyError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    record = {
        "sample": {
            "token": sample["token"],
            "timestamp": sample["timestamp"],
            "scene_token": sample["scene_token"],
            "prev": sample["prev"],
            "next": sample["next"],
        },
        "sensors": sample_sensor_table(nusc, sample),
        "annotations": annotation_summary(nusc, sample),
        "annotation_records": [annotation_to_record(nusc, nusc.get("sample_annotation", t)) for t in sample["anns"]],
    }
    print(json.dumps(record, indent=2, ensure_ascii=False))

    if args.export_json:
        out = resolve_output_path(cfg.output_dir, args.export_json, "sample.json")
        write_json(out, record)
        print(f"\nWrote JSON: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

