"""Radar BEV visualization."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import matplotlib.pyplot as plt
import numpy as np

from nusc_lab.sensors import load_radar_points_from_sample, radar_channels
from nusc_lab.transforms import transform_between_sample_data
from nusc_lab.visualization.bev import plot_boxes_bev, save_figure, setup_bev_axis


def _radar_points_in_lidar_frame(nusc, sample: dict, radar: str, disable_filters: bool, velocity: str):
    """Return radar xyz, rcs, and xy velocity transformed to LIDAR_TOP frame."""
    ref_token = sample["data"]["LIDAR_TOP"]
    xyz_all, rcs_all, vel_all = [], [], []
    for channel in radar_channels(radar):
        src_token = sample["data"][channel]
        points = load_radar_points_from_sample(nusc, sample, radar=channel, disable_filters=disable_filters)
        if points.size == 0:
            continue
        xyz_ref = transform_between_sample_data(nusc, points[:, :3], src_token, ref_token)[:, :3]
        if points.shape[1] >= 10:
            if velocity == "raw":
                vx, vy = points[:, 6], points[:, 7]
            else:
                vx, vy = points[:, 8], points[:, 9]
            endpoints = points[:, :3].copy()
            endpoints[:, 0] += vx
            endpoints[:, 1] += vy
            endpoints_ref = transform_between_sample_data(nusc, endpoints, src_token, ref_token)[:, :3]
            vel_ref = endpoints_ref[:, :2] - xyz_ref[:, :2]
        else:
            vel_ref = np.zeros((points.shape[0], 2), dtype=float)
        xyz_all.append(xyz_ref)
        rcs_all.append(points[:, 5] if points.shape[1] > 5 else np.zeros(points.shape[0]))
        vel_all.append(vel_ref)
    if not xyz_all:
        return np.empty((0, 3)), np.empty((0,)), np.empty((0, 2))
    return np.vstack(xyz_all), np.concatenate(rcs_all), np.vstack(vel_all)


def render_radar_bev(
    nusc,
    sample: dict,
    radar: str = "all",
    velocity: str = "compensated",
    disable_filters: bool = False,
    with_boxes: bool = False,
    class_filter: Optional[Iterable[str]] = None,
    save_path: str | Path | None = None,
    xlim=(-70, 70),
    ylim=(-70, 70),
):
    """Render radar points and velocity arrows in the LIDAR_TOP frame."""
    xyz, rcs, vel_xy = _radar_points_in_lidar_frame(nusc, sample, radar, disable_filters, velocity)
    fig, ax = plt.subplots(figsize=(8, 8))
    setup_bev_axis(ax, xlim=xlim, ylim=ylim, title=f"Radar BEV in LIDAR_TOP frame ({radar})")
    if xyz.size:
        scatter = ax.scatter(xyz[:, 0], xyz[:, 1], c=rcs, s=8, cmap="plasma", alpha=0.85)
        fig.colorbar(scatter, ax=ax, label="rcs", fraction=0.046, pad=0.04)
        stride = max(1, len(xyz) // 250)
        ax.quiver(
            xyz[::stride, 0],
            xyz[::stride, 1],
            vel_xy[::stride, 0],
            vel_xy[::stride, 1],
            angles="xy",
            scale_units="xy",
            scale=8,
            width=0.002,
            color="black",
            alpha=0.65,
        )
    if with_boxes:
        plot_boxes_bev(nusc, sample, ax, class_filter=class_filter)
    save_figure(fig, save_path)
    return fig, ax
