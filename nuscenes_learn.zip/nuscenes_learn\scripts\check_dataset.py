from __future__ import annotations

import argparse
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args
from nusc_lab.dataset import (
    NuScenesLoadError,
    channel_summary,
    dataset_counts,
    expected_paths,
    load_nuscenes,
    path_status,
)
from nusc_lab.utils.logging import print_kv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check a nuScenes dataset root.")
    add_common_args(parser)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)

    print(f"dataroot: {cfg.dataroot}")
    print(f"version:  {cfg.version}")
    print("\nExpected paths")
    print("--------------")
    statuses = path_status(cfg.dataroot, cfg.version)
    for name, path in expected_paths(cfg.dataroot, cfg.version).items():
        mark = "OK" if statuses[name] else "MISSING"
        print(f"{mark:7} {name:12} {path}")

    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
    except NuScenesLoadError as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        return 2

    print_kv("Table counts", dataset_counts(nusc))
    print_kv("Sensor channels", channel_summary(nusc))
    print("\nDataset loaded successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

