"""Bird's-eye-view plotting primitives."""

from __future__ import annotations

import math
from typing import Iterable, Optional

import matplotlib.pyplot as plt
import numpy as np

from nusc_lab.schema import raw_category_to_detection
from nusc_lab.transforms import global_to_ego, quaternion_to_rotation_matrix
from nusc_lab.utils.colors import CATEGORY_COLORS, DEFAULT_BOX_COLOR


def setup_bev_axis(ax=None, xlim=(-50, 50), ylim=(-50, 50), title: str = "BEV"):
    """Create or configure a BEV axis with ego vehicle at the origin."""
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 8))
    ax.set_title(title)
    ax.set_xlabel("x forward (m)")
    ax.set_ylabel("y left (m)")
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, alpha=0.25)
    ax.scatter([0], [0], marker="x", c="red", s=40, label="ego")
    return ax


def _yaw_from_quaternion(q) -> float:
    R = quaternion_to_rotation_matrix(q)
    return math.atan2(R[1, 0], R[0, 0])


def _box_corners_ego(ann: dict, ref_ego_pose: dict) -> np.ndarray:
    center_global = np.asarray([ann["translation"]], dtype=float)
    center_ego = global_to_ego(center_global, ref_ego_pose)[0, :3]
    ego_yaw = _yaw_from_quaternion(ref_ego_pose["rotation"])
    box_yaw = _yaw_from_quaternion(ann["rotation"]) - ego_yaw
    width, length, _height = ann["size"]
    local = np.array(
        [
            [length / 2, width / 2],
            [length / 2, -width / 2],
            [-length / 2, -width / 2],
            [-length / 2, width / 2],
            [length / 2, width / 2],
        ]
    )
    c, s = math.cos(box_yaw), math.sin(box_yaw)
    R = np.array([[c, -s], [s, c]])
    return local @ R.T + center_ego[:2]


def plot_boxes_bev(
    nusc,
    sample: dict,
    ax,
    ref_channel: str = "LIDAR_TOP",
    class_filter: Optional[Iterable[str]] = None,
) -> None:
    """Draw sample annotations in a reference ego frame."""
    ref_sd = nusc.get("sample_data", sample["data"][ref_channel])
    ref_ego = nusc.get("ego_pose", ref_sd["ego_pose_token"])
    filters = {item.strip() for item in class_filter or [] if item.strip()}
    for ann_token in sample.get("anns", []):
        ann = nusc.get("sample_annotation", ann_token)
        det_name = raw_category_to_detection(ann["category_name"])
        if filters and ann["category_name"] not in filters and det_name not in filters:
            continue
        corners = _box_corners_ego(ann, ref_ego)
        color = CATEGORY_COLORS.get(det_name or ann["category_name"], DEFAULT_BOX_COLOR)
        ax.plot(corners[:, 0], corners[:, 1], color=color, linewidth=1.2)
        ax.text(corners[0, 0], corners[0, 1], det_name or ann["category_name"].split(".")[-1], fontsize=6)


def save_figure(fig, save_path) -> None:
    """Save a figure with tight layout."""
    if save_path:
        fig.savefig(save_path, dpi=180, bbox_inches="tight")

