from __future__ import annotations

import argparse
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, load_nuscenes
from nusc_lab.export.export_detection_json import create_empty_detection_results


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create an empty nuScenes detection result JSON.")
    add_common_args(parser)
    parser.add_argument("--use-camera", action="store_true")
    parser.add_argument("--use-lidar", action="store_true", default=True)
    parser.add_argument("--use-radar", action="store_true")
    parser.add_argument("--use-map", action="store_true")
    parser.add_argument("--use-external", action="store_true")
    parser.add_argument("--out", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
    except NuScenesLoadError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    out = resolve_output_path(cfg.output_dir, args.out, f"detection_empty_{cfg.version}.json")
    create_empty_detection_results(
        nusc,
        out,
        use_camera=args.use_camera,
        use_lidar=args.use_lidar,
        use_radar=args.use_radar,
        use_map=args.use_map,
        use_external=args.use_external,
    )
    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

