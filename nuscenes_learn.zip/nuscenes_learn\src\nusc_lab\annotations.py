"""Annotation filtering, class mapping, and export helpers."""

from __future__ import annotations

from collections import Counter
from typing import Iterable, List, Optional

from .schema import matches_class_filter, raw_category_to_detection


def filter_annotation_tokens(nusc, sample: dict, class_filter: Optional[Iterable[str]] = None) -> List[str]:
    """Return annotation tokens matching raw or 10-class detection labels."""
    selected = []
    for ann_token in sample.get("anns", []):
        ann = nusc.get("sample_annotation", ann_token)
        if matches_class_filter(ann["category_name"], class_filter):
            selected.append(ann_token)
    return selected


def annotation_summary(nusc, sample: dict) -> dict:
    """Summarize raw and detection class counts for a sample."""
    raw_counts = Counter()
    det_counts = Counter()
    for ann_token in sample.get("anns", []):
        ann = nusc.get("sample_annotation", ann_token)
        raw_name = ann["category_name"]
        raw_counts[raw_name] += 1
        det_name = raw_category_to_detection(raw_name)
        if det_name:
            det_counts[det_name] += 1
    return {"raw": dict(raw_counts), "detection": dict(det_counts)}


def attribute_names(nusc, ann: dict) -> List[str]:
    """Resolve attribute token names for a sample annotation."""
    names = []
    for token in ann.get("attribute_tokens", []):
        names.append(nusc.get("attribute", token)["name"])
    return names


def annotation_to_record(nusc, ann: dict) -> dict:
    """Convert a sample annotation to a compact JSON-friendly record."""
    return {
        "token": ann["token"],
        "sample_token": ann["sample_token"],
        "instance_token": ann["instance_token"],
        "category_name": ann["category_name"],
        "detection_name": raw_category_to_detection(ann["category_name"]),
        "attributes": attribute_names(nusc, ann),
        "visibility_token": ann.get("visibility_token"),
        "translation": ann["translation"],
        "size": ann["size"],
        "rotation": ann["rotation"],
        "num_lidar_pts": ann.get("num_lidar_pts"),
        "num_radar_pts": ann.get("num_radar_pts"),
    }

