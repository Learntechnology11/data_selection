"""Export compact metadata for one sample."""

from __future__ import annotations

from pathlib import Path

from nusc_lab.annotations import annotation_to_record
from nusc_lab.dataset import sample_sensor_table
from nusc_lab.utils.io import write_json


def export_sample_pack(nusc, sample: dict, out_dir: str | Path) -> Path:
    """Export sample metadata, sensor records, and annotations as JSON files."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(
        out / "metadata.json",
        {
            "token": sample["token"],
            "timestamp": sample["timestamp"],
            "scene_token": sample["scene_token"],
            "prev": sample["prev"],
            "next": sample["next"],
        },
    )
    write_json(out / "sensors.json", sample_sensor_table(nusc, sample))
    anns = [annotation_to_record(nusc, nusc.get("sample_annotation", token)) for token in sample["anns"]]
    write_json(out / "annotations.json", anns)
    return out

