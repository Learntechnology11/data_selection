"""Consistent colors for categories and sensor plots."""

CATEGORY_COLORS = {
    "car": (0.0, 0.45, 0.74),
    "truck": (0.85, 0.33, 0.10),
    "bus": (0.93, 0.69, 0.13),
    "trailer": (0.49, 0.18, 0.56),
    "construction_vehicle": (0.47, 0.67, 0.19),
    "pedestrian": (0.64, 0.08, 0.18),
    "motorcycle": (0.30, 0.75, 0.93),
    "bicycle": (0.35, 0.35, 0.35),
    "traffic_cone": (1.0, 0.55, 0.0),
    "barrier": (0.15, 0.65, 0.45),
}

DEFAULT_BOX_COLOR = (1.0, 1.0, 0.0)

