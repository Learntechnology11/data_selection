from __future__ import annotations

import argparse
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, get_sample_by_index_or_token, load_nuscenes
from nusc_lab.visualization.camera import render_camera, render_camera_mosaic
from nusc_lab.visualization.fusion import render_fusion_overview
from nusc_lab.visualization.lidar import render_lidar_bev
from nusc_lab.visualization.radar import render_radar_bev


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize one nuScenes sample.")
    add_common_args(parser)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--sample-token", default=None)
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--mode", choices=["camera", "camera-mosaic", "lidar", "radar", "fusion"], default="fusion")
    parser.add_argument("--camera", default="CAM_FRONT")
    parser.add_argument("--radar", default="all")
    parser.add_argument("--nsweeps", type=int, default=1)
    parser.add_argument("--with-boxes", action="store_true")
    parser.add_argument("--classes", nargs="*", default=None, help="Raw or detection classes to show.")
    parser.add_argument("--out", default=None, help="Output PNG path.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        sample = get_sample_by_index_or_token(nusc, args.sample_index, args.sample_token, args.scene_name)
    except (NuScenesLoadError, KeyError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    default_name = f"sample_{args.sample_index:03d}_{args.mode}.png"
    out = resolve_output_path(cfg.output_dir, args.out, default_name)

    if args.mode == "camera":
        render_camera(nusc, sample, args.camera, args.with_boxes, args.classes, out)
    elif args.mode == "camera-mosaic":
        render_camera_mosaic(nusc, sample, args.with_boxes, args.classes, out)
    elif args.mode == "lidar":
        render_lidar_bev(nusc, sample, nsweeps=args.nsweeps, with_boxes=args.with_boxes, class_filter=args.classes, save_path=out)
    elif args.mode == "radar":
        render_radar_bev(nusc, sample, radar=args.radar, with_boxes=args.with_boxes, class_filter=args.classes, save_path=out)
    else:
        render_fusion_overview(nusc, sample, with_boxes=args.with_boxes, class_filter=args.classes, save_path=out)

    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

