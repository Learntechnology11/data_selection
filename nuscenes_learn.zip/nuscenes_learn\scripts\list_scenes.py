from __future__ import annotations

import argparse
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, load_nuscenes, scene_location
from nusc_lab.utils.io import write_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="List nuScenes scenes.")
    add_common_args(parser)
    parser.add_argument("--keyword", default=None, help="Filter scenes by description keyword.")
    parser.add_argument("--export", type=str, default=None, help="Optional CSV output path.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
    except NuScenesLoadError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    rows = []
    keyword = args.keyword.lower() if args.keyword else None
    for scene in nusc.scene:
        if keyword and keyword not in scene["description"].lower():
            continue
        rows.append(
            {
                "name": scene["name"],
                "location": scene_location(nusc, scene),
                "nbr_samples": scene["nbr_samples"],
                "first_sample_token": scene["first_sample_token"],
                "last_sample_token": scene["last_sample_token"],
                "description": scene["description"],
            }
        )

    print(f"{'scene':<12} {'location':<24} {'samples':<8} description")
    print("-" * 90)
    for row in rows:
        print(f"{row['name']:<12} {row['location']:<24} {row['nbr_samples']:<8} {row['description']}")

    if args.export:
        out = resolve_output_path(cfg.output_dir, args.export, "scenes.csv")
        write_csv(out, rows)
        print(f"\nWrote CSV: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

