from __future__ import annotations

import argparse
import sys

from _bootstrap import bootstrap

bootstrap()

from nusc_lab.config import add_common_args, config_from_args, resolve_output_path
from nusc_lab.dataset import NuScenesLoadError, get_sample_by_index_or_token, load_nuscenes
from nusc_lab.sensors import describe_lidar, load_lidar_points_from_sample
from nusc_lab.visualization.lidar import render_lidar_bev


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render LIDAR_TOP BEV.")
    add_common_args(parser)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--sample-token", default=None)
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--nsweeps", type=int, default=1)
    parser.add_argument("--with-boxes", action="store_true")
    parser.add_argument("--classes", nargs="*", default=None)
    parser.add_argument("--color-by", choices=["distance", "intensity"], default="distance")
    parser.add_argument("--out", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = config_from_args(args)
    try:
        nusc = load_nuscenes(cfg.dataroot, cfg.version, verbose=cfg.verbose)
        sample = get_sample_by_index_or_token(nusc, args.sample_index, args.sample_token, args.scene_name)
    except (NuScenesLoadError, KeyError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    out = resolve_output_path(cfg.output_dir, args.out, f"sample_{args.sample_index:03d}_lidar_bev.png")
    points = load_lidar_points_from_sample(nusc, sample, nsweeps=args.nsweeps)
    print(describe_lidar(points))
    render_lidar_bev(
        nusc,
        sample,
        nsweeps=args.nsweeps,
        with_boxes=args.with_boxes,
        class_filter=args.classes,
        color_by=args.color_by,
        save_path=out,
    )
    print(f"Wrote: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

