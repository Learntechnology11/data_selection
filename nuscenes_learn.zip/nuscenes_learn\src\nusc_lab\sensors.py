"""Sensor file loading helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

import numpy as np
from PIL import Image

from .schema import RADAR_CHANNELS


def sensor_file_path(nusc, sample_data: dict) -> Path:
    """Return an absolute path for a sample_data file."""
    return Path(nusc.dataroot) / sample_data["filename"]


def load_image(path: str | Path) -> Image.Image:
    """Load an RGB image without mutating the underlying dataset."""
    return Image.open(path).convert("RGB")


def load_lidar_bin(path: str | Path) -> np.ndarray:
    """Load a nuScenes lidar .bin file as N x 5 float32 points."""
    points = np.fromfile(path, dtype=np.float32)
    if points.size % 5 != 0:
        raise ValueError(f"Unexpected lidar file length, not divisible by 5: {path}")
    return points.reshape((-1, 5))


def load_lidar_points_from_sample(nusc, sample: dict, nsweeps: int = 1) -> np.ndarray:
    """Load LIDAR_TOP points for a sample.

    For nsweeps=1 this reads the binary file directly and returns N x 5
    [x, y, z, intensity, ring]. For nsweeps>1 it delegates to the official
    devkit and returns N x C in the reference lidar frame.
    """
    lidar_token = sample["data"]["LIDAR_TOP"]
    lidar_sd = nusc.get("sample_data", lidar_token)
    if nsweeps <= 1:
        return load_lidar_bin(sensor_file_path(nusc, lidar_sd))

    try:
        from nuscenes.utils.data_classes import LidarPointCloud
    except ImportError as exc:
        raise RuntimeError("nuscenes-devkit is required for multi-sweep lidar loading.") from exc

    pc, times = LidarPointCloud.from_file_multisweep(
        nusc,
        sample,
        "LIDAR_TOP",
        "LIDAR_TOP",
        nsweeps=nsweeps,
    )
    return np.vstack([pc.points, times]).T


def _radar_point_cloud_class():
    try:
        from nuscenes.utils.data_classes import RadarPointCloud
    except ImportError as exc:
        raise RuntimeError("nuscenes-devkit is required for radar point cloud loading.") from exc
    return RadarPointCloud


def radar_channels(radar: str) -> List[str]:
    """Normalize a radar channel argument."""
    if radar == "all":
        return list(RADAR_CHANNELS)
    if radar not in RADAR_CHANNELS:
        raise ValueError(f"Unknown radar channel {radar!r}. Use one of {RADAR_CHANNELS} or 'all'.")
    return [radar]


def load_radar_points_from_sample(
    nusc,
    sample: dict,
    radar: str = "RADAR_FRONT",
    disable_filters: bool = False,
) -> np.ndarray:
    """Load one or more radar point clouds as N x 18 arrays."""
    RadarPointCloud = _radar_point_cloud_class()
    if disable_filters:
        RadarPointCloud.disable_filters()
    else:
        RadarPointCloud.default_filters()

    clouds = []
    for channel in radar_channels(radar):
        sd = nusc.get("sample_data", sample["data"][channel])
        pc = RadarPointCloud.from_file(str(sensor_file_path(nusc, sd)))
        arr = pc.points.T
        if arr.size:
            channel_col = np.full((arr.shape[0], 1), RADAR_CHANNELS.index(channel), dtype=np.float32)
            arr = np.hstack([arr, channel_col])
        clouds.append(arr)
    if not clouds:
        return np.empty((0, 19), dtype=np.float32)
    return np.vstack(clouds) if any(cloud.size for cloud in clouds) else np.empty((0, 19), dtype=np.float32)


def describe_lidar(points: np.ndarray) -> dict:
    """Return basic lidar point cloud statistics."""
    if points.size == 0:
        return {"shape": list(points.shape), "distance_min": None, "distance_max": None}
    dist = np.linalg.norm(points[:, :3], axis=1)
    intensity = points[:, 3] if points.shape[1] > 3 else np.array([])
    return {
        "shape": list(points.shape),
        "distance_min": float(dist.min()),
        "distance_max": float(dist.max()),
        "intensity_min": float(intensity.min()) if intensity.size else None,
        "intensity_max": float(intensity.max()) if intensity.size else None,
    }


def describe_radar(points: np.ndarray) -> dict:
    """Return basic radar point cloud statistics."""
    if points.size == 0:
        return {"shape": list(points.shape), "rcs_min": None, "rcs_max": None}
    speed = np.linalg.norm(points[:, 8:10], axis=1) if points.shape[1] >= 10 else np.array([])
    return {
        "shape": list(points.shape),
        "rcs_min": float(points[:, 5].min()) if points.shape[1] > 5 else None,
        "rcs_max": float(points[:, 5].max()) if points.shape[1] > 5 else None,
        "comp_speed_min": float(speed.min()) if speed.size else None,
        "comp_speed_max": float(speed.max()) if speed.size else None,
    }

